import AsyncStorage from '@react-native-async-storage/async-storage';
import { FunctionsHttpError } from '@supabase/supabase-js';

import { DEMO_LABEL } from '@/features/demo/data';
import type { PreparedImage } from '@/features/diagnosis/api';
import { demoDelay, isDemoMode } from '@/lib/demo-mode';
import { supabase } from '@/lib/supabase';

export type LabelRead = { brand_name: string; composition: string };
type ErrorKey = 'sprayNotLabel' | 'sprayNoComposition' | 'errAiBusy' | 'errBadImage' | 'errNetwork' | 'errDiagnose';

/** D-41: the server only says WHICH product this is; the dose comes from the register or the farmer. */
export async function readPesticideLabel(image: PreparedImage): Promise<{ label: LabelRead | null; errorKey: ErrorKey | null }> {
  let data: LabelRead & { is_pesticide_label: boolean };
  if (isDemoMode()) {
    await demoDelay(1600);
    data = DEMO_LABEL;
  } else {
    const body = image.bytes.buffer.slice(image.bytes.byteOffset, image.bytes.byteOffset + image.bytes.byteLength) as ArrayBuffer;
    const res = await supabase.functions.invoke<LabelRead & { is_pesticide_label: boolean }>('read-pesticide-label', {
      body,
      headers: { 'Content-Type': image.contentType },
    });
    if (res.error || !res.data) {
      const status = res.error instanceof FunctionsHttpError ? (res.error.context as Response).status : 0;
      return { label: null, errorKey: status === 503 ? 'errAiBusy' : status === 413 || status === 415 ? 'errBadImage' : status === 0 ? 'errNetwork' : 'errDiagnose' };
    }
    data = res.data;
  }
  if (!data.is_pesticide_label) return { label: null, errorKey: 'sprayNotLabel' };
  return { label: { brand_name: data.brand_name, composition: data.composition }, errorKey: data.composition ? null : 'sprayNoComposition' };
}

// The farmer's own fertiliser comparison, shown on the Savings card as an estimate.
export type FertSaving = { rupees: number; saved_at: string };
const fertKey = (farmerId: string) => `ks.fertSaving.${farmerId}`;

export async function loadFertSaving(farmerId: string): Promise<FertSaving | null> {
  const raw = await AsyncStorage.getItem(fertKey(farmerId));
  return raw ? (JSON.parse(raw) as FertSaving) : null;
}

export async function saveFertSaving(farmerId: string, rupees: number | null): Promise<void> {
  if (rupees === null || rupees <= 0) await AsyncStorage.removeItem(fertKey(farmerId));
  else await AsyncStorage.setItem(fertKey(farmerId), JSON.stringify({ rupees, saved_at: new Date().toISOString() }));
}
