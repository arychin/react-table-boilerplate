// Mirrors supabase/functions/_shared/diagnosis.ts (TRD §6.1 schema + Should-I-Spray). Keep the two in step.
export type Severity = 'low' | 'medium' | 'high' | 'urgent';
export type Confidence = 'low' | 'medium' | 'high';
export type SprayDecision = 'not_needed' | 'wait_and_watch' | 'spray_recommended';

export type Diagnosis = {
  crop_name: string;
  disease_name: string;
  cause: string;
  severity: Severity;
  confidence: Confidence;
  spray_decision: SprayDecision;
  decision_reason: string;
  treatment: string;
  treatment_steps: string[];
  prevention_tips?: string[];
  organic_alternative?: string;
};

// Mirrors supabase/functions/_shared/soil.ts (Vision Brief §3.4). Keep the two in step.
export type SoilReport = {
  soil_type: string;
  moisture: 'low' | 'medium' | 'high';
  confidence: Confidence;
  observations: string;
  possible_deficiencies: string[];
  fertilisers: { name: string; why: string }[];
  improvement_tips: string[];
};

export type Kind = 'crop' | 'soil';
