// Vision Brief §3.15 Soil Health Card scanner: read the values PRINTED on the farmer's own card (OCR via Gemini vision).
// Nothing is estimated. The photo is not stored, and personal details on the card (name, survey no.) are not extracted.
import { encodeBase64 } from 'jsr:@std/encoding@1';

import { sniffImageMime } from '../_shared/diagnosis.ts';
import { generate } from '../_shared/gemini.ts';
import { cors, fail, signedInFarmer } from '../_shared/http.ts';

const MAX_BYTES = 10 * 1024 * 1024;
const KEYS = ['pH', 'EC', 'OC', 'N', 'P', 'K', 'S', 'Zn', 'B', 'Fe', 'Mn', 'Cu'];

const CARD_SCHEMA = {
  type: 'object',
  properties: {
    is_soil_health_card: { type: 'boolean' },
    sample_date: { type: 'string' },
    parameters: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          key: { type: 'string', enum: KEYS },
          value: { type: 'string' },
          unit: { type: 'string' },
          rating: { type: 'string' },
        },
        required: ['key', 'value', 'unit', 'rating'],
        propertyOrdering: ['key', 'value', 'unit', 'rating'],
      },
    },
  },
  required: ['is_soil_health_card', 'sample_date', 'parameters'],
  propertyOrdering: ['is_soil_health_card', 'sample_date', 'parameters'],
} as const;

const INSTRUCTION = `You read a photo of an Indian government Soil Health Card (मृदा स्वास्थ्य कार्ड) for a farmer. You are a careful transcriber, not an adviser.
Rules — follow all of them:
1. Copy ONLY what is printed. Never estimate, calculate, correct or fill in a value. If a value is unreadable or missing, leave that parameter out.
2. parameters: the soil test results table. Map each row to key: pH, EC (electrical conductivity), OC (organic carbon), N, P, K (available nitrogen / phosphorus / potassium), S (sulphur), Zn, B, Fe, Mn, Cu. Rows in Hindi map the same way.
3. value: the number exactly as printed. unit: as printed (for example kg/ha, ppm, %, dS/m), "" if none. rating: the printed rating word exactly as printed (for example Low, Medium, High, Deficient, Sufficient, Acidic, Normal), "" if none.
4. sample_date: the sample collection or test date exactly as printed, "" if none.
5. Do not copy the farmer's name, father's name, Aadhaar, mobile or survey/khasra numbers, and ignore the fertiliser recommendation section.
6. is_soil_health_card: false if the photo is not a soil test report or card; then return an empty parameters list.`;

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  if (req.method !== 'POST') return fail(405, 'method_not_allowed');
  if (!signedInFarmer(req)) return fail(401, 'unauthorized');
  if (Number(req.headers.get('content-length') ?? 0) > MAX_BYTES) return fail(413, 'image_too_large');
  const bytes = new Uint8Array(await req.arrayBuffer());
  if (bytes.byteLength > MAX_BYTES) return fail(413, 'image_too_large');
  const mimeType = sniffImageMime(bytes);
  if (!mimeType) return fail(415, 'unsupported_image');

  try {
    const { text, model } = await generate({
      systemInstruction: { parts: [{ text: INSTRUCTION }] },
      contents: [{ role: 'user', parts: [{ inlineData: { mimeType, data: encodeBase64(bytes) } }, { text: 'Read this card.' }] }],
      generationConfig: { temperature: 0, responseMimeType: 'application/json', responseSchema: CARD_SCHEMA, maxOutputTokens: 1024 },
    });
    const card = JSON.parse(text);
    console.log(`read-soil-card: model=${model} card=${card.is_soil_health_card} params=${card.parameters?.length ?? 0}`);
    return Response.json(card, { headers: cors });
  } catch {
    return fail(503, 'ai_unavailable');
  }
});
