import type { Session } from '@supabase/supabase-js';

import { savePlan } from '@/features/crop-feed/api';
import { saveSprayCost } from '@/features/savings/api';

import { DEMO_FARMER_ID } from './data';

// A local stand-in for a signed-in farmer: no token is ever sent anywhere in Demo Mode.
export const DEMO_SESSION: Session = {
  access_token: 'demo',
  refresh_token: 'demo',
  expires_in: 315_360_000,
  token_type: 'bearer',
  user: { id: DEMO_FARMER_ID, aud: 'authenticated', app_metadata: {}, user_metadata: {}, created_at: '2026-09-29T00:00:00Z' },
};

/** Phone-side demo data: a paddy crop 45 days in (field check due) and a spray cost for the Savings estimate. */
export async function seedDemo(): Promise<void> {
  const sown = new Date(Date.now() - 45 * 86_400_000);
  const sownOn = `${sown.getFullYear()}-${String(sown.getMonth() + 1).padStart(2, '0')}-${String(sown.getDate()).padStart(2, '0')}`;
  await Promise.all([
    savePlan(DEMO_FARMER_ID, { crop: 'rice', sownOn, duration: 130, chanaStage: 'chana_seedling', lastScouted: null }),
    saveSprayCost(DEMO_FARMER_ID, 650),
  ]);
}
