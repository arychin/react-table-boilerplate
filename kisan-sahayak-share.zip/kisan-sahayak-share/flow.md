# flow.md

How execution travels through the codebase. Updated at the end of every session.

## Entry point
`package.json` → `"main": "expo-router/entry"`. Expo Router builds the routes from `src/app/`.

## Current execution path (after Phase 6)
```
expo-router/entry
└── src/app/_layout.tsx                RootLayout: ThemeProvider → AppProvider → RootNavigator
    │   AppProvider (features/auth/app-context.tsx): loads session + saved language, hides the splash when ready
    ├── signed OUT (Stack.Protected guard={!signedIn})
    │   ├── sign-in.tsx   → auth/api.sendOtp → supabase.auth.signInWithOtp
    │   └── verify.tsx    → auth/api.verifyOtp → session set → guard flips → (tabs)
    └── signed IN (Stack.Protected guard={signedIn})
        ├── (tabs)/index.tsx (Home)  → diagnosis/pick-image.pickAndDiagnose (camera | gallery)
        │                              → router.push /diagnosis/camera?uri,width,height,mimeType
        ├── diagnosis/camera.tsx     → diagnosis/api.prepareImage (resize ≤ 1280 px JPEG)
        │                              → diagnosis/api.diagnoseCrop → POST functions/v1/diagnose-crop (raw bytes; one auto-retry on 503)
        │                              → router.replace /diagnosis/[id]   (errors → message + retry)
        ├── diagnosis/[id].tsx       → diagnosis/api.fetchDiagnosis (device cache, else diagnoses via RLS)
        │                              → signedImageUrl (600 s) when not cached
        │                              → voice/bolo-button.tsx → voice/api.fetchBolo → POST functions/v1/bolo
        │                                 → expo-audio player (tap = play, tap again = stop + rewind)
        │                              → shops/nearby-shops.tsx (only when treatment applies) → top 3 shops, "See all shops" → /shops
        ├── (tabs)/history.tsx       → diagnosis/api.listDiagnoses → tap → /diagnosis/[id]
        ├── (tabs)/shops.tsx         → shops/use-nearby-shops.useNearbyShops(ask location, query)
        │                                 ├── expo-location: permission → last fix (30 min) or GPS (≤ 20 s); works offline
        │                                 ├── profile district: auth/api.fetchFarmer, cached in AsyncStorage per farmer
        │                                 └── shops/find-shops.findShops → src/data/shops.json + lib/haversine (NO network)
        │                              → shops/shop-card: Call (tel:) / Directions (Google Maps URL)
        ├── (tabs)/chat.tsx          placeholder (Phase 6)
        └── settings/account.tsx     → auth/api.fetchFarmer / updateProfile / signOut
```

Every network function in `features/*/api.ts` calls `isDemoMode()` first.

## Changed in the latest session (Daily Action Feed, D-42)
- Home → crop-feed/today-card.tsx
  - on focus: crop-feed/api.loadPlan (AsyncStorage, plus today's date)
  - → crop-feed/feed.todayFor (day number, stage, scouting due/done/too early)
  - → CHECKS[stage] (NIPHM thresholds)
- "Field checked ✓" → api.markScouted
- "Check with a photo" → diagnosis/pick-image.pickAndDiagnose('camera')
- Setup/change: /crop-plan → api.pastDate (day + month → date, max 200 days back) → api.savePlan
- No network anywhere in the feed

## Changed in the session before (Calculator, D-41)
- Home "🧮 हिसाब लगाएँ" card → /spray-calculator or /fertilizer-calculator
- Spray: crop chips → product by photo (expo-image-picker → diagnosis/api.prepareImage → calculator/api.readPesticideLabel → POST functions/v1/read-pesticide-label: Gemini transcribes brand + composition only)
  - → calculator/register.matchComposition (code, not AI) over src/data/pesticide-register.json (CIB&RC 31.03.2026)
  - or by name search (register.searchProducts), or the farmer's own label amount
  - → problem row → compute.spray (per tank, tanks, total product, total water) — all on the phone
- Fertiliser: crop + district (shops/use-nearby-shops.useProfileDistrict, else picker) → register.gfrFor over src/data/fertilizer-gfr-cg.json (ICAR June 2026)
  - or Soil Health Card numbers → compute.fertiliserKg / cost / compareUsual (per fertiliser, never netted)
  - → calculator/api.saveFertSaving (AsyncStorage) → shown on the History savings card as an estimate
- Data files are rebuilt by scripts/build_calculator_data.py; checks: scripts/check_calculator.mts

## Server side: diagnose-crop (supabase/functions/diagnose-crop/index.ts)
```
gateway verifies JWT (verify_jwt=true) → _shared/http.signedInFarmer(): claims.role === 'authenticated' → farmerId
→ read body bytes (≤ 10 MB) → _shared/diagnosis.sniffImageMime (415 if not an image)
→ rate check: ≤ 20 diagnoses/hour (429)
→ in parallel: Storage upload to diagnosis-images/<farmerId>/<uuid>.<ext>  ∥  _shared/diagnosis.diagnoseImage
     diagnoseImage → _shared/gemini.generate: 3.5-flash-lite, + 3.1-flash-lite in parallel after 3.5 s, 9 s deadline
     → responseSchema JSON → enforceSafety
→ insert diagnoses → respond {id, image_path, diagnosis, model, timings_ms}
→ EdgeRuntime.waitUntil: follow_ups (+3 days) + engagement_events (diagnosis_completed)
→ EdgeRuntime.waitUntil: _shared/bolo.prepareBolo (Hindi summary via gemini.generate → Sarvam bulbul:v3 priya mp3 → bolo-audio/<farmer>/<diagnosis>.mp3)
```

## Server side: bolo (supabase/functions/bolo/index.ts)
```
gateway verifies JWT → farmerId → diagnosis_id (uuid) → [diagnoses row owned by farmer ∥ sign cached MP3]
→ not owned: 404 → cached: signed URL (600 s) + hindi_summary
→ diagnosis < 25 s old: poll every 0.7 s for the background job's file
→ else prepareBolo on demand → signed URL      (any failure → 503; the diagnosis itself is never touched)
```
The app's TypeScript copy of the result type is `src/types/diagnosis.ts`. It mirrors `_shared/diagnosis.ts`; keep the two in step.

## Server side: data
- Database: farmers, diagnoses, follow_ups, chat_messages, engagement_events. RLS on all five.
- Storage: private buckets diagnosis-images and bolo-audio. Farmers may only SELECT their own folder (for signed URLs). Writes come from the service role only.
- Sign-up trigger: `auth.users` insert → `public.handle_new_auth_user()` → farmers row
- Secrets: GEMINI_API_KEY, SARVAM_API_KEY, OPENWEATHER_API_KEY

## Changed in the latest session (in-app follow-up loop)
- Home: follow-up/check-in-card → follow-up/api.fetchDueFollowUp (RLS: newest due pending crop follow-up + its diagnosis)
  - Answer → follow-up/api.answerFollowUp → POST functions/v1/follow-up-answer
  - Server: owner + due + not answered → status responded, farmer_response, treatment_applied, responded_at → engagement_events loop_completed
- scripts/metrics.mjs reads the §4A numbers

## Changed in Phase 6
- Advice tab: (tabs)/chat.tsx → chat/api.fetchChatHistory (RLS select, oldest first)
- Send: chat/api.sendChatMessage → POST functions/v1/chat (one retry on 503)
  - Server: validate → rate check (30/h) → last 10 messages as context → gemini.generate (20 s, hedge 6 s) → insert question + answer (service role) → reply

## Changed in Phase 5
- Home: weather/weather-card → hooks/use-device-location (granted permission only) → weather/api.fetchWeather → POST functions/v1/weather (OpenWeather, key server-side) → weather/advice.adviceFor (plain rules)
- Soil: Home soil card → pickAndDiagnose(kind 'soil') → diagnosis/camera?kind=soil → diagnosis/api.diagnosePhoto (x-ks-kind: soil) → diagnose-crop → _shared/soil.analyseSoil → type 'soil' row → /diagnosis/[id] → SoilResult → BoloButton + NearbyShops(product)
- Bolo summary prompt is per kind (_shared/bolo.ts)
- Soil Health Card: Home green button → /soil-card → expo-image-picker → diagnosis/api.prepareImage → soil-card/api.readSoilCard → POST functions/v1/read-soil-card (Gemini OCR, transcribe only) → confirm/correct → saveSoilCard (AsyncStorage) → saved view with fixed-text meanings

## Changed in Phase 4
- Shops tab and the "nearby shops" section on crop results (features/shops/*, lib/haversine.ts). The Haversine formula exists once; find-shops.ts is its only caller.
- expo-location added (when-in-use only)
- src/data/shops.json is rebuilt by scripts/clean_shops.py
  - Coordinates come only from Nominatim-verified Plus Codes (cache: scripts/data/nominatim_cache.json)
  - Plus 5 OpenStreetMap shops (scripts/data/osm_shops.json)

## Changed in Phase 3
- New Edge Function `bolo` and the bolo-audio bucket; diagnose-crop now voices the summary in the background
- Gemini calls moved into _shared/gemini.ts: pinned models, hedged after 3.5 s, 9 s deadline. HTTP helpers in _shared/http.ts.
- Result screen gains the Bolo button (features/voice/*)
- The app retries a diagnosis once on 503
- Native prerequisites for the EAS development build: expo-dev-client, expo-asset, expo-audio plugin options; .easignore
