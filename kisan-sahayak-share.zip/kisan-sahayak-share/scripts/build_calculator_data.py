"""Build the calculator's official data files from the government PDFs (D-41).

Sources (downloaded to /tmp/ks_sources, never stored in the project):
- CIB&RC "Major Uses of Pesticides" as on 31.03.2026 (ppqs.gov.in): insecticides, fungicides, herbicides, bio-insecticides.
- ICAR-IISS "District-wise General Fertilizer Recommendations" (June 2026): Chhattisgarh table.

Output: src/data/pesticide-register.json, src/data/fertilizer-gfr-cg.json
Run:    /tmp/ksvenv/bin/python scripts/build_calculator_data.py   (needs pdfplumber; proxy CA bundle for downloads)
"""
import json
import os
import re
import ssl
import sys
import urllib.request
from collections import Counter

import pdfplumber

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC_DIR = '/tmp/ks_sources'
PPQS = 'https://ppqs.gov.in/sites/default/files/'
REGISTER = [
    ('insecticide', 'updated_mup_insecticide_as_on_31.03.2026_c.pdf'),
    ('fungicide', '2._chemical_mup_fungicide_as_on_31.03.2026_0.pdf'),
    ('herbicide', '4._herbicides_mup_as_on_31.03.2026.pdf'),
    ('bio-insecticide', '6._mup_bio_insecticide_31.03.2026.pdf'),
]
GFR_URL = 'https://icar-ciah.org/include/pdf/advisory/2026/jun_2026/GFR_district_wise_03062026.pdf'

# Farm crops grown in Chhattisgarh. A register cell can name several crops ("Wheat, Gram").
CROPS = {
    'rice': r'\brice\b|\bpaddy\b',
    'wheat': r'\bwheat\b',
    'maize': r'\bmaize\b|\bcorn\b',
    'arhar': r'red ?gram|pigeon ?pea|\barhar\b',
    'chana': r'chick ?pea|bengal ?gram|^gram$',
    'moong': r'green ?gram|\bmoong\b|\bmung\b',
    'urad': r'black ?gram|\burd\b|\burid\b|\burad\b',
    'pea': r'^(green )?peas?$',
    'soybean': r'soya? ?bean',
    'groundnut': r'ground ?nut',
    'mustard': r'mustard|rapeseed',
    'sesame': r'sesam',
    'sugarcane': r'sugarcane',
    'cotton': r'\bcotton\b',
    'tomato': r'tomato',
    'brinjal': r'brinjal',
    'chilli': r'\bchil+(i|y|ies|is)\b',
    'okra': r'okra|bhindi',
    'cabbage': r'cabbage',
    'cauliflower': r'cauliflower',
    'potato': r'potato',
    'onion': r'onion',
    'cucumber': r'cucumber',
    'bitter_gourd': r'bitter ?gourd',
    'bottle_gourd': r'bottle ?gourd',
    'mango': r'\bmango',
    'banana': r'banana',
}
LIQUID = {'EC', 'SC', 'SL', 'EW', 'OD', 'CS', 'ME', 'SE', 'ZC', 'AS', 'LF', 'L', 'FS', 'DC', 'ZW', 'SPE'}
SOLID = {'WP', 'WG', 'WDG', 'DF', 'SP', 'SG', 'GR', 'DP', 'DS', 'WS', 'TB', 'CG'}
NUM = r'(\d+(?:\.\d+)?)'
AMOUNT = re.compile(rf'^\(?{NUM}\s*(?:(?:-|–|—|to)\s*{NUM})?\s*(ml|gm|g|kg|lit|liter|litre|ltrs|ltr|l)?\.?\s*(?:/\s*ha)?\)?$', re.I)


def download(url, name):
    os.makedirs(SRC_DIR, exist_ok=True)
    path = os.path.join(SRC_DIR, name)
    if not os.path.exists(path):
        ctx = ssl.create_default_context(cafile=os.path.expanduser('~/.certs/ca-bundle-with-shell.pem'))
        with urllib.request.urlopen(url, context=ctx) as r, open(path, 'wb') as f:
            f.write(r.read())
    return path


def clean(cell):
    return re.sub(r'\s+', ' ', (cell or '').replace('`', '')).strip()


def crops_in(text):
    parts = [p.strip().lower() for p in re.split(r'[,&/]|\band\b', re.sub(r'\(.*?\)', lambda m: ',' + m.group(0)[1:-1] + ',', text))]
    found = {cid for cid, rx in CROPS.items() for p in parts + [text.lower()] if p and re.search(rx, p)}
    return sorted(found)


def form_code(name):
    codes = re.findall(r'\b([A-Z]{1,3})\b', name.replace('%', ' '))
    for c in reversed(codes):
        if c in LIQUID or c in SOLID:
            return c
    return None


def amount(text, form_unit):
    """'50 –100' → (50, 100, unit) per ha, kg/L converted to g/ml. None when it isn't a clear per-ha amount."""
    m = AMOUNT.match(text)
    if not m:
        return None
    lo, hi, unit = float(m.group(1)), float(m.group(2) or m.group(1)), (m.group(3) or '').lower()
    if unit in ('kg', 'lit', 'liter', 'litre', 'ltrs', 'ltr', 'l'):
        lo, hi = lo * 1000, hi * 1000
    elif lo < 10:
        return None  # e.g. "3.0" (L or ml?) or a per-tree figure: ambiguous, so the farmer uses the label instead.
    # The bottle is in ml for liquids even where the register prints "gm" for an EC/SC.
    unit = form_unit or ('g' if unit in ('kg', 'g', 'gm') else 'ml' if unit else None)
    if not unit or lo > hi or hi > 20000:
        return None
    return lo, hi, unit


def water(text):
    m = AMOUNT.match(text)
    if not m or (m.group(3) or 'l').lower()[0] != 'l':
        return None
    lo, hi = float(m.group(1)), float(m.group(2) or m.group(1))
    return (lo, hi) if 50 <= lo <= hi <= 2000 else None


def wait_days(text):
    m = re.match(r'^(\d+)\s*(days?)?\.?$', text, re.I)
    return int(m.group(1)) if m else None


def parse_register():
    products, stats = [], Counter()
    for kind, name in REGISTER:
        path = download(PPQS + name, name)
        current, last = None, None
        with pdfplumber.open(path) as pdf:
            for page in pdf.pages:
                for table in page.extract_tables():
                    for raw in table:
                        cells = list(raw)
                        if len(cells) > 6:
                            # Merged cells come back as None padding; column 0 stays (blank crop = same crop as above).
                            cells = cells[:1] + [x for x in cells[1:] if x is not None]
                            if len(cells) == 1:
                                cells += [None] * 5
                        if len(cells) != 6:
                            stats['skip_shape'] += 1
                            continue
                        c = [clean(x) for x in cells]
                        if c[0] and not any(c[1:]):
                            if '%' in c[0]:
                                current = {'name': c[0], 'kind': kind, 'form': form_code(c[0]), 'rows': []}
                                products.append(current)
                            last = None
                            continue
                        if current is None:
                            continue
                        if not c[0] and c[1] and not any(c[2:]) and last:
                            last['pest'] += ' ' + c[1]  # pest name split across a page break
                            continue
                        crop_text = c[0] or (last['crop'] if last else '')
                        ids = crops_in(crop_text)
                        stats['rows'] += 1
                        if not ids:
                            stats['other_crop'] += 1
                            last = {'crop': crop_text, 'pest': c[1]}
                            continue
                        form_unit = 'ml' if current['form'] in LIQUID else 'g' if current['form'] in SOLID else None
                        dose, w = amount(c[3], form_unit), water(c[4])
                        row = {'crops': ids, 'crop': crop_text, 'pest': c[1], 'wait': wait_days(c[5])}
                        last = row
                        if not dose or not w:
                            stats['not_spray_or_unclear'] += 1
                            continue
                        row.update(dose=[round(dose[0], 1), round(dose[1], 1)], unit=dose[2], water=[w[0], w[1]])
                        current['rows'].append(row)
                        stats['kept'] += 1
    products = [p for p in products if p['rows']]
    for p in products:
        for r in p['rows']:
            r['pest'] = r['pest'].strip()
    return products, stats


DISTRICTS_IN_APP = [
    'Balod', 'Baloda Bazar', 'Balrampur', 'Bastar', 'Bemetara', 'Bijapur', 'Bilaspur', 'Dantewada', 'Dhamtari', 'Durg',
    'Gariaband', 'Gaurela-Pendra-Marwahi', 'Janjgir-Champa', 'Jashpur', 'Kabirdham', 'Kanker',
    'Khairagarh-Chhuikhadan-Gandai', 'Kondagaon', 'Korba', 'Koriya', 'Mahasamund', 'Manendragarh-Chirmiri-Bharatpur',
    'Mohla-Manpur-Ambagarh Chowki', 'Mungeli', 'Narayanpur', 'Raigarh', 'Raipur', 'Rajnandgaon', 'Sakti',
    'Sarangarh-Bilaigarh', 'Sukma', 'Surajpur', 'Surguja',
]


def parse_gfr():
    path = download(GFR_URL, 'GFR_district_wise_03062026.pdf')
    rows, earlier = [], None
    with pdfplumber.open(path) as pdf:
        for i in (11, 12):  # Chhattisgarh is on pages 12–13
            for table in pdf.pages[i].extract_tables():
                head = clean(table[0][2]) if len(table[0]) > 2 else ''
                if i == 11 and 'Rice' in head:
                    earlier = [[int(x) for x in re.findall(r'\d+', clean(table[0][j]))] for j in (2, 5, 8)]
                for r in table:
                    if len(r) == 11 and (r[0] or '').strip().isdigit() and len(rows) < 33:
                        rows.append([clean(r[1])] + [int(x) for x in r[2:]])
    assert len(rows) == 33 and earlier, (len(rows), earlier)
    districts = {}
    for app_name, r in zip(DISTRICTS_IN_APP, rows):
        assert app_name[:3].lower() == r[0][:3].lower(), (app_name, r[0])  # same order in both lists (Koriya = Korea)
        districts[app_name] = {'rice': r[1:4], 'wheat': r[4:7], 'maize': r[7:10]}
    return {
        'source': 'ICAR-IISS Bhopal, District-wise General Fertilizer Recommendations for Major Crops in India (June 2026), Chhattisgarh. kg/ha N:P2O5:K2O.',
        'earlier': {'rice': earlier[0], 'wheat': earlier[1], 'maize': earlier[2]},
        'districts': districts,
    }


def main():
    products, stats = parse_register()
    register = {
        'source': 'CIB&RC, Directorate of Plant Protection, Quarantine & Storage — Major Uses of Pesticides (registered under the Insecticides Act, 1968), as on 31.03.2026. Spray uses only; dose = formulation per ha, water = litres per ha.',
        'products': products,
    }
    with open(os.path.join(ROOT, 'src/data/pesticide-register.json'), 'w') as f:
        json.dump(register, f, ensure_ascii=False, separators=(',', ':'))
    gfr = parse_gfr()
    with open(os.path.join(ROOT, 'src/data/fertilizer-gfr-cg.json'), 'w') as f:
        json.dump(gfr, f, ensure_ascii=False, indent=1)
    by_crop = Counter(c for p in products for r in p['rows'] for c in r['crops'])
    print('register:', dict(stats), 'products:', len(products), file=sys.stderr)
    print('rows per crop:', dict(by_crop.most_common()), file=sys.stderr)
    print('gfr districts:', len(gfr['districts']), 'earlier:', gfr['earlier'], file=sys.stderr)


if __name__ == '__main__':
    main()
