// Shared request helpers for app-facing Edge Functions (both deployed with verify_jwt = true).
import { decodeBase64Url } from 'jsr:@std/encoding@1';
import { createClient } from 'npm:@supabase/supabase-js@2';

export const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-ks-language, x-ks-kind, x-region',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

export const fail = (status: number, error: string) => Response.json({ error }, { status, headers: cors });

// The gateway has already verified the JWT signature (verify_jwt = true), so only read the claims.
export function signedInFarmer(req: Request): string | null {
  try {
    const token = req.headers.get('Authorization')?.replace(/^Bearer\s+/i, '') ?? '';
    const claims = JSON.parse(new TextDecoder().decode(decodeBase64Url(token.split('.')[1] ?? '')));
    return claims.role === 'authenticated' && typeof claims.sub === 'string' ? claims.sub : null;
  } catch {
    return null;
  }
}

export const adminClient = () =>
  createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!, { auth: { persistSession: false } });
