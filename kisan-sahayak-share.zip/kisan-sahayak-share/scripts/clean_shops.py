#!/usr/bin/env python3
"""Clean the raw Krishi Kendra CSV into src/data/shops.json (D-12).

Usage: python3 scripts/clean_shops.py <raw.csv> [src/data/shops.json]

- Drops rows that are clearly not agri-input shops (pest-control services, tractor dealers, pet shops ...),
  and rows whose address PIN is outside Chhattisgarh (49xxxx).
- The CSV latitude/longitude are NOT shop locations (D-31: most are 10-45 km off — they are search origins).
  A shop gets coordinates only from the Plus Code in its address (scripts/plus_codes.py), only when no other
  listing carries the same code (shared codes are area placeholders), and only when
  OpenStreetMap Nominatim confirms that point is in Chhattisgarh and matches the address (town or PIN) or
  the shop's district. Otherwise latitude/longitude are null, so distance code cannot use them; Directions
  falls back to name + address (D-12). Nominatim answers are cached in scripts/data/nominatim_cache.json,
  so re-runs are offline; a cache miss is fetched at 1 request/second (Nominatim usage policy).
- Phones normalised to +91XXXXXXXXXX.
- District normalised to the 33 names in src/constants/districts.ts. Verified location's district wins;
  else the CSV label (the town the shop was searched under, e.g. Bhilai, Jagdalpur), mapped via
  DISTRICT_ALIASES; an unknown label stops the script. A blank label is read from the address.
- Appends the curated OpenStreetMap shops in scripts/data/osm_shops.json (source 'osm', ODbL — the app must
  show "© OpenStreetMap contributors"). They were checked by hand against the CSV: no duplicates.
"""
from __future__ import annotations  # system python is 3.9; allows `str | None`

import csv
import json
import os
import re
import ssl
import sys
import time
import urllib.request
from collections import Counter
from pathlib import Path

from plus_codes import recover_short

NOT_A_SHOP = re.compile(
    r'pest ?control|termite|pest solution|antipest|cleaning|plumber|water ?proof|hygiene|home solution|'
    r'\bpets?\b|pet stop|dogs?\b|zoo|zoological|collector|tractor|eicher|mahindra|massey|sonalika|swaraj|'
    r'auto cent|sports|gym|rice mill|pulses|dairy|poultry|fruit market|flower|lotus|waterlily|herbal|'
    r'ayurved|provision|godown|superstore|jan aushadhi|nursery|narsary|gamle|garden|vatika|mushroom|'
    r'hospital|clinic|school|college|bank|hotel|restaurant|dhaba|cafe|\bsalon\b|mobile|electronics|furniture|'
    r'garment|jewel|office|collectorate|'
    # Second pass (Phase 4 review of every name without an agri word):
    r'pest ?free|best control|clean ?n|cleanwale|\bsqc\b|finance|gold loan|ice ?cream|landscape|aquarium|'
    r'veg[ei]table|\bmarket\b|(?<!baloda )\bbazaa?r\b|\bmart\b|\bmall\b|indane|gas service|panchayat|police|crpf|homestay|'
    r'palace|coaching|classes|kidz|book depot|furnishing|medicose|medical|kubota|thresher|showroom|snake|trctor|powertrac|'
    r'painting|interior|engineering|rewinding|electricals|submersible|petrol|pump|kitchen|meditation|'
    r'dhyan|dry fruit|daily needs|milk|amul|broiler|\begg\b|chicken|goat|fish|hatchery|juice|nariyal|\bbhel\b|'
    r'passport|aadhaa?r seva|adhar seva|lok se[vw]a|choice cent|kiosk|grahak se[vw]a|punarwas|gothan|gauthan|gaushala|'
    r'cycle store|steel|\bplants?\b|plant seller|gamla|nursary|\bcomplex\b|nikunj|nature park|kanji house|'
    r'\bnaka\b|godam|development board|panchg[a]?vya|computer|utilities|home ops|uddyaan|udyaan|'
    r'गौठान|गौशाला|उद्यान|महाविद्यालय|जिला पंचायत|कुकरी',
    re.I,
)
# Names that are only a place (map pins, not shops), or otherwise not input shops, found in the same review.
NOT_A_SHOP_NAMES = {
    'mahasamund chhattisgarh', 'durg chhattisgarh', 'manendragarh', 'gamawada', 'kakdagaon', 'pendra rod',
    'pandeathgaon', 'khudmudi', 'dongipara kondagona chattisgarh', 'yashubandhewala', 'dukan ◐.̃◐',
    'rooted by aruna', 'wall street landscape', 'success point coaching', 'rain revive innovations',
    'chhaya applications', 'dmt king',
}
# Names that are unmistakably input shops win over NOT_A_SHOP (e.g. "Prgti krisi seva kendra ... bank, bij, khad").
# A bare "seva kendra" is NOT enough: Lok/Aadhar/Passport Seva Kendras are government service counters.
REAL_SHOP = re.compile(
    r'kri?u?s?shi\s+(seva\s+|sewa\s+)?kendra|kri?si\s+(seva\s+|sewa\s+)?kendra|(kisa+n|krishak)\s+se[vw]a|'
    r'agro (agency|clinic|product)|agri ?clinic|agree clinic|bio agro|\bkhad\b|\bbij\b|\bbeej\b|कृषि (सेवा )?केन्?द्र|'
    r'(kri?shi|kisa+n|agro) (bazaa?r|mart|mall)|fertili[sz]er',
    re.I,
)
# Chhattisgarh bounding box. Rectangular, so it also admits slivers of neighbouring states.
LAT_MIN, LAT_MAX, LNG_MIN, LNG_MAX = 17.78, 24.10, 80.24, 84.40

ROOT = Path(__file__).resolve().parent.parent
CANONICAL = re.findall(r"en: '([^']+)'", (ROOT / 'src/constants/districts.ts').read_text(encoding='utf-8'))
# Town / old-district name -> canonical district. Used for CSV labels and for reading addresses.
DISTRICT_ALIASES = {
    'Gaurela': 'Gaurela-Pendra-Marwahi', 'Pendra': 'Gaurela-Pendra-Marwahi', 'Marwahi': 'Gaurela-Pendra-Marwahi',
    'Janjgir': 'Janjgir-Champa', 'Champa': 'Janjgir-Champa',
    'Mohla': 'Mohla-Manpur-Ambagarh Chowki', 'Manpur': 'Mohla-Manpur-Ambagarh Chowki',
    'Khairagarh': 'Khairagarh-Chhuikhadan-Gandai', 'Chhuikhadan': 'Khairagarh-Chhuikhadan-Gandai',
    'Manendragarh': 'Manendragarh-Chirmiri-Bharatpur', 'Chirmiri': 'Manendragarh-Chirmiri-Bharatpur',
    'Sarangarh': 'Sarangarh-Bilaigarh', 'Bilaigarh': 'Sarangarh-Bilaigarh',
    'Jagdalpur': 'Bastar', 'Ambikapur': 'Surguja', 'Bhilai': 'Durg', 'Kawardha': 'Kabirdham',
    'Bhatapara': 'Baloda Bazar', 'Dongargarh': 'Rajnandgaon', 'Uttar Bastar Kanker': 'Kanker',
    'Dakshin Bastar Dantewada': 'Dantewada', 'Baikunthpur': 'Koriya',
    # Nominatim's spellings of district names
    'Manendragarh-Chirimiri-Bharatpur': 'Manendragarh-Chirmiri-Bharatpur', 'Kabeerdham': 'Kabirdham',
    'Balodabazar-Bhatapara': 'Baloda Bazar', 'Baloda Bazar-Bhatapara': 'Baloda Bazar',
    'Janjgir Champa': 'Janjgir-Champa', 'Korea': 'Koriya', 'Sarguja': 'Surguja',
}
NAME_TO_DISTRICT = {**{d: d for d in CANONICAL}, **DISTRICT_ALIASES}
DISTRICT_IN_TEXT = re.compile(
    r'\b(' + '|'.join(re.escape(n) for n in sorted(NAME_TO_DISTRICT, key=len, reverse=True)) + r')\b', re.I
)


def district_from_label(label: str) -> str | None:
    if not label:
        return None
    if label not in NAME_TO_DISTRICT:
        sys.exit(f'unknown district label in CSV: {label!r} - add it to DISTRICT_ALIASES')
    return NAME_TO_DISTRICT[label]


def district_from_address(address: str) -> str | None:
    # Addresses end "..., <town/district>, Chhattisgarh <PIN>", so the last match is the most specific.
    matches = DISTRICT_IN_TEXT.findall(address)
    if not matches:
        return None
    last = matches[-1].lower()
    return next(d for n, d in NAME_TO_DISTRICT.items() if n.lower() == last)


def normalise_phone(raw: str) -> str | None:
    digits = re.sub(r'\D', '', raw)
    if digits.startswith('91') and len(digits) == 12:
        digits = digits[2:]
    digits = digits.lstrip('0')
    return f'+91{digits}' if len(digits) == 10 else None


PLUS_CODE = re.compile(r'(?<![\w+])([23456789CFGHJMPQRVWX]{4}\+[23456789CFGHJMPQRVWX]{2,3})(?![\w+])')
CACHE_FILE = ROOT / 'scripts/data/nominatim_cache.json'
USER_AGENT = 'KisanSahayakDev/0.1 (one-time data prep for an agri advisory MVP)'


def reverse_geocode(lat: float, lng: float, cache: dict) -> dict:
    key = f'{lat:.6f},{lng:.6f}'
    if key not in cache:
        time.sleep(1.1)  # Nominatim policy: max 1 request per second
        url = f'https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat={lat:.6f}&lon={lng:.6f}&zoom=14&accept-language=en'
        ca = os.environ.get('SSL_CERT_FILE')
        ctx = ssl.create_default_context(cafile=ca) if ca else None
        with urllib.request.urlopen(urllib.request.Request(url, headers={'User-Agent': USER_AGENT}), context=ctx, timeout=30) as resp:
            cache[key] = json.load(resp).get('address', {})
        CACHE_FILE.write_text(json.dumps(cache, ensure_ascii=False, indent=0, sort_keys=True), encoding='utf-8')
    return cache[key]


def confirms(place: dict, address: str, pin: str | None, district: str | None) -> bool:
    if place.get('state') != 'Chhattisgarh':
        return False
    names = (place.get(k) for k in ('village', 'hamlet', 'town', 'city', 'suburb', 'neighbourhood', 'municipality', 'county'))
    lowered = address.lower()
    if any(n and len(n) >= 4 and re.sub(r' tahsil$', '', n.lower()) in lowered for n in names):
        return True
    if pin and place.get('postcode') == pin:
        return True
    return district is not None and NAME_TO_DISTRICT.get(place.get('state_district', '')) == district


def locate(address: str, ref_lat: float, ref_lng: float, pin: str | None, district: str | None, cache: dict):
    """(lat, lng, district) from the address's Plus Code, verified by Nominatim; else None.
    A short code repeats every 1 degree; the CSV point picks the nearest copy, and when that copy doesn't
    verify (the CSV point was over half a degree off), the 8 neighbouring copies are tried."""
    m = PLUS_CODE.search(address)
    if not m:
        return None
    lat0, lng0 = recover_short(m.group(1), ref_lat, ref_lng)
    for dlat, dlng in [(0, 0), (1, 0), (-1, 0), (0, 1), (0, -1), (1, 1), (1, -1), (-1, 1), (-1, -1)]:
        lat, lng = lat0 + dlat, lng0 + dlng
        if not (LAT_MIN <= lat <= LAT_MAX and LNG_MIN <= lng <= LNG_MAX):
            continue
        place = reverse_geocode(lat, lng, cache)
        if confirms(place, address, pin, district):
            return round(lat, 6), round(lng, 6), NAME_TO_DISTRICT.get(place.get('state_district', ''))
    return None


def main() -> None:
    src = Path(sys.argv[1])
    out = Path(sys.argv[2] if len(sys.argv) > 2 else 'src/data/shops.json')
    rows = list(csv.DictReader(src.open(encoding='utf-8-sig')))
    cache = json.loads(CACHE_FILE.read_text(encoding='utf-8')) if CACHE_FILE.exists() else {}
    # One code on several listings (8 shops from different villages on '8M3G+M89') is an area placeholder.
    code_count = Counter(m.group(1) for r in rows if (m := PLUS_CODE.search(r['address'])))
    assert len(CANONICAL) == 33, f'expected 33 districts in districts.ts, found {len(CANONICAL)}'

    shops, dropped, out_of_state, district_fixed = [], [], [], 0
    for r in rows:
        name = ' '.join(r['name'].split())
        if (NOT_A_SHOP.search(name) and not REAL_SHOP.search(name)) or name.lower() in NOT_A_SHOP_NAMES:
            dropped.append(name)
            continue
        address = ' '.join(r['address'].split())
        pins = re.findall(r'\b(\d{6})\b', address)
        pin = pins[-1] if pins else None
        if pin and not pin.startswith('49'):
            out_of_state.append(name)
            continue
        district = district_from_label(r['district'].strip()) or district_from_address(address)
        code = PLUS_CODE.search(address)
        unique_code = code is not None and code_count[code.group(1)] == 1
        found = locate(address, float(r['latitude']), float(r['longitude']), pin, district, cache) if unique_code else None
        if found and found[2] and found[2] != district:
            district, district_fixed = found[2], district_fixed + 1
        rating = r['rating'].strip()
        shops.append({
            'id': f'shop-{len(shops) + 1:04d}',
            'source': 'csv',
            'name': name,
            'address': address,
            'district': district,
            'phone': normalise_phone(r['phone']),
            'type': r['type'].strip(),
            'rating': float(rating) if rating else None,
            'latitude': found[0] if found else None,
            'longitude': found[1] if found else None,
        })

    osm = json.loads((ROOT / 'scripts/data/osm_shops.json').read_text(encoding='utf-8'))['shops']
    for o in osm:
        assert o['district'] in CANONICAL, o
        shops.append({
            'id': 'osm-' + o['osm'].replace('/', '-'),
            'source': 'osm',
            'name': o['name'],
            'address': o['address'],
            'district': o['district'],
            'phone': None,
            'type': o['type'],
            'rating': None,
            'latitude': o['latitude'],
            'longitude': o['longitude'],
        })

    out.write_text(json.dumps(shops, ensure_ascii=False, indent=1) + '\n', encoding='utf-8')

    with_coords = sum(1 for s in shops if s['latitude'] is not None)
    print(f'raw rows:            {len(rows)}')
    print(f'dropped (not shops): {len(dropped)}')
    print(f'dropped (PIN outside Chhattisgarh): {len(out_of_state)}')
    print(f'kept shops:          {len(shops)}  (csv {len(shops) - len(osm)} + osm {len(osm)})')
    print(f'  verified coords:   {with_coords}')
    print(f'  name+address only: {len(shops) - with_coords}')
    print(f'  with phone:        {sum(1 for s in shops if s["phone"])}')
    print(f'  with district:     {sum(1 for s in shops if s["district"])}  ({district_fixed} corrected from verified location)')
    print(f'wrote {out}')


if __name__ == '__main__':
    main()
