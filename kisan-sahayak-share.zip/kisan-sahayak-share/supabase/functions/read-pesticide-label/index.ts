// D-41: read WHICH product is in the farmer's hand (brand + composition as printed). The dose never comes from here:
// the app looks the composition up in the CIB&RC register, or the farmer types the label amount. The photo is not stored.
import { encodeBase64 } from 'jsr:@std/encoding@1';

import { sniffImageMime } from '../_shared/diagnosis.ts';
import { generate } from '../_shared/gemini.ts';
import { cors, fail, signedInFarmer } from '../_shared/http.ts';

const MAX_BYTES = 10 * 1024 * 1024;

const LABEL_SCHEMA = {
  type: 'object',
  properties: {
    is_pesticide_label: { type: 'boolean' },
    brand_name: { type: 'string' },
    composition: { type: 'string' },
  },
  required: ['is_pesticide_label', 'brand_name', 'composition'],
  propertyOrdering: ['is_pesticide_label', 'brand_name', 'composition'],
} as const;

const INSTRUCTION = `You read a photo of an Indian pesticide, fungicide or weedicide bottle, packet or label. You are a careful transcriber, not an adviser.
Rules — follow all of them:
1. composition: the technical (common chemical) name or names with their strength and formulation code, exactly as printed in English, for example "Chlorantraniliprole 18.5% w/w SC" or "Azoxystrobin 18.2% + Difenoconazole 11.4% w/v SC". If it is printed only in Hindi, write the chemical names in English letters with the same numbers. "" if you cannot read it clearly.
2. brand_name: the trade name as printed, "" if none.
3. Never copy or invent a dose, quantity per acre or per litre, price, crop or pest. Never guess a missing strength or code — leave it out.
4. is_pesticide_label: false if the photo is not a crop-protection product label (for example fertiliser, seed, medicine for people or animals); then return "" for both strings.`;

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  if (req.method !== 'POST') return fail(405, 'method_not_allowed');
  if (!signedInFarmer(req)) return fail(401, 'unauthorized');
  if (Number(req.headers.get('content-length') ?? 0) > MAX_BYTES) return fail(413, 'image_too_large');
  const bytes = new Uint8Array(await req.arrayBuffer());
  if (bytes.byteLength > MAX_BYTES) return fail(413, 'image_too_large');
  const mimeType = sniffImageMime(bytes);
  if (!mimeType) return fail(415, 'unsupported_image');

  try {
    const { text, model } = await generate({
      systemInstruction: { parts: [{ text: INSTRUCTION }] },
      contents: [{ role: 'user', parts: [{ inlineData: { mimeType, data: encodeBase64(bytes) } }, { text: 'Read this label.' }] }],
      generationConfig: { temperature: 0, responseMimeType: 'application/json', responseSchema: LABEL_SCHEMA, maxOutputTokens: 256 },
    });
    const label = JSON.parse(text);
    console.log(`read-pesticide-label: model=${model} label=${label.is_pesticide_label} composition=${label.composition ? 'yes' : 'no'}`);
    return Response.json(label, { headers: cors });
  } catch {
    return fail(503, 'ai_unavailable');
  }
});
