// D-41: arithmetic only. Every amount comes from an official table (CIB&RC, ICAR) or the farmer's own label.

export type AreaUnit = 'dismil' | 'acre' | 'ha';
export type Range = [number, number];

export const ACRES_PER_HA = 2.4711;

/** Chhattisgarh land records: 1 acre = 100 dismil (decimal). */
export function toAcres(value: number, unit: AreaUnit): number {
  return unit === 'dismil' ? value / 100 : unit === 'ha' ? value * ACRES_PER_HA : value;
}

export const perAcre = (perHa: Range): Range => [perHa[0] / ACRES_PER_HA, perHa[1] / ACRES_PER_HA];

export type SprayInput = {
  acres: number;
  tankLitres: number;
  waterPerAcre: number;
  dose: { basis: 'acre' | 'litre'; amount: Range };
};

export type SprayResult = { totalWater: number; tanks: number; perTank: Range; total: Range };

export function spray({ acres, tankLitres, waterPerAcre, dose }: SprayInput): SprayResult | null {
  if (!(acres > 0 && tankLitres > 0 && waterPerAcre > 0 && dose.amount[0] > 0 && dose.amount[1] >= dose.amount[0])) return null;
  const totalWater = acres * waterPerAcre;
  const scale = (f: number): Range => [dose.amount[0] * f, dose.amount[1] * f];
  return dose.basis === 'acre'
    ? { totalWater, tanks: Math.ceil(totalWater / tankLitres), perTank: scale(tankLitres / waterPerAcre), total: scale(acres) }
    : { totalWater, tanks: Math.ceil(totalWater / tankLitres), perTank: scale(tankLitres), total: scale(totalWater) };
}

// Nutrient content of the three government-priced fertilisers (Fertiliser Control Order grades).
export const FERTILISERS = {
  urea: { n: 0.46, p: 0, k: 0, bagKg: 45 },
  dap: { n: 0.18, p: 0.46, k: 0, bagKg: 50 },
  mop: { n: 0, p: 0, k: 0.6, bagKg: 50 },
} as const;
export type Fertiliser = keyof typeof FERTILISERS;
export type Kg = Record<Fertiliser, number>;

/** PIB, March 2026: urea ₹242/45 kg (neem-coated), DAP ₹1,350/50 kg, MOP average retail ₹1,710.54/50 kg. Farmer can edit. */
export const DEFAULT_BAG_PRICE: Record<Fertiliser, number> = { urea: 242, dap: 1350, mop: 1711 };

/** kg/ha N : P2O5 : K2O → kg of DAP (for P), MOP (for K) and urea (for the N that DAP doesn't give). */
export function fertiliserKg(npk: [number, number, number], acres: number): Kg {
  const ha = acres / ACRES_PER_HA;
  const dap = (npk[1] / FERTILISERS.dap.p) * ha;
  const urea = Math.max(0, npk[0] * ha - dap * FERTILISERS.dap.n) / FERTILISERS.urea.n;
  const mop = (npk[2] / FERTILISERS.mop.k) * ha;
  return { urea, dap, mop };
}

export const bags = (kg: number, f: Fertiliser) => kg / FERTILISERS[f].bagKg;

export function cost(kg: Kg, bagPrice: Record<Fertiliser, number>): number {
  return (Object.keys(kg) as Fertiliser[]).reduce((sum, f) => sum + bags(kg[f], f) * bagPrice[f], 0);
}

/** What the farmer usually puts (bags per acre) → kg for the whole field. */
export function usualKg(bagsPerAcre: Kg, acres: number): Kg {
  return { urea: bagsPerAcre.urea * FERTILISERS.urea.bagKg * acres, dap: bagsPerAcre.dap * FERTILISERS.dap.bagKg * acres, mop: bagsPerAcre.mop * FERTILISERS.mop.bagKg * acres };
}

/**
 * Per fertiliser, never netted: extra urea can't make up for too little DAP.
 * Saving = only the money spent ABOVE the recommendation; anything below it is listed as short. Under 0.1 bag counts as "about right".
 */
export function compareUsual(need: Kg, usual: Kg, bagPrice: Record<Fertiliser, number>) {
  const ferts = Object.keys(need) as Fertiliser[];
  const diffBags = Object.fromEntries(ferts.map((f) => [f, bags(usual[f] - need[f], f)])) as Kg;
  const over = ferts.filter((f) => diffBags[f] >= 0.1);
  const short = ferts.filter((f) => diffBags[f] <= -0.1);
  const excessRupees = over.reduce((sum, f) => sum + diffBags[f] * bagPrice[f], 0);
  return { diffBags, excessRupees, over, short };
}
