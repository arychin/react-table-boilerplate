"""Open Location Code ("Plus Code") decoding — the open algorithm published by Google under Apache-2.0
(github.com/google/open-location-code, spec: docs/specification.md). Only what clean_shops.py needs:
recover a short code like "33X2+V26" against a nearby reference point, and return its centre.
"""
from __future__ import annotations

ALPHABET = '23456789CFGHJMPQRVWX'
PAIR_RESOLUTIONS = [20.0, 1.0, 0.05, 0.0025, 0.000125]
GRID_ROWS, GRID_COLS = 5, 4


def _prefix(lat: float, lng: float, length: int) -> str:
    """First `length` characters (an even number, <= 4 here) of the full code containing the point."""
    lat, lng = lat + 90, lng + 180
    out = ''
    for res in PAIR_RESOLUTIONS[: length // 2]:
        out += ALPHABET[int(lat // res) % 20] + ALPHABET[int(lng // res) % 20]
        lat, lng = lat % res, lng % res
    return out


def _decode_full(code: str) -> tuple[float, float]:
    digits = code.replace('+', '').upper()
    lat, lng = -90.0, -180.0
    lat_res = lng_res = PAIR_RESOLUTIONS[0]
    for i, res in enumerate(PAIR_RESOLUTIONS):
        if 2 * i + 1 >= len(digits):
            break
        lat += ALPHABET.index(digits[2 * i]) * res
        lng += ALPHABET.index(digits[2 * i + 1]) * res
        lat_res = lng_res = res
    if len(digits) > 10:  # one grid refinement character
        lat_res, lng_res = lat_res / GRID_ROWS, lng_res / GRID_COLS
        n = ALPHABET.index(digits[10])
        lat += (n // GRID_COLS) * lat_res
        lng += (n % GRID_COLS) * lng_res
    return lat + lat_res / 2, lng + lng_res / 2


def recover_short(short: str, ref_lat: float, ref_lng: float) -> tuple[float, float]:
    """Centre of a short code (4 chars + '+' + 2-3 chars) taken as the copy nearest the reference point.
    Correct whenever the reference is within half a degree (~55 km) of the true place."""
    padding = 8 - short.index('+')
    resolution = 20.0 ** (2 - padding / 2)
    lat, lng = _decode_full(_prefix(ref_lat, ref_lng, padding) + short)
    half = resolution / 2
    if ref_lat + half < lat:
        lat -= resolution
    elif ref_lat - half > lat:
        lat += resolution
    if ref_lng + half < lng:
        lng -= resolution
    elif ref_lng - half > lng:
        lng += resolution
    return lat, lng
