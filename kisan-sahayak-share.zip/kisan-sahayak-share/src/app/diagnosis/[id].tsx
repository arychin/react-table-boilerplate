import { Image } from 'expo-image';
import { router, useLocalSearchParams } from 'expo-router';
import { useEffect, useState } from 'react';
import { ActivityIndicator, ScrollView, StyleSheet, Text, View } from 'react-native';

import { Button } from '@/components/ui/button';
import { Spacing } from '@/constants/theme';
import { useApp } from '@/features/auth/app-context';
import { fetchDiagnosis, signedImageUrl, type DiagnosisRow } from '@/features/diagnosis/api';
import { NearbyShops } from '@/features/shops/nearby-shops';
import { BoloButton } from '@/features/voice/bolo-button';
import { useTheme } from '@/hooks/use-theme';
import type { Diagnosis, SoilReport } from '@/types/diagnosis';

// Plan Phase 2 step 5 + Vision Brief §3.1, §3.11 (Should-I-Spray), §2.2 (honest uncertainty).
export default function DiagnosisResultScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const { t } = useApp();
  const theme = useTheme();
  const [row, setRow] = useState<(DiagnosisRow & { localUri?: string }) | null | undefined>(undefined);
  const [imageUri, setImageUri] = useState<string | number | null>(null);

  useEffect(() => {
    fetchDiagnosis(id).then(async (found) => {
      setRow(found);
      if (found) setImageUri(found.localUri ?? (await signedImageUrl(found.image_url)));
    });
  }, [id]);

  if (row === undefined) {
    return (
      <View style={[styles.center, { backgroundColor: theme.background }]}>
        <ActivityIndicator size="large" color={theme.primary} />
      </View>
    );
  }
  if (row === null) {
    return (
      <View style={[styles.center, { backgroundColor: theme.background }]}>
        <Text style={[styles.body, { color: theme.text }]}>{t.errDiagnose}</Text>
      </View>
    );
  }

  if (row.kind === 'soil') return <SoilResult id={row.id} report={row.diagnosis} imageUri={imageUri} />;

  const d = row.diagnosis;
  const unsure = d.confidence === 'low';
  const treatmentApplies = !unsure && d.spray_decision !== 'not_needed';
  return (
    <ScrollView style={{ backgroundColor: theme.background }} contentContainerStyle={styles.content}>
      {!!imageUri && <Image source={imageUri} style={styles.photo} contentFit="cover" accessibilityIgnoresInvertColors />}

      <View style={styles.header}>
        <Text style={[styles.crop, { color: theme.textSecondary }]}>{t.crop}: {d.crop_name}</Text>
        <Text style={[styles.disease, { color: theme.text }]} accessibilityRole="header">{d.disease_name}</Text>
        <View style={styles.badges}>
          {/* An unclear photo has no severity to grade. */}
          {!unsure && <Badge text={t.severity[d.severity]} tone={d.severity === 'low' ? 'ok' : d.severity === 'medium' ? 'warn' : 'bad'} />}
          <Badge text={`${t.confidenceLabel}: ${t.confidence[d.confidence]}`} tone={unsure ? 'warn' : 'neutral'} />
        </View>
      </View>

      <BoloButton diagnosisId={row.id} />

      {unsure && (
        <View style={[styles.banner, { backgroundColor: theme.warningBg }]}>
          <Text style={[styles.bannerText, { color: theme.warning }]}>{t.lowConfidence}</Text>
        </View>
      )}

      <SprayVerdict d={d} />

      <Section title={t.cause} body={d.cause} />
      <Section title={t.treatment} body={d.treatment} />
      {treatmentApplies && (
        <View style={[styles.note, { borderColor: theme.border }]}>
          <Text style={[styles.noteText, { color: theme.text }]}>{t.doseNote}</Text>
        </View>
      )}
      <ListSection title={t.steps} items={d.treatment_steps} numbered />
      {!!d.prevention_tips?.length && <ListSection title={t.prevention} items={d.prevention_tips} />}
      {!!d.organic_alternative && <Section title={t.organic} body={d.organic_alternative} />}
      {treatmentApplies && <NearbyShops />}

      <Text style={[styles.disclaimer, { color: theme.textSecondary }]}>{t.aiDisclaimer}</Text>
      <Button label={t.newPhoto} onPress={() => router.replace('/diagnosis/camera')} />
    </ScrollView>
  );
}

function SoilResult({ id, report: r, imageUri }: { id: string; report: SoilReport; imageUri: string | number | null }) {
  const { t } = useApp();
  const theme = useTheme();
  const unsure = r.confidence === 'low';
  const product = r.fertilisers[0]?.name;
  return (
    <ScrollView style={{ backgroundColor: theme.background }} contentContainerStyle={styles.content}>
      {!!imageUri && <Image source={imageUri} style={styles.photo} contentFit="cover" accessibilityIgnoresInvertColors />}

      <View style={styles.header}>
        <Text style={[styles.crop, { color: theme.textSecondary }]}>🧪 {t.soilTitle}</Text>
        <Text style={[styles.disease, { color: theme.text }]} accessibilityRole="header">{r.soil_type}</Text>
        <View style={styles.badges}>
          {!unsure && <Badge text={`${t.moistureLabel}: ${t.moisture[r.moisture]}`} tone={r.moisture === 'low' ? 'warn' : 'neutral'} />}
          <Badge text={`${t.confidenceLabel}: ${t.confidence[r.confidence]}`} tone={unsure ? 'warn' : 'neutral'} />
        </View>
      </View>

      <BoloButton diagnosisId={id} />

      {/* Vision Brief §2.2: a soil photo never replaces a lab test. */}
      <View style={[styles.banner, { backgroundColor: unsure ? theme.warningBg : theme.backgroundElement }]}>
        <Text style={[styles.bannerText, { color: unsure ? theme.warning : theme.text }]}>{unsure ? t.soilUnclear : t.soilVisualNote}</Text>
      </View>

      {!unsure && <Section title={t.soilSeen} body={r.observations} />}
      {!!r.possible_deficiencies.length && <ListSection title={t.soilPossible} items={r.possible_deficiencies} />}
      {!!r.fertilisers.length && (
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: theme.text }]}>{t.soilFertilisers}</Text>
          {r.fertilisers.map((f) => (
            <View key={f.name} style={styles.listRow}>
              <Text style={[styles.bullet, { color: theme.primary }]}>•</Text>
              <Text style={[styles.body, styles.listText, { color: theme.text }]}>
                <Text style={styles.strong}>{f.name}</Text> — {f.why}
              </Text>
            </View>
          ))}
          <View style={[styles.note, { borderColor: theme.border }]}>
            <Text style={[styles.noteText, { color: theme.text }]}>{t.soilDoseNote}</Text>
          </View>
        </View>
      )}
      <ListSection title={unsure ? t.steps : t.soilTips} items={r.improvement_tips} numbered={unsure} />
      {!unsure && product && <NearbyShops product={product} />}

      <Text style={[styles.disclaimer, { color: theme.textSecondary }]}>{t.aiDisclaimer}</Text>
      <Button label={t.newPhoto} onPress={() => router.replace({ pathname: '/diagnosis/camera', params: { kind: 'soil' } })} />
    </ScrollView>
  );
}

function SprayVerdict({ d }: { d: Diagnosis }) {
  const { t } = useApp();
  const theme = useTheme();
  const tone = {
    not_needed: { bg: theme.successBg, fg: theme.primary, icon: '🟢' },
    wait_and_watch: { bg: theme.warningBg, fg: theme.warning, icon: '🟡' },
    spray_recommended: { bg: theme.dangerBg, fg: theme.danger, icon: '🔴' },
  }[d.spray_decision];
  return (
    <View style={[styles.verdict, { backgroundColor: tone.bg }]} accessibilityRole="summary">
      <Text style={[styles.verdictTitle, { color: tone.fg }]}>{tone.icon} {t.spray[d.spray_decision]}</Text>
      <Text style={[styles.body, { color: theme.text }]}>{d.decision_reason}</Text>
      {/* Vision Brief §3.11: every Should-I-Spray result ends with this line. */}
      <Text style={[styles.confirm, { color: theme.text }]}>{t.sprayConfirm}</Text>
    </View>
  );
}

function Badge({ text, tone }: { text: string; tone: 'ok' | 'warn' | 'bad' | 'neutral' }) {
  const theme = useTheme();
  const colors = {
    ok: [theme.successBg, theme.primary],
    warn: [theme.warningBg, theme.warning],
    bad: [theme.dangerBg, theme.danger],
    neutral: [theme.backgroundElement, theme.text],
  }[tone];
  return (
    <View style={[styles.badge, { backgroundColor: colors[0] }]}>
      <Text style={[styles.badgeText, { color: colors[1] }]}>{text}</Text>
    </View>
  );
}

function Section({ title, body }: { title: string; body: string }) {
  const theme = useTheme();
  return (
    <View style={styles.section}>
      <Text style={[styles.sectionTitle, { color: theme.text }]}>{title}</Text>
      <Text style={[styles.body, { color: theme.text }]}>{body}</Text>
    </View>
  );
}

function ListSection({ title, items, numbered = false }: { title: string; items: string[]; numbered?: boolean }) {
  const theme = useTheme();
  return (
    <View style={styles.section}>
      <Text style={[styles.sectionTitle, { color: theme.text }]}>{title}</Text>
      {items.map((item, i) => (
        <View key={item} style={styles.listRow}>
          <Text style={[styles.bullet, { color: theme.primary }]}>{numbered ? `${i + 1}.` : '•'}</Text>
          <Text style={[styles.body, styles.listText, { color: theme.text }]}>{item}</Text>
        </View>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: Spacing.four },
  content: { padding: Spacing.four, gap: Spacing.three, paddingBottom: Spacing.six },
  photo: { width: '100%', aspectRatio: 4 / 3, borderRadius: Spacing.three },
  header: { gap: Spacing.one },
  crop: { fontSize: 16, fontWeight: '600' },
  disease: { fontSize: 26, fontWeight: '800', lineHeight: 34 },
  badges: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.two, marginTop: Spacing.one },
  badge: { borderRadius: Spacing.five, paddingHorizontal: Spacing.three, paddingVertical: Spacing.one },
  badgeText: { fontSize: 14, fontWeight: '700' },
  banner: { borderRadius: Spacing.three, padding: Spacing.three },
  bannerText: { fontSize: 16, fontWeight: '700', lineHeight: 24 },
  verdict: { borderRadius: Spacing.three, padding: Spacing.three, gap: Spacing.two },
  verdictTitle: { fontSize: 20, fontWeight: '800' },
  confirm: { fontSize: 15, fontWeight: '700', lineHeight: 22 },
  section: { gap: Spacing.one },
  sectionTitle: { fontSize: 18, fontWeight: '800' },
  body: { fontSize: 17, lineHeight: 26 },
  note: { borderWidth: 1.5, borderStyle: 'dashed', borderRadius: Spacing.three, padding: Spacing.three },
  noteText: { fontSize: 15, fontWeight: '600', lineHeight: 22 },
  listRow: { flexDirection: 'row', gap: Spacing.two },
  bullet: { fontSize: 17, fontWeight: '800', lineHeight: 26, minWidth: 18 },
  listText: { flex: 1 },
  strong: { fontWeight: '800' },
  disclaimer: { fontSize: 14, fontStyle: 'italic', textAlign: 'center' },
});
