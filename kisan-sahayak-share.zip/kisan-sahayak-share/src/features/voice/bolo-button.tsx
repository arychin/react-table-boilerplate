import { setAudioModeAsync, useAudioPlayer, useAudioPlayerStatus } from 'expo-audio';
import { useCallback, useEffect, useRef, useState } from 'react';
import { ActivityIndicator, Pressable, StyleSheet, Text, View } from 'react-native';

import { MinTouchTarget, Spacing } from '@/constants/theme';
import { useApp } from '@/features/auth/app-context';
import { fetchBolo, type BoloAudio } from '@/features/voice/api';
import { useTheme } from '@/hooks/use-theme';

const URL_REFRESH_MS = 8 * 60_000; // signed URLs live 10 min (TRD §8)

type State = 'preparing' | 'ready' | 'error';

// Vision Brief §3.8: tap once to hear the short Hindi summary, tap again to stop.
export function BoloButton({ diagnosisId }: { diagnosisId: string }) {
  const { t } = useApp();
  const theme = useTheme();
  const player = useAudioPlayer(null);
  const status = useAudioPlayerStatus(player);
  const [state, setState] = useState<State>('preparing');
  const [summary, setSummary] = useState<string | null>(null);
  const audio = useRef<BoloAudio | null>(null);

  const apply = useCallback((result: BoloAudio | null): boolean => {
    if (!result) {
      setState('error');
      return false;
    }
    audio.current = result;
    player.replace(typeof result.source === 'string' ? { uri: result.source } : result.source);
    setSummary(result.summary);
    setState('ready');
    return true;
  }, [player]);

  // Prepared while the farmer reads the result, so the first tap usually plays at once.
  useEffect(() => {
    setAudioModeAsync({ playsInSilentMode: true }).catch(() => {});
    fetchBolo(diagnosisId).then(apply);
  }, [diagnosisId, apply]);

  useEffect(() => {
    if (status.didJustFinish) player.seekTo(0);
  }, [status.didJustFinish, player]);

  const onPress = async () => {
    if (status.playing) {
      player.pause();
      await player.seekTo(0);
      return;
    }
    if (state === 'error' || !audio.current || Date.now() - audio.current.fetchedAt > URL_REFRESH_MS) {
      setState('preparing');
      if (!apply(await fetchBolo(diagnosisId))) return;
    }
    player.play();
  };

  const playing = status.playing;
  const label = playing ? t.boloStop : state === 'preparing' ? t.boloPreparing : state === 'error' ? t.boloError : t.boloListen;
  return (
    <View style={styles.wrap}>
      <Pressable
        accessibilityRole="button"
        accessibilityLabel={label}
        accessibilityState={{ busy: state === 'preparing', selected: playing }}
        disabled={state === 'preparing'}
        onPress={onPress}
        style={({ pressed }) => [
          styles.button,
          { backgroundColor: playing ? theme.danger : state === 'error' ? theme.warningBg : theme.primary },
          (pressed || state === 'preparing') && styles.dimmed,
        ]}>
        {state === 'preparing' && !playing ? (
          <ActivityIndicator color={theme.onPrimary} />
        ) : (
          <Text style={styles.icon}>{playing ? '■' : state === 'error' ? '↻' : '🔊'}</Text>
        )}
        <Text style={[styles.label, { color: state === 'error' && !playing ? theme.warning : theme.onPrimary }]}>{label}</Text>
      </Pressable>
      {summary && <Text style={[styles.summary, { color: theme.textSecondary }]}>“{summary}”</Text>}
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { gap: Spacing.two },
  button: {
    minHeight: MinTouchTarget + 8,
    borderRadius: Spacing.five,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: Spacing.two,
    paddingHorizontal: Spacing.four,
  },
  dimmed: { opacity: 0.75 },
  icon: { fontSize: 22, color: '#ffffff' },
  label: { fontSize: 19, fontWeight: '800' },
  summary: { fontSize: 15, lineHeight: 23, fontStyle: 'italic' },
});
