import { router } from 'expo-router';
import { useState } from 'react';
import { KeyboardAvoidingView, Platform, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { Button } from '@/components/ui/button';
import { LanguageToggle } from '@/components/ui/language-toggle';
import { MinTouchTarget, Spacing } from '@/constants/theme';
import { sendOtp, toE164 } from '@/features/auth/api';
import { useApp } from '@/features/auth/app-context';
import { DemoToggle } from '@/features/demo/demo-toggle';
import { useTheme } from '@/hooks/use-theme';

// Vision Brief §3.10: the first screen is the phone number — nothing else, no email ever.
export default function SignInScreen() {
  const { t } = useApp();
  const theme = useTheme();
  const [digits, setDigits] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [sending, setSending] = useState(false);

  async function onSend() {
    const phone = toE164(digits);
    if (!phone) {
      setError(t.errInvalidPhone);
      return;
    }
    setError(null);
    setSending(true);
    const { errorKey } = await sendOtp(phone);
    setSending(false);
    if (errorKey) {
      setError(t[errorKey]);
      return;
    }
    router.push({ pathname: '/verify', params: { phone } });
  }

  return (
    <SafeAreaView style={[styles.flex, { backgroundColor: theme.background }]}>
      <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
          <View style={styles.top}>
            <DemoToggle />
            <LanguageToggle />
          </View>

          <View style={styles.brand}>
            <Text style={[styles.appName, { color: theme.primary }]}>{t.appName}</Text>
            <Text style={[styles.tagline, { color: theme.textSecondary }]}>{t.tagline}</Text>
          </View>

          <Text style={[styles.title, { color: theme.text }]}>{t.phoneTitle}</Text>
          <Text style={[styles.hint, { color: theme.textSecondary }]}>{t.phoneHint}</Text>

          <View style={[styles.inputRow, { borderColor: error ? theme.danger : theme.border }]}>
            <Text style={[styles.prefix, { color: theme.text }]}>+91</Text>
            <TextInput
              value={digits}
              onChangeText={(value) => {
                setDigits(value.replace(/\D/g, '').slice(0, 10));
                setError(null);
              }}
              onSubmitEditing={onSend}
              placeholder={t.phonePlaceholder}
              placeholderTextColor={theme.textSecondary}
              keyboardType="phone-pad"
              textContentType="telephoneNumber"
              autoComplete="tel-national"
              maxLength={10}
              autoFocus
              accessibilityLabel={t.phoneTitle}
              style={[styles.input, { color: theme.text }]}
            />
          </View>
          {error && <Text style={[styles.error, { color: theme.danger }]}>{error}</Text>}

          <Button label={t.sendCode} onPress={onSend} loading={sending} disabled={digits.length !== 10} />
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  content: { flexGrow: 1, padding: Spacing.four, gap: Spacing.three },
  top: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: Spacing.two },
  brand: { alignItems: 'center', marginVertical: Spacing.five, gap: Spacing.one },
  appName: { fontSize: 36, fontWeight: '800' },
  tagline: { fontSize: 16, fontWeight: '500' },
  title: { fontSize: 24, fontWeight: '700' },
  hint: { fontSize: 16 },
  inputRow: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 2,
    borderRadius: Spacing.three,
    paddingHorizontal: Spacing.three,
    minHeight: MinTouchTarget + 8,
    gap: Spacing.two,
  },
  prefix: { fontSize: 22, fontWeight: '700' },
  input: { flex: 1, fontSize: 22, fontWeight: '600', letterSpacing: 1, paddingVertical: Spacing.two },
  error: { fontSize: 16, fontWeight: '600' },
});
