import AsyncStorage from '@react-native-async-storage/async-storage';

import { daysBetween, type CropPlan } from './feed';

// On the phone only: the feed needs no network, so it works in the field.
const key = (farmerId: string) => `ks.cropPlan.${farmerId}`;

/** Local calendar date, YYYY-MM-DD. Kept here so screens never call Date during render. */
export function todayIso(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

/** Day + month the farmer remembers → the most recent such date that isn't in the future, within the life of a crop. */
export function pastDate(dayOfMonth: number, month: number, today = todayIso(), maxDaysAgo = 200): string | null {
  if (!(dayOfMonth >= 1 && dayOfMonth <= 31 && month >= 1 && month <= 12)) return null;
  for (const year of [+today.slice(0, 4), +today.slice(0, 4) - 1]) {
    const d = new Date(Date.UTC(year, month - 1, dayOfMonth));
    if (d.getUTCMonth() !== month - 1) return null; // 31 June etc.
    const iso = d.toISOString().slice(0, 10);
    // A date typed in the future would otherwise become last year's; no crop here lasts 200 days.
    if (iso <= today) return daysBetween(iso, today) <= maxDaysAgo ? iso : null;
  }
  return null;
}

export async function loadPlan(farmerId: string): Promise<{ plan: CropPlan | null; today: string }> {
  const raw = await AsyncStorage.getItem(key(farmerId));
  return { plan: raw ? (JSON.parse(raw) as CropPlan) : null, today: todayIso() };
}

export async function savePlan(farmerId: string, plan: CropPlan | null): Promise<void> {
  if (plan) await AsyncStorage.setItem(key(farmerId), JSON.stringify(plan));
  else await AsyncStorage.removeItem(key(farmerId));
}

export async function markScouted(farmerId: string, plan: CropPlan): Promise<CropPlan> {
  const next = { ...plan, lastScouted: todayIso() };
  await savePlan(farmerId, next);
  return next;
}
