import { StyleSheet, Text, View } from 'react-native';

import { Spacing } from '@/constants/theme';
import { useApp } from '@/features/auth/app-context';
import { useTheme } from '@/hooks/use-theme';
import type { Kind } from '@/types/diagnosis';

export function PhotoTips({ kind = 'crop' }: { kind?: Kind }) {
  const { t } = useApp();
  const theme = useTheme();
  const tips = kind === 'soil' ? t.soilPhotoTips : t.photoTips;
  return (
    <View style={[styles.tips, { backgroundColor: theme.backgroundElement }]}>
      <Text style={[styles.title, { color: theme.text }]}>{t.photoTipsTitle}</Text>
      {tips.map((tip) => (
        <Text key={tip} style={[styles.tip, { color: theme.textSecondary }]}>• {tip}</Text>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  tips: { borderRadius: Spacing.three, padding: Spacing.three, gap: Spacing.one },
  title: { fontSize: 17, fontWeight: '700' },
  tip: { fontSize: 16 },
});
