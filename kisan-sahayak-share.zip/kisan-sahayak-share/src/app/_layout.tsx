import { DarkTheme, DefaultTheme, Stack, ThemeProvider } from 'expo-router';
import * as SplashScreen from 'expo-splash-screen';
import { useEffect } from 'react';
import { useColorScheme } from 'react-native';

import { AppProvider, useApp } from '@/features/auth/app-context';

SplashScreen.preventAutoHideAsync();

function RootNavigator() {
  const { ready, session, t } = useApp();

  useEffect(() => {
    if (ready) SplashScreen.hideAsync();
  }, [ready]);

  if (!ready) return null;

  const signedIn = !!session;
  return (
    <Stack screenOptions={{ headerShown: false }}>
      {/* TRD §6.6: phone → OTP → straight into the app; profile stays optional. */}
      <Stack.Protected guard={!signedIn}>
        <Stack.Screen name="sign-in" />
        <Stack.Screen name="verify" />
      </Stack.Protected>
      <Stack.Protected guard={signedIn}>
        <Stack.Screen name="(tabs)" />
        <Stack.Screen name="settings/account" options={{ headerShown: true, title: t.accountTitle }} />
        <Stack.Screen name="diagnosis/camera" options={{ headerShown: true, title: t.cropProblem }} />
        <Stack.Screen name="diagnosis/[id]" options={{ headerShown: true, title: t.appName }} />
        <Stack.Screen name="soil-card" options={{ headerShown: true, title: t.soilCardTitle }} />
        <Stack.Screen name="spray-calculator" options={{ headerShown: true, title: t.sprayTitle }} />
        <Stack.Screen name="fertilizer-calculator" options={{ headerShown: true, title: t.fertTitle }} />
        <Stack.Screen name="crop-plan" options={{ headerShown: true, title: t.planTitle }} />
      </Stack.Protected>
    </Stack>
  );
}

export default function RootLayout() {
  const colorScheme = useColorScheme();
  return (
    <ThemeProvider value={colorScheme === 'dark' ? DarkTheme : DefaultTheme}>
      <AppProvider>
        <RootNavigator />
      </AppProvider>
    </ThemeProvider>
  );
}
