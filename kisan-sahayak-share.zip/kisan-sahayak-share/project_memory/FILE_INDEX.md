# File Index

| Path | Status | Purpose | Date |
|---|---|---|---|
| project_memory/SESSION_LOG.md | created | Append-only chronological log of every action | 2026-09-29 |
| project_memory/ARCHITECTURE.md | created | System design (planned, from TRD v1) and how it changes over time | 2026-09-29 |
| project_memory/DECISIONS.md | created | Decisions, tradeoffs, open questions | 2026-09-29 |
| project_memory/CURRENT_STATE.md | created | Full snapshot of what exists now | 2026-09-29 |
| project_memory/TASK_TRACKER.md | created | Completed, blocked and pending tasks | 2026-09-29 |
| project_memory/FILE_INDEX.md | created | This file | 2026-09-29 |

## Phase 0 (2026-10-02)
| Path | Status | Purpose |
|---|---|---|
| package.json / package-lock.json | created (from template) | name kisan-sahayak; + supabase-js, AsyncStorage; dev: eslint, eslint-config-expo; reset-project script removed |
| app.json | created (from template) | Kisan Sahayak, com.kisansahayak.app, scheme kisansahayak, web output single, EAS owner/projectId |
| eas.json | created | development / preview / production profiles (Plan Phase 0) |
| tsconfig.json | created (template) | strict; `@/*` → src/* |
| eslint.config.js | created (by expo lint) | Expo ESLint config |
| expo-env.d.ts | generated | Expo types; needed for tsc |
| .gitignore | modified | added `.env` |
| .env | created | the 2 EXPO_PUBLIC_* values; git-ignored; chmod 600 |
| .env.example | created | all TRD §4 vars as placeholders |
| .vscode/ | created (template) | editor settings |
| assets/ | created (template, trimmed) | icons and splash only; example images removed |
| src/app/_layout.tsx | created | root Stack + ThemeProvider |
| src/app/(tabs)/_layout.tsx | created | Tabs: Home, Shops, Chat, History |
| src/app/(tabs)/index.tsx, shops.tsx, chat.tsx, history.tsx | created | placeholders (replaced by Phases 2, 4, 6, 2) |
| src/components/common/placeholder-screen.tsx | created | shared placeholder; delete once all 4 tabs are real |
| src/components/themed-text.tsx, themed-view.tsx | kept (template) | themed primitives |
| src/constants/theme.ts, src/global.css | kept (template) | colours, spacing, fonts |
| src/hooks/use-color-scheme.ts, use-theme.ts | kept (template) | theme hooks |
| src/hooks/use-color-scheme.web.ts | deleted | static-render helper; failed lint (D-15) |
| src/lib/supabase.ts | created | Supabase client singleton |
| src/features/{diagnosis,shops,chat,voice}, src/types, src/data, src/components/ui | created (empty) | TRD §3 structure |
| supabase/config.toml, supabase/.gitignore | created (supabase init) | Supabase project config |
| supabase/.temp/ | created (supabase link) | link metadata; no secrets (checked) |
| supabase/functions/ | created (empty) | key-check function created then deleted |
| scripts/load_secrets.py | created | parses the credentials PDF + Achi.txt into shell exports or the client .env; never writes server secrets |
| docs/*.pdf, docs/*.txt, docs/Kisan_Sahayak_Working_Instructions.md | created (copied) | specs inside the project |
| CLAUDE.md | created | TRD §10 + project-specific additions (D-13) |
| README.md | created | links to specs and history; run steps |
| decisions.md | created | per-session closing summary (Working Instructions §6) |
| flow.md | created | execution flow |
| ~/.certs/ca-bundle-with-shell.pem | created (outside project) | CA bundle for the CLIs behind Zscaler (D-14) |

## Phase 1 (2026-10-03)
| Path | Status | Purpose |
|---|---|---|
| supabase/migrations/20261003004500_phase1_schema_rls.sql | created, pushed | TRD §5 tables, RLS, grants, farmers trigger (D-19) |
| scripts/clean_shops.py | created | raw CSV → src/data/shops.json (D-20) |
| scripts/check_phase1_rls.mjs | created | live OTP + RLS check, anon key only; `node --env-file=.env scripts/check_phase1_rls.mjs` |
| src/data/shops.json | created (generated) | 967 cleaned shops; lat/lng null when untrusted |
| src/types/database.ts | created (generated) | `supabase gen types --linked`; regenerate after every migration |
| src/lib/supabase.ts | modified | typed client + AppState auto-refresh |
| src/lib/demo-mode.ts | created | isDemoMode()/setDemoMode(); toggle UI comes in Phase 9 |
| src/constants/strings.ts | created | all UI text, hi + en |
| src/constants/districts.ts | created | 33 Chhattisgarh districts, en + hi |
| src/constants/theme.ts | modified | green brand colours, MinTouchTarget |
| src/features/auth/api.ts | created | OTP, sign-out, farmer fetch/update, error mapping |
| src/features/auth/app-context.tsx | created | session + language provider (useApp) |
| src/components/ui/button.tsx | created | large primary/secondary button |
| src/components/ui/language-toggle.tsx | created | हिंदी/English switch |
| src/components/common/placeholder-screen.tsx | modified | bilingual "built in" text |
| src/app/_layout.tsx | modified | AppProvider, splash, Stack.Protected auth guard |
| src/app/sign-in.tsx | created | phone entry (first screen) |
| src/app/verify.tsx | created | OTP entry, resend, change number |
| src/app/settings/account.tsx | created | optional profile + language + log out |
| src/app/(tabs)/_layout.tsx | modified | bilingual tab titles, Account header button |
| src/app/(tabs)/index.tsx, shops.tsx, chat.tsx, history.tsx | modified | bilingual placeholder titles |
| docs/Kisan_Sahayak_Vision_Brief_v4_FINAL.docx, _docx.txt | created (copied, previous session) | newer PRD (D-17) |

## External references (not in repo)
| Path | Purpose |
|---|---|
| ~/Downloads/New folder/Kisan_Sahayak_Vision_Brief_v4_FINAL.pdf | PRD |
| ~/Downloads/New folder/Kisan_Sahayak_TRD_v1.pdf | TRD |
| ~/Downloads/New folder/Kisan_Sahayak_Implementation_Plan_v1.pdf | Phased build order |
| ~/Downloads/New folder/Kisan_Sahayak_Working_Instructions.md | Process rules for sessions |
| ~/Downloads/jai_shree_ram-2/MASTER_krishi_shops.csv | Raw shop dataset, 1,186 rows; needs cleaning (OQ-6) |
| ~/Downloads/jai_shree_ram-2/Kisan_Sahayak_Credentials_For_Achint.pdf | Live credentials. NEVER copy into the repo or memory (D-9) |
| ~/Downloads/Achi.txt | Kuldeep's note with the sbp_ token. Read by scripts/load_secrets.py; never copy |

## Phase 2 (2026-10-03)
| Path | Status | Purpose |
|---|---|---|
| supabase/functions/_shared/diagnosis.ts | created | schema (TRD §6.1 + Should-I-Spray), prompt, callGemini, enforceSafety, sniffImageMime |
| supabase/functions/diagnose-crop/index.ts | created, deployed (v9) | single-request diagnosis (D-22) |
| supabase/functions/deno.json | created | Deno type-check config (no node_modules) |
| supabase/config.toml | modified | `[functions.diagnose-crop] verify_jwt = true` |
| supabase/migrations/20261003020000_phase2_diagnosis_storage.sql | created, pushed | private bucket + own-folder policies |
| supabase/migrations/20261003030000_phase2_server_only_image_writes.sql | created, pushed | drops the client upload policy |
| src/features/diagnosis/api.ts | created | prepareImage, diagnoseCrop, fetch/list diagnoses, signed URLs |
| src/features/diagnosis/pick-image.ts | created | camera/gallery → diagnosis/camera |
| src/features/diagnosis/photo-tips.tsx | created | photo tips card |
| src/types/diagnosis.ts | created | client copy of the diagnosis type (mirror of _shared) |
| src/app/diagnosis/camera.tsx | created | prepare → diagnose, stages, retry |
| src/app/diagnosis/[id].tsx | created | result screen |
| src/app/(tabs)/index.tsx | modified | Home = diagnosis entry point |
| src/app/(tabs)/history.tsx | modified | past diagnoses list |
| src/app/_layout.tsx | modified | registers the diagnosis screens behind the signed-in guard |
| src/constants/strings.ts | modified | diagnosis/home/history text, hi + en |
| src/constants/theme.ts | modified | warning/success/danger backgrounds |
| app.json | modified | expo-image-picker plugin (bilingual permission text, mic off) |
| package.json | modified | + expo-image-picker, expo-image-manipulator |
| tsconfig.json, eslint.config.js | modified | exclude supabase/functions (Deno) |
| scripts/check_phase2_diagnose.mjs | created | live server check; optional region arg; KS_RESIZED env |
| scripts/reset_test_farmers.mjs | created | wipes test-farmer data (service role from the shell only) |
| scripts/load_secrets.py | modified | `--with-service-role` flag |
| test-assets/* + ATTRIBUTION.txt | created | 5 CC-licensed test photos + a PNG copy (not bundled in the app) |
| (deleted) supabase/functions/model-bench, scripts/model_bench.mjs | temporary | model benchmark, removed after D-21 |

## Phase 3 (2026-10-06)
| Path | Status | Purpose |
|---|---|---|
| supabase/functions/_shared/gemini.ts | created | pinned models + hedged `generate` with a 9 s deadline (D-28) |
| supabase/functions/_shared/http.ts | created | cors, fail, signedInFarmer (gateway-verified claims), adminClient |
| supabase/functions/_shared/bolo.ts | created | Hindi summary (separate Gemini call), Sarvam TTS (priya/mp3), prepareBolo |
| supabase/functions/_shared/diagnosis.ts | modified | diagnoseImage via gemini.generate; maxOutputTokens 1024 |
| supabase/functions/diagnose-crop/index.ts | modified, deployed | shared helpers; background prepareBolo |
| supabase/functions/bolo/index.ts | created, deployed | cached voice for a diagnosis (TRD §6.2 standalone) |
| supabase/config.toml | modified | `[functions.bolo] verify_jwt = true` |
| supabase/migrations/20261006213000_phase3_bolo_audio.sql | created, pushed | private bolo-audio bucket + own-folder SELECT |
| src/features/voice/api.ts | created | fetchBolo (isDemoMode first) |
| src/features/voice/bolo-button.tsx | created | Bolo button: fetch on open, tap play/stop |
| src/features/diagnosis/api.ts | modified | one automatic retry on 503 |
| src/app/diagnosis/[id].tsx | modified | Bolo button under the header |
| src/constants/strings.ts | modified | Bolo text hi/en |
| app.json | modified | expo-audio (no mic/record/background) + expo-asset plugins |
| package.json | modified | + expo-audio, expo-asset, expo-dev-client; Expo patch updates (57.0.27) |
| .easignore | created | keeps internal folders out of EAS uploads |
| scripts/check_phase3_bolo.mjs | created | live Bolo check |
| scripts/check_phase3_tts_failure.mjs | created | non-blocking failure check (run only with a temporarily invalid Sarvam key) |
| scripts/measure_diagnose_latency.mjs | created | app-equivalent latency/reliability measurement |
| scripts/reset_test_farmers.mjs | modified | also clears bolo-audio |
| (deleted) supabase/functions/sarvam-probe, gemini-probe | temporary | Sarvam parameter probe; Gemini stall probe |

## Phase 4 (2026-10-07)
| Path | Status | Purpose |
|---|---|---|
| src/lib/haversine.ts | created | THE only Haversine implementation (Vision Brief §3.7 formula) |
| src/features/shops/find-shops.ts | created | offline ranking: located shops ≤ 50 km + farmer's district; search; directionsUrl; the only haversine caller |
| src/features/shops/use-nearby-shops.ts | created | useNearbyShops hook: device location (expo-location, 20 s GPS cap) + profile district (cached per farmer) |
| src/features/shops/shop-card.tsx | created | card: name, distance, type, district, address, Call, Directions, OSM credit |
| src/features/shops/nearby-shops.tsx | created | top-3 section for result screens (crop now, soil in Phase 5) |
| src/app/(tabs)/shops.tsx | replaced | Shops tab: search + list + location states |
| src/app/diagnosis/[id].tsx | modified | NearbyShops when treatment applies |
| src/constants/strings.ts | modified | shop finder text hi/en |
| app.json | modified | expo-location plugin (when-in-use only; no background, no foreground service) |
| package.json | modified | + expo-location ~57.0.20 |
| scripts/clean_shops.py | modified | canonical districts, second NOT_A_SHOP pass, PIN state filter, verified Plus Code locations, OSM merge, `source` field (D-31) |
| scripts/plus_codes.py | created | Open Location Code short-code recovery (matches Google's reference library, 1,309/1,309) |
| scripts/data/osm_shops.json | created | 5 OpenStreetMap agri shops (ODbL) |
| scripts/data/nominatim_cache.json | created (generated) | cached reverse-geocode answers so re-runs are offline |
| src/data/shops.json | regenerated | 793 shops, 151 with verified coordinates |

## Phase 5 (2026-10-07)
| Path | Status | Purpose |
|---|---|---|
| supabase/functions/_shared/soil.ts | created | SOIL_SCHEMA, soil prompt (§2.2-safe), analyseSoil, low-confidence safety |
| supabase/functions/_shared/diagnosis.ts | modified | LANGUAGE_RULE exported for soil |
| supabase/functions/_shared/bolo.ts | modified | kind-aware Hindi summary (crop / soil), shared voice rules |
| supabase/functions/_shared/http.ts | modified | CORS allows x-ks-kind |
| supabase/functions/diagnose-crop/index.ts | modified, deployed | x-ks-kind: soil → analyseSoil; follow-up/event crop-only |
| supabase/functions/bolo/index.ts | modified, deployed | passes the row's type to prepareBolo |
| supabase/functions/weather/index.ts | created, deployed | OpenWeatherMap current + 12 h forecast |
| supabase/config.toml | modified | `[functions.weather] verify_jwt = true` |
| src/hooks/use-device-location.ts | created (moved) | shared location hook (shops + weather) |
| src/features/weather/{api.ts, advice.ts, weather-card.tsx} | created | fetchWeather (isDemoMode first), plain-rule advice, Home card |
| src/features/diagnosis/api.ts | modified | diagnosePhoto(kind); rows carry kind; History lists soil too |
| src/features/diagnosis/{pick-image.ts, photo-tips.tsx} | modified | kind param; soil photo tips |
| src/app/diagnosis/camera.tsx | modified | kind param, per-kind title and stage text |
| src/app/diagnosis/[id].tsx | modified | SoilResult view |
| src/app/(tabs)/index.tsx | modified | weather card + soil card |
| src/app/(tabs)/history.tsx | modified | soil rows (🧪) |
| src/app/(tabs)/shops.tsx | modified | "Ask the shop for: X" banner from ?product |
| src/features/shops/{nearby-shops.tsx, use-nearby-shops.ts, find-shops.ts} | modified | product prop; hook moved; single Coords type |
| src/types/diagnosis.ts | modified | SoilReport, Kind |
| src/constants/strings.ts | modified | soil + weather text hi/en |
| app.json | modified | location permission text mentions weather |
| scripts/check_phase5_soil_weather.mjs | created | live soil + weather check |
| test-assets/soil_*.jpg (4) + ATTRIBUTION.txt | added | CC-licensed Wikimedia soil photos |
| supabase/functions/read-soil-card/index.ts | created, deployed | Soil Health Card OCR (transcribe only; no storage, no personal fields) (D-35) |
| supabase/config.toml | modified | `[functions.read-soil-card] verify_jwt = true` |
| src/features/soil-card/api.ts | created | readSoilCard (isDemoMode first), levelFor, load/save on the phone |
| src/app/soil-card.tsx | created | intro → read → confirm/correct → saved view with meanings |
| src/app/_layout.tsx | modified | soil-card screen in the signed-in stack |
| src/app/(tabs)/index.tsx | modified | small green "Add your Soil Health Card" button |
| test-assets/soil_health_card_sample.{html,jpg} | created | synthetic sample card (invented values, marked SAMPLE) |
| test-assets/shc_cg_template.html, shc_cg_scan.jpg, shc_cg_photo.jpg | created | realistic Hindi-first Chhattisgarh-style card (invented); clean + degraded phone photo |

## Phase 6 (2026-10-07)
| Path | Status | Purpose |
|---|---|---|
| supabase/functions/chat/index.ts | created, deployed | Agri Expert chat: prompt rules, history context, rate limit, saves both messages (D-36) |
| supabase/config.toml | modified | `[functions.chat] verify_jwt = true` |
| src/features/chat/api.ts | created | fetchChatHistory (RLS), sendChatMessage (isDemoMode first, one retry on 503) |
| src/app/(tabs)/chat.tsx | replaced | chat screen: history, chips, thinking bubble, retry state |
| src/constants/strings.ts | modified | chat text hi/en |
| scripts/check_phase6_chat.mjs | created | live chat check (language, context, no doses, off-topic, history, RLS, validation) |

## MVP item 7 — in-app follow-up loop (2026-10-07)
| Path | Status | Purpose |
|---|---|---|
| supabase/migrations/20261007150000_followup_treatment_applied.sql | created, pushed | follow_ups.treatment_applied (D-37) |
| src/types/database.ts | regenerated | includes treatment_applied |
| supabase/functions/follow-up-answer/index.ts | created, deployed | records the answer + loop_completed (server-side) |
| supabase/config.toml | modified | `[functions.follow-up-answer] verify_jwt = true` |
| src/features/follow-up/api.ts | created | fetchDueFollowUp (RLS), answerFollowUp (isDemoMode first) |
| src/features/follow-up/check-in-card.tsx | created | Home check-in card + next steps |
| src/app/(tabs)/index.tsx | modified | check-in card at the top of Home |
| src/constants/strings.ts | modified | check-in text hi/en |
| scripts/check_followup_loop.mjs | created | live loop check (uses the service role only to backdate) |
| scripts/metrics.mjs | created | §4A founder metrics (read-only) |
| (deleted) supabase/functions/gemini-probe | temporary | diagnosed the 2026-10-07 Gemini "high demand" outage |
| supabase/functions/diagnose-crop/index.ts | modified, deployed | removes the uploaded photo when the AI fails (D-38) |

## D-39 extras — Savings Tracker (2026-10-07)
| Path | Status | Purpose |
|---|---|---|
| src/features/savings/compute.ts | created | pure savings maths with measured / told / estimate definitions (D-40) |
| src/features/savings/api.ts | created | own crop checks + follow-up answers (RLS); spray cost on the phone |
| src/features/savings/savings-card.tsx | created | History card with source tags and the cost input |
| src/app/(tabs)/history.tsx | modified | savings card as the list header |
| src/constants/strings.ts | modified | savings text hi/en |
| scripts/metrics.mjs | modified | + "no spray needed" advice count |

## D-39 extras — Calculator (2026-10-07, D-41)
| File | Status | Purpose |
|---|---|---|
| scripts/build_calculator_data.py | created | downloads the CIB&RC register PDFs + ICAR GFR PDF to /tmp, extracts tables (pdfplumber in /tmp/ksvenv) → the two JSON files |
| src/data/pesticide-register.json | created | 627 products / 1,534 spray rows for 27 CG crops (dose/ha, water/ha, waiting days) |
| src/data/fertilizer-gfr-cg.json | created | ICAR June 2026 N:P2O5:K2O for 33 CG districts × rice/wheat/kharif maize + earlier state values |
| src/features/calculator/compute.ts | created | pure maths: area units, spray mix, fertiliser kg/bags/cost, per-fertiliser comparison |
| src/features/calculator/register.ts | created | crop list, composition parsing + register matching, search, GFR lookup |
| src/features/calculator/api.ts | created | readPesticideLabel (isDemoMode first); fertiliser saving in AsyncStorage |
| src/features/calculator/ui.tsx | created | shared chips, number field, area input, formatting |
| src/app/spray-calculator.tsx | created | spray mix screen |
| src/app/fertilizer-calculator.tsx | created | fertiliser screen |
| supabase/functions/read-pesticide-label/index.ts | created | Gemini transcribes brand + composition only; photo not stored (verify_jwt) |
| supabase/config.toml | modified | read-pesticide-label verify_jwt = true |
| scripts/check_calculator.mts | created | 37 logic checks; --server adds 11 live label-reader checks |
| test-assets/pesticide_labels.html, label_*.jpg | created | synthetic labels (invented brands) rendered with macOS Quick Look |
| src/app/_layout.tsx, src/app/(tabs)/index.tsx | modified | routes + Home calculator card |
| src/features/savings/savings-card.tsx | modified | fertiliser estimate line; card shows with only that line |
| src/features/shops/use-nearby-shops.ts | modified | useProfileDistrict exported |
| src/constants/strings.ts | modified | calculator text hi/en, 27 crop names |

## D-39 extras — Daily Action Feed (2026-10-16, D-42)
| File | Status | Purpose |
|---|---|---|
| src/features/crop-feed/feed.ts | created | pure logic: day number, IRRI paddy stages, scouting schedule; NIPHM thresholds (hi/en) |
| src/features/crop-feed/api.ts | created | plan in AsyncStorage per farmer; todayIso; pastDate (day+month → date, ≤ 200 days back) |
| src/features/crop-feed/today-card.tsx | created | Home card |
| src/app/crop-plan.tsx | created | set up / change / remove the crop |
| src/app/_layout.tsx, src/app/(tabs)/index.tsx | modified | route + card after photo tips |
| src/constants/strings.ts | modified | feed + plan text hi/en |
| scripts/check_crop_feed.mts | created | 49 checks incl. threshold numbers vs NIPHM text in /tmp/ks_sources/ipm |
| scripts/check_calculator.ts | deleted | stale pre-rename copy (re-saved by the editor); broke tsc; the .mts supersedes it |

## Keep-alive + Demo Mode (2026-10-16, D-43/D-44)
| File | Status | Purpose |
|---|---|---|
| supabase/migrations/20261016020000_keep_alive.sql | created | pg_cron every 12 h → pg_net GET own /auth/v1/health; anon key from Vault |
| src/lib/demo-mode.ts | modified | flag persisted in AsyncStorage; loadDemoMode; demoDelay |
| src/lib/supabase.ts | modified | autoRefreshToken false; AppState refresh only when not demo |
| src/features/auth/app-context.tsx | modified | demo session without auth calls; setDemo; remount on mode switch; demo language sync |
| src/features/demo/data.ts | created | demo dataset (tomato hi/en, healthy paddy, sandy loam, chat answer, weather, soil card, label) + bundled photo/audio |
| src/features/demo/store.ts | created | in-session demo state: history, follow-up, savings, chat, Bolo source |
| src/features/demo/seed.ts | created | DEMO_SESSION; seeds crop plan (day 45) + spray cost on switch-on |
| src/features/*/api.ts (diagnosis, weather, follow-up, savings, chat, soil-card, calculator, voice, auth) | modified | demo data behind isDemoMode() at the top |
| src/features/voice/bolo-button.tsx, src/app/diagnosis/[id].tsx | modified | accept bundled module ids (audio/photo) as well as URLs |
| src/app/sign-in.tsx, src/app/settings/account.tsx | modified | hidden 3 s long-press switch; demo banner + off button |
| src/constants/strings.ts | modified | demoOn / demoOff |
| assets/demo/* | created | 2 photos (CC BY / BY-SA), 3 real Bolo MP3s |
| scripts/make_demo_assets.mjs | created | regenerates demo content through the live pipeline (needs --with-service-role; reset test farmers after) |
| test-assets/ATTRIBUTION.txt | modified | shipped-in-app photo credits |
