import * as ImagePicker from 'expo-image-picker';
import { router } from 'expo-router';

import type { PickedImage } from '@/features/diagnosis/api';
import type { Kind } from '@/types/diagnosis';

// Opens the camera or gallery, then hands the photo to diagnosis/camera for upload + analysis.
export async function pickAndDiagnose(source: 'camera' | 'gallery', onDenied: () => void, kind: Kind = 'crop'): Promise<void> {
  if (source === 'camera') {
    const permission = await ImagePicker.requestCameraPermissionsAsync();
    if (!permission.granted) {
      onDenied();
      return;
    }
  }
  const options: ImagePicker.ImagePickerOptions = { mediaTypes: ['images'], quality: 1, exif: false };
  const result = source === 'camera'
    ? await ImagePicker.launchCameraAsync(options)
    : await ImagePicker.launchImageLibraryAsync(options);
  const asset = result.canceled ? null : result.assets[0];
  if (!asset) return;
  const image: PickedImage = { uri: asset.uri, width: asset.width, height: asset.height, mimeType: asset.mimeType };
  router.push({ pathname: '/diagnosis/camera', params: { ...image, mimeType: image.mimeType ?? '', kind } });
}
