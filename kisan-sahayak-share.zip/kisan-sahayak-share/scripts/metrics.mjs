// Vision Brief §4A founder metrics (read-only). Excludes the two test farmers unless --include-test is given.
// Run: eval "$(python3 scripts/load_secrets.py --with-service-role)" && node --env-file=.env scripts/metrics.mjs [--include-test]
import { createClient } from '@supabase/supabase-js';

const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
if (!key) {
  console.error('SUPABASE_SERVICE_ROLE_KEY not set — see the usage line at the top of this file.');
  process.exit(1);
}
const admin = createClient(process.env.EXPO_PUBLIC_SUPABASE_URL, key, { auth: { persistSession: false } });
const includeTest = process.argv.includes('--include-test');
const TEST_PHONES = ['+919000000001', '+919000000002'];

const { data: farmers } = await admin.from('farmers').select('id, phone_number');
const counted = new Set((farmers ?? []).filter((f) => includeTest || !TEST_PHONES.includes(f.phone_number)).map((f) => f.id));
const mine = (rows) => (rows ?? []).filter((r) => counted.has(r.farmer_id));

const weekAgo = new Date(Date.now() - 7 * 86400_000).toISOString();
const monthAgo = new Date(Date.now() - 30 * 86400_000).toISOString();
const [{ data: dx }, { data: chats }, { data: events }, { data: fus }, { data: allDx }] = await Promise.all([
  admin.from('diagnoses').select('farmer_id, created_at').gte('created_at', monthAgo),
  admin.from('chat_messages').select('farmer_id, created_at').eq('role', 'user').gte('created_at', monthAgo),
  admin.from('engagement_events').select('farmer_id, event_type'),
  admin.from('follow_ups').select('status, scheduled_for, farmer_response, treatment_applied, diagnoses!inner(farmer_id)'),
  admin.from('diagnoses').select('farmer_id, diagnosis_json').eq('type', 'crop'),
]);

const activity = [...mine(dx), ...mine(chats)];
const weekly = new Set(activity.filter((a) => a.created_at >= weekAgo).map((a) => a.farmer_id));
const activeDays = new Map();
for (const a of activity) activeDays.set(a.farmer_id, (activeDays.get(a.farmer_id) ?? new Set()).add(a.created_at.slice(0, 10)));
const repeat = [...activeDays.values()].filter((days) => days.size >= 2).length;

const ev = mine(events);
const loops = ev.filter((e) => e.event_type === 'loop_completed').length;
const diagnosesDone = ev.filter((e) => e.event_type === 'diagnosis_completed').length;
const ownFus = (fus ?? []).filter((f) => counted.has(f.diagnoses.farmer_id));
const due = ownFus.filter((f) => f.scheduled_for <= new Date().toISOString()).length;
const saves = ownFus.filter((f) => f.farmer_response === 'improved').length;
const savesApplied = ownFus.filter((f) => f.farmer_response === 'improved' && f.treatment_applied === true).length;
// Same definition as the app's Savings Tracker (src/features/savings/compute.ts).
const noSpray = mine(allDx).filter((d) => d.diagnosis_json.spray_decision === 'not_needed' && d.diagnosis_json.confidence !== 'low').length;

console.log(`Kisan Sahayak — §4A metrics (${includeTest ? 'including' : 'excluding'} test farmers), ${new Date().toISOString().slice(0, 16)}Z`);
console.log(`  weekly active farmers (diagnosis or question, last 7 d): ${weekly.size}`);
console.log(`  repeat farmers (active on 2+ days, last 30 d):           ${repeat}`);
console.log(`  crop diagnoses completed (all time):                    ${diagnosesDone}`);
console.log(`  advisory loops completed (check-in answered):           ${loops} of ${due} due  (${due ? Math.round((100 * loops) / due) : 0}%)`);
console.log(`  crop-saves (farmer says "getting better"):              ${saves}  (${savesApplied} after applying the treatment)`);
console.log(`  "no spray needed" advice given (sprays avoided):         ${noSpray}`);
