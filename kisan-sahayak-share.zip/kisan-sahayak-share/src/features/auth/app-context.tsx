import AsyncStorage from '@react-native-async-storage/async-storage';
import type { Session } from '@supabase/supabase-js';
import { createContext, Fragment, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';

import { strings, type Language, type Strings } from '@/constants/strings';
import { isLanguage, updateProfile } from '@/features/auth/api';
import { DEMO_SESSION, seedDemo } from '@/features/demo/seed';
import { resetDemo, setDemoLanguage } from '@/features/demo/store';
import { isDemoMode, loadDemoMode, setDemoMode } from '@/lib/demo-mode';
import { supabase } from '@/lib/supabase';

const LANGUAGE_KEY = 'ks.language';

type AppContextValue = {
  ready: boolean;
  session: Session | null;
  language: Language;
  t: Strings;
  setLanguage: (language: Language) => void;
  demo: boolean;
  setDemo: (on: boolean) => Promise<void>;
};

const AppContext = createContext<AppContextValue | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [language, setLanguageState] = useState<Language>('hi');
  const [ready, setReady] = useState(false);
  const [demo, setDemoState] = useState(false);

  useEffect(() => {
    Promise.all([loadDemoMode(), AsyncStorage.getItem(LANGUAGE_KEY)]).then(async ([demoOn, stored]) => {
      if (isLanguage(stored)) {
        setLanguageState(stored);
        setDemoLanguage(stored);
      }
      setDemoState(demoOn);
      // Demo Mode never touches Supabase auth, so a cold start in airplane mode still opens the app.
      setSession(demoOn ? DEMO_SESSION : (await supabase.auth.getSession()).data.session);
      if (!demoOn) supabase.auth.startAutoRefresh();
      setReady(true);
    });
    const { data } = supabase.auth.onAuthStateChange((_event, next) => {
      if (!isDemoMode()) setSession(next);
    });
    return () => data.subscription.unsubscribe();
  }, []);

  const farmerId = session?.user.id;

  // Keep the server copy in step with the device choice once signed in (TRD §5.1 preferred_language).
  useEffect(() => {
    if (farmerId) updateProfile(farmerId, { preferred_language: language });
  }, [farmerId, language]);

  const setLanguage = useCallback((next: Language) => {
    setLanguageState(next);
    setDemoLanguage(next);
    AsyncStorage.setItem(LANGUAGE_KEY, next);
  }, []);

  const setDemo = useCallback(async (on: boolean) => {
    await setDemoMode(on);
    resetDemo();
    if (on) {
      supabase.auth.stopAutoRefresh();
      await seedDemo();
      setSession(DEMO_SESSION);
    } else {
      setSession((await supabase.auth.getSession()).data.session);
      supabase.auth.startAutoRefresh();
    }
    setDemoState(on);
  }, []);

  const value = useMemo(
    () => ({ ready, session, language, t: strings[language], setLanguage, demo, setDemo }),
    [ready, session, language, setLanguage, demo, setDemo],
  );

  // Switching mode remounts the screens, so nothing cached from the other mode (location, lists) is shown.
  return (
    <AppContext.Provider value={value}>
      <Fragment key={demo ? 'demo' : 'live'}>{children}</Fragment>
    </AppContext.Provider>
  );
}

export function useApp(): AppContextValue {
  const value = useContext(AppContext);
  if (!value) throw new Error('useApp must be used inside <AppProvider>');
  return value;
}
