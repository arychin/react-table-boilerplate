import { Pressable, StyleSheet, Text, View } from 'react-native';

import type { Language } from '@/constants/strings';
import { MinTouchTarget, Spacing } from '@/constants/theme';
import { useApp } from '@/features/auth/app-context';
import { useTheme } from '@/hooks/use-theme';

const OPTIONS: { value: Language; label: string }[] = [
  { value: 'hi', label: 'हिंदी' },
  { value: 'en', label: 'English' },
];

// Vision Brief §4 #10: one tap switches the whole app, instantly.
export function LanguageToggle() {
  const { language, setLanguage } = useApp();
  const theme = useTheme();
  return (
    <View accessibilityRole="radiogroup" style={[styles.row, { borderColor: theme.border }]}>
      {OPTIONS.map((option) => {
        const selected = option.value === language;
        return (
          <Pressable
            key={option.value}
            accessibilityRole="radio"
            accessibilityState={{ selected }}
            onPress={() => setLanguage(option.value)}
            style={[styles.option, selected && { backgroundColor: theme.primary }]}>
            <Text style={[styles.label, { color: selected ? theme.onPrimary : theme.text }]}>{option.label}</Text>
          </Pressable>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', borderWidth: 1.5, borderRadius: Spacing.three, overflow: 'hidden', alignSelf: 'flex-start' },
  option: { minHeight: MinTouchTarget - 12, minWidth: 96, paddingHorizontal: Spacing.three, alignItems: 'center', justifyContent: 'center' },
  label: { fontSize: 16, fontWeight: '700' },
});
