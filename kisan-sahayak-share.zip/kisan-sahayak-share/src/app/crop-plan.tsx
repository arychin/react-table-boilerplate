import { router } from 'expo-router';
import { useEffect, useState } from 'react';
import { ScrollView, Text, View } from 'react-native';

import { Button } from '@/components/ui/button';
import { useApp } from '@/features/auth/app-context';
import { Chip, ChipRow, num, NumberField, calcStyles as s, SectionTitle } from '@/features/calculator/ui';
import { loadPlan, pastDate, savePlan } from '@/features/crop-feed/api';
import { CHANA_STAGES, RICE_DURATIONS, type ChanaStage, type CropPlan, type FeedCrop, type RiceDuration } from '@/features/crop-feed/feed';
import { useTheme } from '@/hooks/use-theme';

const MONTHS = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map(String);

// D-42: the farmer tells us the crop and when the seed went in; everything else is worked out on the phone.
export default function CropPlanScreen() {
  const { t, session } = useApp();
  const theme = useTheme();
  const farmerId = session?.user.id ?? '';
  const [existing, setExisting] = useState<CropPlan | null>(null);
  const [today, setToday] = useState<string | null>(null);
  const [crop, setCrop] = useState<FeedCrop>('rice');
  const [day, setDay] = useState('');
  const [month, setMonth] = useState('7');
  const [duration, setDuration] = useState<RiceDuration>(130);
  const [chanaStage, setChanaStage] = useState<ChanaStage>('chana_seedling');
  const [error, setError] = useState(false);

  useEffect(() => {
    loadPlan(farmerId).then(({ plan, today: now }) => {
      setToday(now);
      setExisting(plan);
      if (!plan) return setMonth(String(+now.slice(5, 7)));
      setCrop(plan.crop);
      setDay(String(+plan.sownOn.slice(8, 10)));
      setMonth(String(+plan.sownOn.slice(5, 7)));
      setDuration(plan.duration);
      setChanaStage(plan.chanaStage);
    });
  }, [farmerId]);

  const save = async () => {
    const sownOn = today ? pastDate(num(day), +month, today) : null;
    if (!sownOn) return setError(true);
    const sameCrop = existing && existing.crop === crop && existing.sownOn === sownOn;
    await savePlan(farmerId, { crop, sownOn, duration, chanaStage, lastScouted: sameCrop ? existing.lastScouted : null });
    router.back();
  };

  const remove = async () => {
    await savePlan(farmerId, null);
    router.back();
  };

  return (
    <ScrollView style={{ backgroundColor: theme.background }} contentContainerStyle={s.content} keyboardShouldPersistTaps="handled">
      <SectionTitle>{t.planCrop}</SectionTitle>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
        {(['rice', 'chana'] as const).map((c) => (
          <Chip key={c} label={t.planCrops[c]} selected={c === crop} onPress={() => setCrop(c)} />
        ))}
      </View>

      <SectionTitle>{t.planSown}</SectionTitle>
      <NumberField label={t.planDay} value={day} onChange={(v) => { setDay(v.replace(/\D/g, '').slice(0, 2)); setError(false); }} />
      <ChipRow options={MONTHS} value={month} label={(m) => t.planMonths[+m - 1]} onChange={(m) => { setMonth(m); setError(false); }} />
      {error && <Text style={[s.error, { color: theme.danger }]}>{t.planBadDate}</Text>}

      {crop === 'rice' ? (
        <>
          <SectionTitle>{t.planDuration}</SectionTitle>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
            {RICE_DURATIONS.map((d) => (
              <Chip key={d} label={t.planDurations[d]} selected={d === duration} onPress={() => setDuration(d)} />
            ))}
          </View>
        </>
      ) : (
        <>
          <SectionTitle>{t.planChanaStage}</SectionTitle>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
            {CHANA_STAGES.map((st) => (
              <Chip key={st} label={t.stageNames[st]} selected={st === chanaStage} onPress={() => setChanaStage(st)} />
            ))}
          </View>
        </>
      )}

      <Button label={t.planSave} onPress={save} disabled={!today} />
      {existing && <Button label={t.planRemove} variant="secondary" onPress={remove} />}
    </ScrollView>
  );
}
