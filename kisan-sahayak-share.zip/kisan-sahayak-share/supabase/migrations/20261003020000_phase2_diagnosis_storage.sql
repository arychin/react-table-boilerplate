-- Phase 2: private image bucket for diagnoses (TRD §8: never public; access via short-lived signed URLs).
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'diagnosis-images', 'diagnosis-images', false, 10485760,
  array['image/jpeg', 'image/png', 'image/webp', 'image/heic', 'image/heif']
)
on conflict (id) do nothing;

-- Farmers upload into, and read from, only their own "<auth uid>/..." folder.
-- No update/delete: a diagnosed photo can't be swapped afterwards.
create policy "diagnosis-images: upload own folder" on storage.objects
  for insert to authenticated
  with check (bucket_id = 'diagnosis-images' and (storage.foldername(name))[1] = (select auth.uid())::text);

create policy "diagnosis-images: read own folder" on storage.objects
  for select to authenticated
  using (bucket_id = 'diagnosis-images' and (storage.foldername(name))[1] = (select auth.uid())::text);
