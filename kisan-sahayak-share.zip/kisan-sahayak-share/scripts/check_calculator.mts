// D-41 calculator checks: maths against hand-worked answers, official-table lookups, and (with --server) the label reader.
// Run: npx --yes tsx --env-file=.env --tsconfig tsconfig.json scripts/check_calculator.mts [--server]
import { readFileSync } from 'node:fs';

import { createClient } from '@supabase/supabase-js';

import { bags, compareUsual, cost, DEFAULT_BAG_PRICE, fertiliserKg, perAcre, spray, toAcres, usualKg } from '../src/features/calculator/compute';
import { gfrFor, matchComposition, parseComposition, rowsFor, searchProducts, type CropId } from '../src/features/calculator/register';

let pass = 0, fail = 0;
const near = (a: number, b: number, tol = 0.01) => Math.abs(a - b) <= tol * Math.max(1, Math.abs(b));
function check(name: string, ok: boolean, got?: unknown) {
  if (ok) pass++; else { fail++; console.log('FAIL', name, JSON.stringify(got)); }
}

// Area: 1 acre = 100 dismil; 1 ha = 2.4711 acre
check('50 dismil', toAcres(50, 'dismil') === 0.5);
check('1 ha', near(toAcres(1, 'ha'), 2.4711));

// Spray, per-acre basis. Chlorantraniliprole rice: 150 ml/ha, 500 L/ha. 1 acre, 16 L tank, 200 L/acre.
// per acre = 150/2.4711 = 60.70 ml; tanks = ceil(200/16) = 13; per tank = 60.70 * 16/200 = 4.856 ml
const pa = perAcre([150, 150]);
const s1 = spray({ acres: 1, tankLitres: 16, waterPerAcre: 200, dose: { basis: 'acre', amount: pa } })!;
check('per acre dose', near(pa[0], 60.70), pa);
check('tanks', s1.tanks === 13, s1);
check('per tank', near(s1.perTank[0], 4.856), s1);
check('total', near(s1.total[0], 60.70), s1);
// 75 dismil: total 45.53 ml, water 150 L, tanks ceil(150/16)=10
const s2 = spray({ acres: toAcres(75, 'dismil'), tankLitres: 16, waterPerAcre: 200, dose: { basis: 'acre', amount: pa } })!;
check('75 dismil total', near(s2.total[0], 45.53) && s2.totalWater === 150 && s2.tanks === 10, s2);
// Per-litre basis: label "2 ml per litre", 16 L tank → 32 ml/tank; 1 acre at 200 L → 400 ml
const s3 = spray({ acres: 1, tankLitres: 16, waterPerAcre: 200, dose: { basis: 'litre', amount: [2, 2] } })!;
check('per litre', s3.perTank[0] === 32 && s3.total[0] === 400, s3);
check('bad input → null', spray({ acres: 0, tankLitres: 16, waterPerAcre: 200, dose: { basis: 'acre', amount: [1, 1] } }) === null);
check('range keeps order', (() => { const r = spray({ acres: 2, tankLitres: 15, waterPerAcre: 150, dose: { basis: 'acre', amount: [20, 40] } })!; return r.perTank[0] === 2 && r.perTank[1] === 4 && r.total[1] === 80; })());

// Fertiliser: Bilaspur rice 70:35:20 on 1 acre (0.40468 ha)
// DAP = 35/0.46*0.40468 = 30.79 kg; N from DAP = 5.542; urea = (70*0.40468 - 5.542)/0.46 = 49.53 kg; MOP = 20/0.6*0.40468 = 13.49 kg
const k = fertiliserKg([70, 35, 20], 1);
check('dap kg', near(k.dap, 30.79), k);
check('urea kg', near(k.urea, 49.53), k);
check('mop kg', near(k.mop, 13.49), k);
// Old 90:60:60 on 1 acre: DAP 52.79, urea (36.42-9.502)/0.46=58.52, MOP 40.47
const old = fertiliserKg([90, 60, 60], 1);
check('old urea', near(old.urea, 58.52) && near(old.dap, 52.79) && near(old.mop, 40.47), old);
// Cost new = 49.53/45*242 + 30.79/50*1350 + 13.49/50*1711 = 266.4 + 831.3 + 461.6 = 1559.3
check('cost new', near(cost(k, DEFAULT_BAG_PRICE), 1559.3), cost(k, DEFAULT_BAG_PRICE));
check('bags urea', near(bags(45, 'urea'), 1));
// Usual: 2 bags urea + 1 DAP + 0.5 MOP per acre on 2 acres → 180, 100, 50 kg
const u = usualKg({ urea: 2, dap: 1, mop: 0.5 }, 2);
check('usual kg', u.urea === 180 && u.dap === 100 && u.mop === 50, u);
check('zero P/K → only urea', (() => { const z = fertiliserKg([46, 0, 0], ACRES()); return near(z.urea, 100) && z.dap === 0 && z.mop === 0; })());
function ACRES() { return 2.4711; } // 1 ha
// Per-fertiliser comparison. Bilaspur rice 1 acre, usual 2 urea + 1 DAP + 1 MOP: all above → excess = 3545 - 1559.3
const c1 = compareUsual(k, usualKg({ urea: 2, dap: 1, mop: 1 }, 1), DEFAULT_BAG_PRICE);
check('all over → excess = cost difference', near(c1.excessRupees, 3545 - 1559.3) && c1.short.length === 0, c1);
// Dhamtari maize 150:55:60, 1 acre: urea need ~113 kg (2.5 bags); farmer 2 urea → short; MOP 1 bag vs 0.8 → excess only on MOP (+DAP if over)
const mz = fertiliserKg([150, 55, 60], 1);
const c2 = compareUsual(mz, usualKg({ urea: 2, dap: 1, mop: 1 }, 1), DEFAULT_BAG_PRICE);
check('short urea is flagged, never netted', c2.short.includes('urea') && near(c2.diffBags.urea, 2 - mz.urea / 45), c2);
check('excess counts only fertilisers clearly above (DAP 0.03 bag over = about right)', !c2.over.includes('dap') && c2.over.includes('mop') && near(c2.excessRupees, (1 - mz.mop / 50) * 1711), c2);
check('exactly recommended → no excess, no short', (() => { const c = compareUsual(k, k, DEFAULT_BAG_PRICE); return c.excessRupees === 0 && c.short.length === 0; })());

// ICAR table
check('gfr bilaspur rice', JSON.stringify(gfrFor('Bilaspur', 'rice')) === JSON.stringify({ npk: [70, 35, 20], earlier: [90, 60, 60] }), gfrFor('Bilaspur', 'rice'));
check('gfr raipur wheat', JSON.stringify(gfrFor('Raipur', 'wheat')?.npk) === '[90,25,35]', gfrFor('Raipur', 'wheat'));
check('gfr koriya maize', JSON.stringify(gfrFor('Koriya', 'maize')?.npk) === '[60,30,40]', gfrFor('Koriya', 'maize'));
check('gfr unknown', gfrFor('Nowhere', 'rice') === null);

// Composition parsing / matching
check('parse simple', parseComposition('Chlorantraniliprole 18.5% w/w SC')?.key === 'chlorantraniliprole@18.5', parseComposition('Chlorantraniliprole 18.5% w/w SC'));
check('parse combo order-free', parseComposition('Bifenthrin 25% + Acetamiprid 25 % WG')?.key === parseComposition('Acetamiprid 25% + Bifenthrin 25 % WG')?.key);
check('parse leading zeros', parseComposition('Fipronil00.30% GR')?.key === 'fipronil@0.3');
check('parse ignores bracket', parseComposition('Glyphosate 41% SL (Equivalent to 54% w/v)')?.key === 'glyphosate@41');
check('parse form WDG→WG', parseComposition('Thiamethoxam 25% WDG')?.form === 'WG');
const m1 = matchComposition('Chlorantraniliprole 18.5% SC', 'rice');
check('match CAP rice exact', m1.exact.length >= 1 && rowsFor(m1.exact[0], 'rice').some((r) => r.dose[0] === 150 && r.water[0] === 500 && r.wait === 47), m1.exact.map((p) => [p.name, rowsFor(p, 'rice')]));
const m2 = matchComposition('Pymetrozine 50% WG', 'rice');
check('match pymetrozine', m2.exact.some((p) => rowsFor(p, 'rice').some((r) => r.dose[0] === 300 && r.wait === 19)), m2.exact.map((p) => [p.name, rowsFor(p, 'rice')]));
const m3 = matchComposition('Chlorantraniliprole 0.4% GR', 'rice');
check('different strength → similar, not exact', m3.exact.length === 0 && m3.similar.length >= 1, m3);
const m4 = matchComposition('Pymetrozine 50% WG', 'onion');
check('not registered for crop', m4.notForCrop && !m4.exact.length && !m4.similar.length, m4);
check('unreadable', matchComposition('Super Killer', 'rice').exact.length === 0);
check('search', searchProducts('chloranTRAN', 'rice').length >= 1 && searchProducts('ch', 'rice').length === 0);

if (process.argv.includes('--server')) {
  const url = process.env.EXPO_PUBLIC_SUPABASE_URL!;
  const anon = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY!;
  const client = createClient(url, anon, { auth: { persistSession: false } });
  await client.auth.signInWithOtp({ phone: '+919000000001' });
  const { data } = await client.auth.verifyOtp({ phone: '+919000000001', token: '246810', type: 'sms' });
  const token = data.session!.access_token;
  const read = async (file: string) => {
    const t = Date.now();
    const res = await fetch(`${url}/functions/v1/read-pesticide-label`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}`, apikey: anon, 'Content-Type': 'image/jpeg' },
      body: readFileSync(`test-assets/${file}`),
    });
    const body = res.ok ? await res.json() : await res.text();
    console.log(`  ${file}: ${res.status} ${Date.now() - t} ms → ${JSON.stringify(body)}`);
    return { status: res.status, label: body as { is_pesticide_label: boolean; brand_name: string; composition: string } };
  };
  // The label shows "60 ml/acre", "200 ग्राम", "80–100 ml" — none of that may come back.
  const DOSE = /\d\s*(ml|g\b|gm|ग्राम|मिली|l\b|लीटर|litre)|per acre|प्रति एकड़/i;
  const cases: [string, CropId, number, number][] = [
    ['label_cap_sc.jpg', 'rice', 150, 47],
    ['label_cap_photo.jpg', 'rice', 150, 47],
    ['label_hindi_tricyclazole.jpg', 'rice', 500, 23],
    ['label_bispyribac.jpg', 'rice', 200, 78],
  ];
  for (const [file, crop, dose, wait] of cases) {
    const { status, label } = await read(file);
    check(`${file} read`, status === 200 && label.is_pesticide_label && !!label.composition, label);
    check(`${file} no dose returned`, !DOSE.test(JSON.stringify(label)), label);
    const m = matchComposition(label.composition ?? '', crop);
    check(`${file} → register match`, m.exact.some((p) => rowsFor(p, crop).some((r) => r.dose[0] === dose && r.wait === wait)), m.exact.map((p) => [p.name, rowsFor(p, crop)]));
  }
  const urea = await read('label_urea_bag.jpg');
  check('urea bag → not a pesticide label', urea.status === 200 && !urea.label.is_pesticide_label, urea.label);
  const leaf = await read('tomato_early_blight.jpg');
  check('leaf photo → not a pesticide label', leaf.status === 200 && !leaf.label.is_pesticide_label, leaf.label);
  const unauth = await fetch(`${url}/functions/v1/read-pesticide-label`, { method: 'POST', headers: { apikey: anon, 'Content-Type': 'image/jpeg' }, body: readFileSync('test-assets/label_cap_sc.jpg') });
  check('no login → 401', unauth.status === 401, unauth.status);
}

console.log(`${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
