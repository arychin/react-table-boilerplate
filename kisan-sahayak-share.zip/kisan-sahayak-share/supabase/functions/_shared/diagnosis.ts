// Diagnosis prompt + schema, shared by diagnose-crop (and bolo for the Diagnosis type).
import { generate } from './gemini.ts';

export type Language = 'hi' | 'en';

// TRD §6.1 schema (all original fields and required list kept), extended with
// crop_name + the Vision Brief §3.11 Should-I-Spray verdict and its reasoning.
export const DIAGNOSIS_SCHEMA = {
  type: 'object',
  properties: {
    crop_name: { type: 'string' },
    disease_name: { type: 'string' },
    cause: { type: 'string' },
    severity: { type: 'string', enum: ['low', 'medium', 'high', 'urgent'] },
    confidence: { type: 'string', enum: ['low', 'medium', 'high'] },
    spray_decision: { type: 'string', enum: ['not_needed', 'wait_and_watch', 'spray_recommended'] },
    decision_reason: { type: 'string' },
    treatment: { type: 'string' },
    treatment_steps: { type: 'array', items: { type: 'string' } },
    prevention_tips: { type: 'array', items: { type: 'string' } },
    organic_alternative: { type: 'string' },
  },
  required: [
    'crop_name', 'disease_name', 'cause', 'severity', 'confidence',
    'spray_decision', 'decision_reason', 'treatment', 'treatment_steps',
  ],
  propertyOrdering: [
    'crop_name', 'disease_name', 'cause', 'severity', 'confidence', 'spray_decision',
    'decision_reason', 'treatment', 'treatment_steps', 'prevention_tips', 'organic_alternative',
  ],
} as const;

export type Diagnosis = {
  crop_name: string;
  disease_name: string;
  cause: string;
  severity: 'low' | 'medium' | 'high' | 'urgent';
  confidence: 'low' | 'medium' | 'high';
  spray_decision: 'not_needed' | 'wait_and_watch' | 'spray_recommended';
  decision_reason: string;
  treatment: string;
  treatment_steps: string[];
  prevention_tips?: string[];
  organic_alternative?: string;
};

export const LANGUAGE_RULE: Record<Language, string> = {
  hi: 'Write every text field in simple Hindi (Devanagari script) using the everyday words a village farmer in Chhattisgarh uses. Put a scientific or English name in brackets only after the plain Hindi name.',
  en: 'Write every text field in simple, plain English that a farmer with little schooling can follow. Put a scientific name in brackets only after the plain name.',
};

export function systemInstruction(language: Language): string {
  return `You are Kisan Sahayak, a careful plant-health adviser for small farmers in Chhattisgarh, India (paddy, wheat, tomato, soybean, chickpea, vegetables).
Look at the photo and identify the single most likely problem.

Rules — follow all of them:
1. ${LANGUAGE_RULE[language]}
2. NEVER state a dose, quantity, concentration, dilution, mixing ratio, or any amount per acre, pump, litre or plant. Dose guidance is shown to the farmer separately from verified sources. You may name the active ingredient or product type (for example "a mancozeb-based fungicide").
3. Be honest about uncertainty. confidence = "high" only when the symptoms are clear and typical; "medium" when likely but another cause is possible; "low" when the photo is blurry, too far away, not a crop plant, or the symptoms are ambiguous.
4. If the photo does not clearly show a crop plant or leaf: say the photo is unclear in disease_name, set confidence "low", severity "low", spray_decision "wait_and_watch", and use treatment and treatment_steps to ask for a sharp close-up of the affected leaf in daylight.
5. If the plant looks healthy: say so in disease_name, severity "low", spray_decision "not_needed", and give simple care tips.
6. spray_decision: "not_needed" (minor, just watch), "wait_and_watch" (borderline — recheck in a few days or send another photo), or "spray_recommended" (evidence supports acting now). Never "spray_recommended" when confidence is "low". decision_reason: one or two sentences explaining why, based only on what is visible.
7. severity is how fast the farmer must act: low, medium, high, urgent.
8. treatment: the recommended product type or approach in one line. treatment_steps: 3 to 5 short practical steps, including safety (gloves and mask, spray in calm weather in the morning or evening, follow the product label). prevention_tips: 2 to 4 tips for the next crop. organic_alternative: a low-cost option such as a neem-based spray if one genuinely helps; otherwise say no reliable organic option.
9. Do not promise a cure, yield or result.`;
}

export const USER_PROMPT = 'Diagnose this crop photo.';

// Server-side safety net for rule 6 (Vision Brief §3.11): low confidence can never mean "spray".
export function enforceSafety(d: Diagnosis): Diagnosis {
  return d.confidence === 'low' && d.spray_decision === 'spray_recommended'
    ? { ...d, spray_decision: 'wait_and_watch' }
    : d;
}

/** Structured image diagnosis (responseSchema, never markdown parsing) with model fallback. */
export async function diagnoseImage(opts: { language: Language; mimeType: string; base64: string }): Promise<{ diagnosis: Diagnosis; model: string }> {
  const { text, model } = await generate({
    systemInstruction: { parts: [{ text: systemInstruction(opts.language) }] },
    contents: [{
      role: 'user',
      parts: [{ inlineData: { mimeType: opts.mimeType, data: opts.base64 } }, { text: USER_PROMPT }],
    }],
    generationConfig: {
      temperature: 0.2,
      responseMimeType: 'application/json',
      responseSchema: DIAGNOSIS_SCHEMA,
      maxOutputTokens: 1024, // normal answers are ~300–370 tokens; caps any runaway generation
    },
  });
  return { diagnosis: enforceSafety(JSON.parse(text) as Diagnosis), model };
}

// Detect the real image type from the file's bytes — never trust or hardcode 'image/jpeg' (TRD §6.1).
export function sniffImageMime(bytes: Uint8Array): string | null {
  const b = bytes;
  if (b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return 'image/jpeg';
  if (b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47) return 'image/png';
  if (b[0] === 0x52 && b[1] === 0x49 && b[2] === 0x46 && b[3] === 0x46 && b[8] === 0x57 && b[9] === 0x45 && b[10] === 0x42 && b[11] === 0x50) return 'image/webp';
  const brand = String.fromCharCode(...b.slice(4, 12));
  if (brand.startsWith('ftyp') && /heic|heix|hevc|mif1|msf1/.test(brand.slice(4))) return 'image/heic';
  return null;
}
