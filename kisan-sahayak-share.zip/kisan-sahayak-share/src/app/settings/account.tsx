import { useEffect, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';

import { Button } from '@/components/ui/button';
import { LanguageToggle } from '@/components/ui/language-toggle';
import { DISTRICTS } from '@/constants/districts';
import { MinTouchTarget, Spacing } from '@/constants/theme';
import { fetchFarmer, signOut, updateProfile } from '@/features/auth/api';
import { useApp } from '@/features/auth/app-context';
import { useTheme } from '@/hooks/use-theme';

// TRD §6.6 step 4: optional name + district, saved onto the farmer's existing row. Never required.
export default function AccountScreen() {
  const { session, language, t, demo, setDemo } = useApp();
  const theme = useTheme();
  const farmerId = session?.user.id ?? '';
  const [name, setName] = useState('');
  const [district, setDistrict] = useState<string | null>(null);
  const [phone, setPhone] = useState('');
  const [status, setStatus] = useState<'idle' | 'saving' | 'saved' | 'error'>('idle');

  useEffect(() => {
    fetchFarmer(farmerId).then((farmer) => {
      if (!farmer) return;
      setName(farmer.name ?? '');
      setDistrict(farmer.district);
      setPhone(farmer.phone_number);
    });
  }, [farmerId]);

  async function onSave() {
    setStatus('saving');
    const { errorKey } = await updateProfile(farmerId, { name: name.trim() || null, district });
    setStatus(errorKey ? 'error' : 'saved');
  }

  const edit = <T,>(setter: (value: T) => void) => (value: T) => {
    setter(value);
    setStatus('idle');
  };

  return (
    <ScrollView style={{ backgroundColor: theme.background }} contentContainerStyle={styles.content}>
      {demo && (
        <View style={[styles.demo, { backgroundColor: theme.warningBg }]}>
          <Text style={[styles.note, { color: theme.warning }]}>{t.demoOn}</Text>
          <Button label={t.demoOff} onPress={() => setDemo(false)} />
        </View>
      )}
      <Text style={[styles.phone, { color: theme.text }]}>{phone}</Text>
      <Text style={[styles.note, { color: theme.textSecondary }]}>{t.accountOptional}</Text>

      <Text style={[styles.label, { color: theme.text }]}>{t.languageLabel}</Text>
      <LanguageToggle />

      <Text style={[styles.label, { color: theme.text }]}>{t.nameLabel}</Text>
      <TextInput
        value={name}
        onChangeText={edit(setName)}
        placeholder={t.namePlaceholder}
        placeholderTextColor={theme.textSecondary}
        autoComplete="name"
        maxLength={80}
        style={[styles.input, { color: theme.text, borderColor: theme.border }]}
      />

      <Text style={[styles.label, { color: theme.text }]}>{t.districtLabel}</Text>
      <View style={styles.chips}>
        {DISTRICTS.map((d) => {
          const selected = district === d.en;
          return (
            <Pressable
              key={d.en}
              accessibilityRole="radio"
              accessibilityState={{ selected }}
              onPress={() => edit(setDistrict)(selected ? null : d.en)}
              style={[
                styles.chip,
                { borderColor: selected ? theme.primary : theme.border },
                selected && { backgroundColor: theme.primary },
              ]}>
              <Text style={[styles.chipText, { color: selected ? theme.onPrimary : theme.text }]}>{d[language]}</Text>
            </Pressable>
          );
        })}
      </View>

      {status === 'error' && <Text style={[styles.status, { color: theme.danger }]}>{t.errSave}</Text>}
      {status === 'saved' && <Text style={[styles.status, { color: theme.primary }]}>{t.saved}</Text>}
      <Button label={t.save} onPress={onSave} loading={status === 'saving'} />
      <Button variant="secondary" label={t.signOut} onPress={demo ? () => setDemo(false) : signOut} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  content: { padding: Spacing.four, gap: Spacing.three, paddingBottom: Spacing.six },
  phone: { fontSize: 22, fontWeight: '700' },
  note: { fontSize: 15 },
  label: { fontSize: 17, fontWeight: '700', marginTop: Spacing.two },
  input: { borderWidth: 2, borderRadius: Spacing.three, minHeight: MinTouchTarget, paddingHorizontal: Spacing.three, fontSize: 18 },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.two },
  chip: { borderWidth: 1.5, borderRadius: Spacing.five, minHeight: 44, paddingHorizontal: Spacing.three, justifyContent: 'center' },
  chipText: { fontSize: 15, fontWeight: '600' },
  status: { fontSize: 16, fontWeight: '600' },
  demo: { borderRadius: Spacing.three, padding: Spacing.three, gap: Spacing.two },
});
