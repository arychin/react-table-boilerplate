import * as Location from 'expo-location';
import { useEffect, useState } from 'react';

import { isDemoMode } from '@/lib/demo-mode';

export type Coords = { latitude: number; longitude: number };
export type LocationStatus = 'locating' | 'ready' | 'needs-permission' | 'denied' | 'unavailable';
type Fix = { status: LocationStatus; coords: Coords | null };

const LAST_FIX_MAX_AGE_MS = 30 * 60_000;
const GPS_TIMEOUT_MS = 20_000;
// Vision Brief §3.9: Demo Mode simulates a farmer near Durg.
const DEMO_COORDS: Coords = { latitude: 21.19, longitude: 81.28 };

/**
 * Device location for the shop finder and the weather card. GPS itself works in airplane mode.
 * `ask` = request permission on mount. Otherwise only use an already-granted permission.
 */
export function useDeviceLocation(ask: boolean) {
  const [fix, setFix] = useState<Fix>(() => ({ status: isDemoMode() ? 'ready' : 'locating', coords: isDemoMode() ? DEMO_COORDS : null }));

  useEffect(() => {
    if (!isDemoMode()) readLocation(ask).then(setFix);
  }, [ask]);

  const locate = () => {
    setFix({ status: 'locating', coords: null });
    readLocation(true).then(setFix);
  };
  return { ...fix, locate };
}

async function readLocation(request: boolean): Promise<Fix> {
  const perm = request ? await Location.requestForegroundPermissionsAsync() : await Location.getForegroundPermissionsAsync();
  if (!perm.granted) return { status: request || !perm.canAskAgain ? 'denied' : 'needs-permission', coords: null };
  try {
    const pos =
      (await Location.getLastKnownPositionAsync({ maxAge: LAST_FIX_MAX_AGE_MS })) ??
      (await Promise.race([
        Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.High }),
        new Promise<never>((_, reject) => setTimeout(() => reject(new Error('GPS timeout')), GPS_TIMEOUT_MS)),
      ]));
    return { status: 'ready', coords: { latitude: pos.coords.latitude, longitude: pos.coords.longitude } };
  } catch {
    return { status: 'unavailable', coords: null };
  }
}
