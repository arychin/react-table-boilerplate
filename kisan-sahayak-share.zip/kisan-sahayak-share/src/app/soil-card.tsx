import * as ImagePicker from 'expo-image-picker';
import { useEffect, useState } from 'react';
import { ActivityIndicator, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';

import { Button } from '@/components/ui/button';
import { MinTouchTarget, Spacing } from '@/constants/theme';
import { useApp } from '@/features/auth/app-context';
import { prepareImage } from '@/features/diagnosis/api';
import { choicesFor, loadSoilCard, readSoilCard, saveSoilCard, type CardRow, type Level, type SoilCard } from '@/features/soil-card/api';
import { useTheme } from '@/hooks/use-theme';

type Draft = Omit<SoilCard, 'saved_at'>;

// Vision Brief §3.15: photograph the card → app reads the printed values → farmer confirms/corrects → saved + explained.
export default function SoilCardScreen() {
  const { t, session } = useApp();
  const theme = useTheme();
  const farmerId = session?.user.id ?? '';
  const [saved, setSaved] = useState<SoilCard | null | undefined>(undefined);
  const [draft, setDraft] = useState<Draft | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [rescan, setRescan] = useState(false);

  useEffect(() => {
    loadSoilCard(farmerId).then(setSaved);
  }, [farmerId]);

  const scan = async (source: 'camera' | 'gallery') => {
    setError(null);
    if (source === 'camera' && !(await ImagePicker.requestCameraPermissionsAsync()).granted) {
      setError(t.cameraDenied);
      return;
    }
    const options: ImagePicker.ImagePickerOptions = { mediaTypes: ['images'], quality: 1, exif: false };
    const result = source === 'camera' ? await ImagePicker.launchCameraAsync(options) : await ImagePicker.launchImageLibraryAsync(options);
    const asset = result.canceled ? null : result.assets[0];
    if (!asset) return;
    setBusy(true);
    const image = await prepareImage({ uri: asset.uri, width: asset.width, height: asset.height, mimeType: asset.mimeType });
    const read = image ? await readSoilCard(image) : null;
    setBusy(false);
    if (read?.card) setDraft(read.card);
    else setError(t[read?.errorKey ?? 'errDiagnose']);
  };

  const confirm = async () => {
    if (!draft) return;
    setSaved(await saveSoilCard(farmerId, draft));
    setDraft(null);
    setRescan(false);
  };

  const editRow = (i: number, change: Partial<CardRow>) =>
    setDraft((d) => (d ? { ...d, rows: d.rows.map((r, j) => (j === i ? { ...r, ...change } : r)) } : d));

  if (saved === undefined || busy) {
    return (
      <View style={[styles.center, { backgroundColor: theme.background }]}>
        <ActivityIndicator size="large" color={theme.primary} />
        {busy && <Text style={[styles.stage, { color: theme.text }]}>{t.cardReading}</Text>}
      </View>
    );
  }

  return (
    <ScrollView style={{ backgroundColor: theme.background }} contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
      {draft ? (
        <>
          <Text style={[styles.title, { color: theme.text }]}>{t.cardConfirmTitle}</Text>
          <Text style={[styles.note, { color: theme.textSecondary }]}>{t.cardConfirmHint}</Text>
          {!!draft.sample_date && <Text style={[styles.note, { color: theme.text }]}>{t.cardSampleDate(draft.sample_date)}</Text>}
          {draft.rows.map((row, i) => (
            <View key={row.key} style={[styles.row, { backgroundColor: theme.backgroundElement }]}>
              <View style={styles.rowTop}>
                <Text style={[styles.param, { color: theme.text }]}>{t.cardParam[row.key]}</Text>
                <TextInput
                  value={row.value}
                  onChangeText={(value) => editRow(i, { value })}
                  keyboardType="decimal-pad"
                  accessibilityLabel={t.cardParam[row.key]}
                  style={[styles.input, { color: theme.text, borderColor: theme.border }]}
                />
                <Text style={[styles.unit, { color: theme.textSecondary }]}>{row.unit}</Text>
              </View>
              <View style={styles.chips}>
                {choicesFor(row.key).map((level) => (
                  <Chip key={level} label={t.cardLevel[level]} selected={row.level === level} onPress={() => editRow(i, { level })} />
                ))}
              </View>
            </View>
          ))}
          <Button label={t.cardSave} onPress={confirm} />
          <Button label={t.cardRescan} variant="secondary" onPress={() => setDraft(null)} />
        </>
      ) : saved && !rescan ? (
        <>
          <Text style={[styles.title, { color: theme.text }]}>{t.cardSavedTitle}</Text>
          {!!saved.sample_date && <Text style={[styles.note, { color: theme.textSecondary }]}>{t.cardSampleDate(saved.sample_date)}</Text>}
          {saved.rows.map((row) => (
            <View key={row.key} style={[styles.row, { backgroundColor: theme.backgroundElement }]}>
              <View style={styles.rowTop}>
                <Text style={[styles.param, { color: theme.text }]}>{t.cardParam[row.key]}</Text>
                <Text style={[styles.value, { color: theme.text }]}>{row.value} {row.unit}</Text>
                <LevelBadge level={row.level} />
              </View>
              {meaning(t, row) && <Text style={[styles.meaning, { color: theme.text }]}>{meaning(t, row)}</Text>}
            </View>
          ))}
          <View style={[styles.banner, { borderColor: theme.border }]}>
            <Text style={[styles.note, { color: theme.text }]}>{t.cardSavedNote}</Text>
          </View>
          <Button label={t.cardRescan} variant="secondary" onPress={() => setRescan(true)} />
        </>
      ) : (
        <>
          <Text style={[styles.title, { color: theme.text }]}>🪪 {t.soilCardTitle}</Text>
          <Text style={[styles.body, { color: theme.text }]}>{t.soilCardIntro}</Text>
          <Text style={[styles.note, { color: theme.textSecondary }]}>{t.soilCardPrivacy}</Text>
          {error && <Text style={[styles.error, { color: theme.danger }]}>{error}</Text>}
          <Button label={t.takePhoto} onPress={() => scan('camera')} />
          <Button label={t.pickPhoto} variant="secondary" onPress={() => scan('gallery')} />
        </>
      )}
    </ScrollView>
  );
}

/** Plain-language rules, not AI: what an out-of-range value means. Amounts always come from the card or KVK. */
function meaning(t: ReturnType<typeof useApp>['t'], row: CardRow): string | null {
  if (row.key === 'pH') return row.level === 'acidic' ? t.cardMeaningAcidic : row.level === 'alkaline' ? t.cardMeaningAlkaline : null;
  if (row.key === 'EC') return row.level === 'salty' ? t.cardMeaningSalty : null;
  if (row.level === 'low') return t.cardMeaningLow(t.cardRole[row.key]);
  if (row.level === 'high') return t.cardMeaningHigh;
  return null;
}

function Chip({ label, selected, onPress }: { label: string; selected: boolean; onPress: () => void }) {
  const theme = useTheme();
  return (
    <Pressable
      accessibilityRole="radio"
      aria-checked={selected}
      onPress={onPress}
      style={[styles.chip, { borderColor: theme.primary, backgroundColor: selected ? theme.primary : 'transparent' }]}>
      <Text style={[styles.chipText, { color: selected ? theme.onPrimary : theme.primary }]}>{label}</Text>
    </Pressable>
  );
}

function LevelBadge({ level }: { level: Level }) {
  const { t } = useApp();
  const theme = useTheme();
  const bad = ['low', 'high', 'acidic', 'alkaline', 'salty'].includes(level);
  return (
    <View style={[styles.badge, { backgroundColor: bad ? theme.warningBg : theme.successBg }]}>
      <Text style={[styles.badgeText, { color: bad ? theme.warning : theme.primary }]}>{t.cardLevel[level]}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: Spacing.three },
  content: { padding: Spacing.four, gap: Spacing.three, paddingBottom: Spacing.six },
  title: { fontSize: 22, fontWeight: '800' },
  body: { fontSize: 17, lineHeight: 25 },
  note: { fontSize: 15, lineHeight: 22 },
  stage: { fontSize: 18, fontWeight: '700' },
  error: { fontSize: 16, fontWeight: '600' },
  row: { borderRadius: Spacing.three, padding: Spacing.three, gap: Spacing.two },
  rowTop: { flexDirection: 'row', alignItems: 'center', gap: Spacing.two },
  param: { flex: 1, fontSize: 16, fontWeight: '700' },
  input: { minWidth: 80, minHeight: MinTouchTarget, borderWidth: 1.5, borderRadius: Spacing.two, paddingHorizontal: Spacing.two, fontSize: 17, textAlign: 'right' },
  unit: { minWidth: 44, fontSize: 14 },
  value: { fontSize: 16, fontWeight: '600' },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.two },
  chip: { minHeight: MinTouchTarget, borderWidth: 1.5, borderRadius: Spacing.five, paddingHorizontal: Spacing.three, justifyContent: 'center' },
  chipText: { fontSize: 15, fontWeight: '700' },
  badge: { borderRadius: Spacing.five, paddingHorizontal: Spacing.two, paddingVertical: 2 },
  badgeText: { fontSize: 14, fontWeight: '700' },
  meaning: { fontSize: 15, lineHeight: 22 },
  banner: { borderWidth: 1.5, borderStyle: 'dashed', borderRadius: Spacing.three, padding: Spacing.three },
});
