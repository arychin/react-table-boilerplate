import { router, useFocusEffect } from 'expo-router';
import { useCallback, useState } from 'react';
import { ActivityIndicator, FlatList, Pressable, StyleSheet, Text, View } from 'react-native';

import { MinTouchTarget, Spacing } from '@/constants/theme';
import { useApp } from '@/features/auth/app-context';
import { listDiagnoses, type DiagnosisRow } from '@/features/diagnosis/api';
import { SavingsCard } from '@/features/savings/savings-card';
import { useTheme } from '@/hooks/use-theme';

const VERDICT_ICON = { not_needed: '🟢', wait_and_watch: '🟡', spray_recommended: '🔴' } as const;

export default function HistoryScreen() {
  const { language, t } = useApp();
  const theme = useTheme();
  const [rows, setRows] = useState<DiagnosisRow[] | null>(null);

  useFocusEffect(
    useCallback(() => {
      listDiagnoses().then(setRows);
    }, []),
  );

  if (rows === null) {
    return (
      <View style={[styles.center, { backgroundColor: theme.background }]}>
        <ActivityIndicator size="large" color={theme.primary} />
      </View>
    );
  }

  return (
    <FlatList
      style={{ backgroundColor: theme.background }}
      contentContainerStyle={styles.list}
      data={rows}
      keyExtractor={(row) => row.id}
      keyboardShouldPersistTaps="handled"
      ListHeaderComponent={<SavingsCard />}
      ListEmptyComponent={<Text style={[styles.empty, { color: theme.textSecondary }]}>{t.historyEmpty}</Text>}
      renderItem={({ item }) => (
        <Pressable
          accessibilityRole="button"
          onPress={() => router.push({ pathname: '/diagnosis/[id]', params: { id: item.id } })}
          style={({ pressed }) => [styles.row, { backgroundColor: theme.backgroundElement }, pressed && styles.pressed]}>
          <Text style={styles.icon}>{item.kind === 'soil' ? '🧪' : VERDICT_ICON[item.diagnosis.spray_decision]}</Text>
          <View style={styles.rowText}>
            <Text style={[styles.title, { color: theme.text }]} numberOfLines={2}>
              {item.kind === 'soil' ? item.diagnosis.soil_type : item.diagnosis.disease_name}
            </Text>
            <Text style={[styles.meta, { color: theme.textSecondary }]}>
              {item.kind === 'soil' ? t.soilTitle : item.diagnosis.crop_name} · {new Date(item.created_at).toLocaleDateString(language === 'hi' ? 'hi-IN' : 'en-IN')}
            </Text>
          </View>
        </Pressable>
      )}
    />
  );
}

const styles = StyleSheet.create({
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  list: { padding: Spacing.three, gap: Spacing.two },
  empty: { fontSize: 17, textAlign: 'center', marginTop: Spacing.six },
  row: { flexDirection: 'row', alignItems: 'center', gap: Spacing.three, padding: Spacing.three, borderRadius: Spacing.three, minHeight: MinTouchTarget },
  pressed: { opacity: 0.7 },
  icon: { fontSize: 22 },
  rowText: { flex: 1, gap: 2 },
  title: { fontSize: 17, fontWeight: '700' },
  meta: { fontSize: 14 },
});
