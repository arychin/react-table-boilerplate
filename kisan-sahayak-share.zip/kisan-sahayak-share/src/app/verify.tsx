import { router, useLocalSearchParams } from 'expo-router';
import { useEffect, useState } from 'react';
import { KeyboardAvoidingView, Platform, ScrollView, StyleSheet, Text, TextInput } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { Button } from '@/components/ui/button';
import { MinTouchTarget, Spacing } from '@/constants/theme';
import { sendOtp, verifyOtp } from '@/features/auth/api';
import { useApp } from '@/features/auth/app-context';
import { useTheme } from '@/hooks/use-theme';

const RESEND_SECONDS = 30;

export default function VerifyScreen() {
  const { phone } = useLocalSearchParams<{ phone: string }>();
  const { t } = useApp();
  const theme = useTheme();
  const [code, setCode] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [verifying, setVerifying] = useState(false);
  const [resendIn, setResendIn] = useState(RESEND_SECONDS);

  useEffect(() => {
    if (resendIn <= 0) return;
    const timer = setTimeout(() => setResendIn((s) => s - 1), 1000);
    return () => clearTimeout(timer);
  }, [resendIn]);

  async function onVerify(token: string) {
    setError(null);
    setVerifying(true);
    const { errorKey } = await verifyOtp(phone, token);
    setVerifying(false);
    // On success the session changes and the root guard swaps straight to the tabs.
    if (errorKey) setError(t[errorKey]);
  }

  async function onResend() {
    setError(null);
    setResendIn(RESEND_SECONDS);
    const { errorKey } = await sendOtp(phone);
    if (errorKey) setError(t[errorKey]);
  }

  return (
    <SafeAreaView style={[styles.flex, { backgroundColor: theme.background }]}>
      <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
          <Text style={[styles.title, { color: theme.text }]}>{t.otpTitle}</Text>
          <Text style={[styles.hint, { color: theme.textSecondary }]}>{t.otpSentTo(phone)}</Text>

          <TextInput
            value={code}
            onChangeText={(value) => {
              const next = value.replace(/\D/g, '').slice(0, 6);
              setCode(next);
              setError(null);
              if (next.length === 6) onVerify(next);
            }}
            keyboardType="number-pad"
            textContentType="oneTimeCode"
            autoComplete="sms-otp"
            maxLength={6}
            autoFocus
            accessibilityLabel={t.otpTitle}
            style={[
              styles.input,
              { color: theme.text, borderColor: error ? theme.danger : theme.border },
            ]}
          />
          {error && <Text style={[styles.error, { color: theme.danger }]}>{error}</Text>}

          <Button label={t.verify} onPress={() => onVerify(code)} loading={verifying} disabled={code.length !== 6} />
          <Button
            variant="secondary"
            label={resendIn > 0 ? t.resendIn(resendIn) : t.resend}
            onPress={onResend}
            disabled={resendIn > 0}
          />
          <Button variant="secondary" label={t.changeNumber} onPress={() => router.back()} />
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  content: { flexGrow: 1, padding: Spacing.four, paddingTop: Spacing.six, gap: Spacing.three },
  title: { fontSize: 28, fontWeight: '700' },
  hint: { fontSize: 16 },
  input: {
    borderWidth: 2,
    borderRadius: Spacing.three,
    minHeight: MinTouchTarget + 16,
    fontSize: 32,
    fontWeight: '700',
    letterSpacing: 12,
    textAlign: 'center',
  },
  error: { fontSize: 16, fontWeight: '600' },
});
