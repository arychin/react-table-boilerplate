import { useEffect, useState } from 'react';
import { Pressable, ScrollView, Text, View } from 'react-native';

import { DISTRICTS } from '@/constants/districts';
import { useApp } from '@/features/auth/app-context';
import { saveFertSaving } from '@/features/calculator/api';
import { bags, compareUsual, cost, DEFAULT_BAG_PRICE, fertiliserKg, toAcres, usualKg, type AreaUnit, type Fertiliser } from '@/features/calculator/compute';
import { FERT_CROPS, gfrFor, type FertCrop, type Npk } from '@/features/calculator/register';
import { AreaInput, Chip, ChipRow, fmt, num, NumberField, calcStyles as s, SectionTitle } from '@/features/calculator/ui';
import { useProfileDistrict } from '@/features/shops/use-nearby-shops';
import { useTheme } from '@/hooks/use-theme';

const FERTS: Fertiliser[] = ['urea', 'dap', 'mop'];
const oneDecimal = (n: number) => String(Math.round(n * 10) / 10);
const strings = (r: Record<Fertiliser, number>) => ({ urea: String(r.urea), dap: String(r.dap), mop: String(r.mop) });
const numbers = (r: Record<Fertiliser, string>) => ({ urea: num(r.urea), dap: num(r.dap), mop: num(r.mop) });

// Vision Brief §3.16 + D-41: the ICAR district recommendation (or the farmer's Soil Health Card) turned into bags and rupees.
export default function FertilizerCalculatorScreen() {
  const { t, language, session } = useApp();
  const theme = useTheme();
  const farmerId = session?.user.id ?? '';
  const profileDistrict = useProfileDistrict();
  const [picked, setPicked] = useState<string | null>(null);
  const [picking, setPicking] = useState(false);
  const [crop, setCrop] = useState<FertCrop>('rice');
  const [area, setArea] = useState('1');
  const [unit, setUnit] = useState<AreaUnit>('acre');
  const [own, setOwn] = useState(false);
  const [ownNpk, setOwnNpk] = useState(['', '', '']);
  const [price, setPrice] = useState(strings(DEFAULT_BAG_PRICE));
  const [usual, setUsual] = useState<Record<Fertiliser, string>>({ urea: '', dap: '', mop: '' });

  const district = picked ?? profileDistrict;
  const districtName = DISTRICTS.find((d) => d.en === district)?.[language] ?? district;
  const gfr = district ? gfrFor(district, crop) : null;
  const npk: Npk | null = own ? [num(ownNpk[0]), num(ownNpk[1]), num(ownNpk[2])] : (gfr?.npk ?? null);
  const acres = toAcres(num(area), unit);
  const prices = numbers(price);
  const need = npk && acres > 0 ? fertiliserKg(npk, acres) : null;
  const needCost = need ? cost(need, prices) : null;
  const usualBags = numbers(usual);
  const usualGiven = FERTS.some((f) => usualBags[f] > 0);
  const cmp = need && usualGiven ? compareUsual(need, usualKg(usualBags, acres), prices) : null;
  const saving = cmp ? Math.round(cmp.excessRupees) : null;
  const over = cmp?.over ?? [];
  const names = (fs: Fertiliser[]) => fs.map((f) => t.fertName[f]).join(', ');

  useEffect(() => {
    // Only the farmer's own comparison is kept; opening the screen without one leaves an earlier estimate alone.
    if (farmerId && saving !== null) saveFertSaving(farmerId, saving >= 50 ? saving : null);
  }, [farmerId, saving]);

  return (
    <ScrollView style={{ backgroundColor: theme.background }} contentContainerStyle={s.content} keyboardShouldPersistTaps="handled">
      <SectionTitle>{t.calcCrop}</SectionTitle>
      <ChipRow options={FERT_CROPS} value={crop} label={(c) => t.fertCropNames[c]} onChange={setCrop} />

      <SectionTitle>{t.fertDistrict}</SectionTitle>
      {district && !picking ? (
        <View style={[s.resultRow, { alignItems: 'center' }]}>
          <Text style={[s.strong, { color: theme.text, flex: 1 }]}>{districtName}</Text>
          <Pressable accessibilityRole="button" onPress={() => setPicking(true)} style={s.link}>
            <Text style={[s.linkText, { color: theme.primary }]}>{t.fertChange}</Text>
          </Pressable>
        </View>
      ) : (
        <>
          <Text style={[s.note, { color: theme.textSecondary }]}>{t.fertPickDistrict}</Text>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
            {DISTRICTS.map((d) => (
              <Chip
                key={d.en}
                label={d[language]}
                selected={d.en === district}
                onPress={() => {
                  setPicked(d.en);
                  setPicking(false);
                }}
              />
            ))}
          </View>
        </>
      )}

      {gfr && !picking && (
        <View style={[s.card, { backgroundColor: theme.successBg }]}>
          <Text style={[s.body, { color: theme.text }]}>{t.fertIcar(districtName ?? '', ...gfr.npk)}</Text>
          <Text style={[s.note, { color: theme.textSecondary }]}>{t.fertEarlier(...gfr.earlier)}</Text>
        </View>
      )}
      <Pressable accessibilityRole="button" onPress={() => setOwn(!own)} style={s.link}>
        <Text style={[s.linkText, { color: theme.primary }]}>{own ? t.sprayUseRegister : t.fertOwn}</Text>
      </Pressable>
      {own &&
        (['n', 'p', 'k'] as const).map((k, i) => (
          <NumberField
            key={k}
            label={t.fertNutrient[k]}
            value={ownNpk[i]}
            onChange={(v) => setOwnNpk((cur) => cur.map((x, j) => (j === i ? v : x)))}
            suffix="kg/ha"
          />
        ))}

      <AreaInput value={area} unit={unit} onValue={setArea} onUnit={setUnit} />

      <View style={[s.card, { backgroundColor: theme.backgroundElement, borderWidth: 2, borderColor: theme.primary }]}>
        <Text style={[s.strong, { color: theme.text }]}>{t.fertNeed}</Text>
        {!need ? (
          <Text style={[s.note, { color: theme.textSecondary }]}>{!npk ? t.fertPickDistrict : t.sprayNeedArea}</Text>
        ) : (
          <>
            {FERTS.map((f) => (
              <View key={f} style={s.resultRow}>
                <Text style={[s.resultLabel, { color: theme.text }]}>{t.fertName[f]}</Text>
                <View style={{ alignItems: 'flex-end' }}>
                  <Text style={[s.strong, { color: theme.text }]}>{t.fertKgBags(fmt(need[f]), oneDecimal(bags(need[f], f)))}</Text>
                  {usualGiven && <Text style={[s.note, { color: theme.textSecondary }]}>{t.fertYou(oneDecimal(usualBags[f] * acres))}</Text>}
                </View>
              </View>
            ))}
            <View style={s.resultRow}>
              <Text style={[s.resultLabel, { color: theme.text }]}>{t.fertCost}</Text>
              <Text style={[s.resultValue, { color: theme.text }]}>₹{fmt(needCost ?? 0)}</Text>
            </View>
            {cmp && (
              <>
                {!!over.length && (saving ?? 0) >= 50 && <Text style={[s.strong, { color: theme.primary }]}>{t.fertSaving(names(over), fmt(saving ?? 0))}</Text>}
                {!!cmp.short.length && <Text style={[s.strong, { color: theme.warning }]}>{t.fertShort(names(cmp.short))}</Text>}
                {!cmp.short.length && (saving ?? 0) < 50 && <Text style={[s.strong, { color: theme.primary }]}>{t.fertSame}</Text>}
              </>
            )}
          </>
        )}
      </View>

      <SectionTitle>{t.fertUsual}</SectionTitle>
      {FERTS.map((f) => (
        <NumberField key={f} label={t.fertName[f]} value={usual[f]} onChange={(v) => setUsual((u) => ({ ...u, [f]: v }))} suffix={t.fertBagsPerAcre} />
      ))}

      <SectionTitle>{t.fertBagPrice}</SectionTitle>
      {FERTS.map((f) => (
        <NumberField key={f} label={t.fertName[f]} value={price[f]} onChange={(v) => setPrice((p) => ({ ...p, [f]: v }))} suffix="₹" />
      ))}

      <Text style={[s.note, { color: theme.text }]}>{t.fertNote}</Text>
    </ScrollView>
  );
}
