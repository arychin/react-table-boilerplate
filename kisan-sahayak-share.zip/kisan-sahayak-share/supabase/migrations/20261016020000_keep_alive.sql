-- D-43: the free plan pauses a project after ~7 idle days (2026-10-16: app showed a blank page, host gave NXDOMAIN).
-- Every 12 h the database calls the project's own public API, so the gateway sees real traffic.
-- The anon key is read from Vault (put there from the shell), so no key is written in this repo.
create extension if not exists pg_cron;
create extension if not exists pg_net with schema extensions;

select cron.schedule(
  'keep-alive',
  '17 */12 * * *',
  $$
  select net.http_get(
    url := 'https://vbexwxzfmjjollhwpaop.supabase.co/auth/v1/health',
    headers := jsonb_build_object('apikey', (select decrypted_secret from vault.decrypted_secrets where name = 'keepalive_anon_key'))
  );
  $$
);
