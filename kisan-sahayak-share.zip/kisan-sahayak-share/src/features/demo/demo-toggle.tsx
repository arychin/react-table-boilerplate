import { useState } from 'react';
import { ActivityIndicator, Pressable, StyleSheet, Text } from 'react-native';

import { Spacing } from '@/constants/theme';
import { useApp } from '@/features/auth/app-context';
import { useTheme } from '@/hooks/use-theme';

// D-45: visible only for the judges' review, as a fail-safe if the server or an API is down. Set false before Play Store.
export const SHOW_DEMO_TOGGLE = true;

export function DemoToggle() {
  const { t, demo, setDemo } = useApp();
  const theme = useTheme();
  const [busy, setBusy] = useState(false);
  if (!SHOW_DEMO_TOGGLE) return null;

  const toggle = async () => {
    setBusy(true);
    await setDemo(!demo);
    setBusy(false);
  };

  return (
    <Pressable
      accessibilityRole="switch"
      accessibilityState={{ checked: demo, busy }}
      accessibilityLabel={t.demoToggleLabel}
      onPress={toggle}
      disabled={busy}
      hitSlop={8}
      style={({ pressed }) => [
        styles.pill,
        { borderColor: demo ? theme.warning : theme.border, backgroundColor: demo ? theme.warningBg : theme.background },
        pressed && styles.pressed,
      ]}>
      {busy ? <ActivityIndicator size="small" color={theme.warning} /> : <Text style={[styles.dot, { color: demo ? theme.warning : theme.textSecondary }]}>{demo ? '●' : '○'}</Text>}
      <Text style={[styles.text, { color: demo ? theme.warning : theme.textSecondary }]}>{demo ? t.demoToggleOn : t.demoToggleOff}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  pill: { flexDirection: 'row', alignItems: 'center', gap: Spacing.one, borderWidth: 1.5, borderRadius: Spacing.five, paddingHorizontal: Spacing.three, minHeight: 36 },
  dot: { fontSize: 12 },
  text: { fontSize: 14, fontWeight: '700' },
  pressed: { opacity: 0.6 },
});
