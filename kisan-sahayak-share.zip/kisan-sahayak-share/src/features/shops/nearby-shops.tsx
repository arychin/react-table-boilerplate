import { router } from 'expo-router';
import { StyleSheet, Text, View } from 'react-native';

import { Button } from '@/components/ui/button';
import { Spacing } from '@/constants/theme';
import { useApp } from '@/features/auth/app-context';
import { useTheme } from '@/hooks/use-theme';

import { ShopCard } from './shop-card';
import { useNearbyShops } from './use-nearby-shops';

const SHOWN = 3;

// Below a crop or soil result. Does not ask for location on its own — only on tap.
// product (soil, Vision Brief §3.4): the fertiliser to ask for. We don't know stock, so it only labels, never filters.
export function NearbyShops({ product }: { product?: string }) {
  const { t } = useApp();
  const theme = useTheme();
  const { shops, location } = useNearbyShops(false);
  const askable = location.status === 'needs-permission' || location.status === 'unavailable';

  return (
    <View style={styles.section}>
      <Text style={[styles.title, { color: theme.text }]}>{product ? t.shopsForProduct(product) : t.shopsForTreatment}</Text>
      {location.status === 'locating' && <Text style={[styles.note, { color: theme.textSecondary }]}>{t.shopsLocating}</Text>}
      {shops.slice(0, SHOWN).map((shop) => (
        <ShopCard key={shop.id} shop={shop} />
      ))}
      {askable && <Button label={t.shopsUseLocation} variant="secondary" onPress={location.locate} />}
      <Button label={t.allShops} variant="secondary" onPress={() => router.push({ pathname: '/shops', params: product ? { product } : {} })} />
    </View>
  );
}

const styles = StyleSheet.create({
  section: { gap: Spacing.two },
  title: { fontSize: 18, fontWeight: '800' },
  note: { fontSize: 16 },
});
