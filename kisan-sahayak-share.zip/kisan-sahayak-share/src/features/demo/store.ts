// Phase 9 Demo Mode (D-44): what the demo farmer "has" this session. Nothing here touches the network.
import type { Language } from '@/constants/strings';
import type { ChatMessage } from '@/features/chat/api';
import type { DiagnosisRow } from '@/features/diagnosis/api';
import type { DueFollowUp, Outcome } from '@/features/follow-up/api';
import type { SavingsInput } from '@/features/savings/compute';
import type { Kind } from '@/types/diagnosis';

import { DEMO_AUDIO, DEMO_CHAT_ANSWER, DEMO_PHOTO, DEMO_RICE, DEMO_SOIL, DEMO_SUMMARY, DEMO_TOMATO } from './data';

type Key = 'tomato' | 'rice' | 'soil';
type DemoRow = { id: string; key: Key; created_at: string; localUri?: string };

let language: Language = 'hi';
let created: DemoRow[] = [];
let followUp: { outcome: Outcome; applied: boolean | null } | null = null;
let chat: ChatMessage[] = [];
let counter = 0;

export const setDemoLanguage = (next: Language) => {
  language = next;
};

export function resetDemo() {
  created = [];
  followUp = null;
  chat = [];
}

const daysAgo = (n: number) => new Date(Date.now() - n * 86_400_000).toISOString();
// Seeded history: the tomato check (follow-up due today), a soil check, and a healthy paddy check that needed no spray.
const seeds = (): DemoRow[] => [
  { id: 'demo-tomato', key: 'tomato', created_at: daysAgo(3) },
  { id: 'demo-soil', key: 'soil', created_at: daysAgo(5) },
  { id: 'demo-rice', key: 'rice', created_at: daysAgo(12) },
];
const IMAGE_PATH: Record<Key, string> = { tomato: 'demo/tomato.jpg', soil: 'demo/soil.jpg', rice: 'demo/rice.jpg' };

function toRow(r: DemoRow): DiagnosisRow & { localUri?: string } {
  const base = { id: r.id, created_at: r.created_at, image_url: IMAGE_PATH[r.key], localUri: r.localUri };
  return r.key === 'soil'
    ? { ...base, kind: 'soil', diagnosis: DEMO_SOIL[language] }
    : { ...base, kind: 'crop', diagnosis: (r.key === 'rice' ? DEMO_RICE : DEMO_TOMATO)[language] };
}

const allRows = () => [...created, ...seeds()];

export const demoListRows = () => allRows().map(toRow);

export function demoFindRow(id: string) {
  const r = allRows().find((x) => x.id === id);
  return r ? toRow(r) : null;
}

/** A new check always gives the Vision Brief's demo answer for its kind; the farmer's own photo is shown with it. */
export function demoAddDiagnosis(kind: Kind, localUri: string): string {
  counter += 1;
  const row: DemoRow = { id: `demo-new-${counter}`, key: kind === 'soil' ? 'soil' : 'tomato', created_at: new Date().toISOString(), localUri };
  created = [row, ...created];
  return row.id;
}

export function demoImage(path: string): number | null {
  return path === IMAGE_PATH.tomato ? DEMO_PHOTO.crop : path === IMAGE_PATH.soil ? DEMO_PHOTO.soil : null;
}

export function demoBolo(diagnosisId: string): { source: number; summary: string } | null {
  const key = allRows().find((x) => x.id === diagnosisId)?.key;
  return key ? { source: DEMO_AUDIO[key], summary: DEMO_SUMMARY[key] } : null;
}

export function demoDueFollowUp(): DueFollowUp | null {
  if (followUp) return null;
  const d = DEMO_TOMATO[language];
  return { id: 'demo-follow-up', diagnosisId: 'demo-tomato', daysAgo: 3, crop: d.crop_name, problem: d.disease_name, askApplied: true };
}

export function demoAnswerFollowUp(outcome: Outcome, applied: boolean | null) {
  followUp = { outcome, applied };
}

export function demoSavingsInputs(): SavingsInput[] {
  const crop = allRows().filter((r) => r.key !== 'soil');
  return crop.map((r) => {
    const d = (r.key === 'rice' ? DEMO_RICE : DEMO_TOMATO)[language];
    const answer = r.key === 'rice' ? { response: 'no_change' as const, applied: null } : r.id === 'demo-tomato' && followUp ? { response: followUp.outcome, applied: followUp.applied } : { response: null, applied: null };
    return { spray_decision: d.spray_decision, confidence: d.confidence, ...answer };
  });
}

export const demoChatHistory = () => [...chat];

export function demoChatSend(message: string, lang: Language): ChatMessage {
  const at = Date.now();
  const reply: ChatMessage = { id: `demo-a-${at}`, role: 'assistant', content: DEMO_CHAT_ANSWER[lang], created_at: new Date(at + 1).toISOString() };
  chat = [...chat, { id: `demo-q-${at}`, role: 'user', content: message, created_at: new Date(at).toISOString() }, reply];
  return reply;
}
