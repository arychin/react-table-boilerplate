import { Linking, Pressable, StyleSheet, Text, View } from 'react-native';

import { MinTouchTarget, Spacing } from '@/constants/theme';
import { useApp } from '@/features/auth/app-context';
import { useTheme } from '@/hooks/use-theme';

import { directionsUrl, districtLabel, type ShopHit } from './find-shops';

// Vision Brief §3.7 card: name, type, distance, Call, Directions.
export function ShopCard({ shop }: { shop: ShopHit }) {
  const { t, language } = useApp();
  const theme = useTheme();
  const type = t.shopType[shop.type as keyof typeof t.shopType] ?? shop.type;
  const where = shop.district ? districtLabel(shop.district, language) : null;

  return (
    <View style={[styles.card, { backgroundColor: theme.backgroundElement }]}>
      <View style={styles.top}>
        <Text style={[styles.name, { color: theme.text }]} numberOfLines={2}>{shop.name}</Text>
        <Text style={[styles.distance, { color: shop.distanceKm === null ? theme.textSecondary : theme.primary }]}>
          {shop.distanceKm === null ? t.distanceUnknown : t.distance(shop.distanceKm)}
        </Text>
      </View>
      <Text style={[styles.meta, { color: theme.textSecondary }]}>{[type, where].filter(Boolean).join(' · ')}</Text>
      <Text style={[styles.address, { color: theme.text }]} numberOfLines={2}>{shop.address}</Text>
      {shop.source === 'osm' && <Text style={[styles.credit, { color: theme.textSecondary }]}>{t.osmCredit}</Text>}
      <View style={styles.actions}>
        {shop.phone && <Action label={`📞 ${t.call}`} onPress={() => Linking.openURL(`tel:${shop.phone}`)} />}
        <Action label={`📍 ${t.directions}`} onPress={() => Linking.openURL(directionsUrl(shop))} />
      </View>
    </View>
  );
}

function Action({ label, onPress }: { label: string; onPress: () => void }) {
  const theme = useTheme();
  return (
    <Pressable
      accessibilityRole="button"
      onPress={onPress}
      style={({ pressed }) => [styles.action, { borderColor: theme.primary }, pressed && styles.pressed]}>
      <Text style={[styles.actionText, { color: theme.primary }]}>{label}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: { borderRadius: Spacing.three, padding: Spacing.three, gap: Spacing.one },
  top: { flexDirection: 'row', alignItems: 'flex-start', gap: Spacing.two },
  name: { flex: 1, fontSize: 18, fontWeight: '800', lineHeight: 24 },
  distance: { fontSize: 16, fontWeight: '800', lineHeight: 24 },
  meta: { fontSize: 14, fontWeight: '600' },
  address: { fontSize: 15, lineHeight: 21 },
  credit: { fontSize: 12 },
  actions: { flexDirection: 'row', gap: Spacing.two, marginTop: Spacing.two },
  action: {
    flex: 1,
    minHeight: MinTouchTarget,
    borderWidth: 1.5,
    borderRadius: Spacing.three,
    alignItems: 'center',
    justifyContent: 'center',
  },
  actionText: { fontSize: 17, fontWeight: '700' },
  pressed: { opacity: 0.6 },
});
