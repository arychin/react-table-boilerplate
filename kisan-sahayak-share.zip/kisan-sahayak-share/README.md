# Kisan Sahayak — Smart Kheti Ka Naya Saathi

AI advisory agent for smallholder farmers in Chhattisgarh.

## Specifications
- PRD: [docs/Kisan_Sahayak_Vision_Brief_v4_FINAL.pdf](docs/Kisan_Sahayak_Vision_Brief_v4_FINAL.pdf)
- TRD: [docs/Kisan_Sahayak_TRD_v1.pdf](docs/Kisan_Sahayak_TRD_v1.pdf)
- Build order: [docs/Kisan_Sahayak_Implementation_Plan_v1.pdf](docs/Kisan_Sahayak_Implementation_Plan_v1.pdf)
- Process: [docs/Kisan_Sahayak_Working_Instructions.md](docs/Kisan_Sahayak_Working_Instructions.md)

## Project history
- [project_memory/](project_memory/) — full log, architecture, decisions, current state
- [decisions.md](decisions.md) and [flow.md](flow.md) — per-session summary and execution flow

## Run
1. `npm install`
2. `python3 scripts/load_secrets.py --write-client-env .env` (writes the two public Supabase values only)
3. `npx expo start`

See [CLAUDE.md](CLAUDE.md) for commands and rules.

**New laptop?** See [SETUP_PERSONAL_LAPTOP.md](SETUP_PERSONAL_LAPTOP.md).
