import AsyncStorage from '@react-native-async-storage/async-storage';
import { useFocusEffect } from 'expo-router';
import { useCallback, useState } from 'react';

import { fetchFarmer } from '@/features/auth/api';
import { useApp } from '@/features/auth/app-context';
import { useDeviceLocation } from '@/hooks/use-device-location';

import { findShops } from './find-shops';

const DISTRICT_KEY = 'ks.profileDistrict';

/** Shared by the Shops tab and the diagnosis result screen (TRD §6.5: one implementation, three call sites). */
export function useNearbyShops(askLocation: boolean, query = '') {
  const location = useDeviceLocation(askLocation);
  const district = useProfileDistrict();
  return { ...findShops({ from: location.coords, district, query }), location };
}

/** The district saved in the farmer's profile. Cached on the phone so the fallback also works offline. */
export function useProfileDistrict(): string | null {
  const { session } = useApp();
  const farmerId = session?.user.id;
  const [district, setDistrict] = useState<string | null>(null);

  useFocusEffect(
    useCallback(() => {
      if (!farmerId) return;
      const key = `${DISTRICT_KEY}.${farmerId}`;
      AsyncStorage.getItem(key).then((cached) => cached && setDistrict((current) => current ?? cached));
      fetchFarmer(farmerId).then((farmer) => {
        if (!farmer) return; // offline (supabase returns null, it doesn't throw): keep the cached district
        setDistrict(farmer.district);
        if (farmer.district) AsyncStorage.setItem(key, farmer.district);
        else AsyncStorage.removeItem(key);
      });
    }, [farmerId]),
  );

  return district;
}
