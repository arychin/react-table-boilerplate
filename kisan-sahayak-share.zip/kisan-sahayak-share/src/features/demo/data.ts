// Phase 9 Demo Mode dataset (Vision Brief §3.9 table, D-44). Tomato text is real Gemini output from the live pipeline
// (scripts/make_demo_assets.mjs); "अंगीमारी" corrected to the standard "अगेती अंगमारी". Audio is real Sarvam output.
// Photos: Wikimedia Commons — "Alternaria solani - leaf lesions" (CC BY 3.0 US); "Red soil.jpg" by Ecofoodforest (CC BY-SA 4.0).
import type { Language } from '@/constants/strings';
import type { Weather } from '@/features/weather/api';
import type { Diagnosis, SoilReport } from '@/types/diagnosis';

export const DEMO_FARMER_ID = '00000000-0000-4000-8000-00000000de30';

export const DEMO_PHOTO = {
  crop: require('@/assets/demo/tomato_early_blight.jpg') as number,
  soil: require('@/assets/demo/soil_sandy_loam.jpg') as number,
};
export const DEMO_AUDIO = {
  tomato: require('@/assets/demo/bolo_tomato.mp3') as number,
  soil: require('@/assets/demo/bolo_soil.mp3') as number,
  rice: require('@/assets/demo/bolo_rice.mp3') as number,
};

export const DEMO_TOMATO: Record<Language, Diagnosis> = {
  hi: {
    crop_name: 'टमाटर (Tomato)',
    disease_name: 'अगेती अंगमारी / अगेती झुलसा [Early Blight / Alternaria solani]',
    cause: 'यह एक फफूंद (फंगस) के कारण होता है जो पत्तियों पर काले या भूरे रंग के गोल धब्बे बनाता है।',
    severity: 'medium',
    confidence: 'high',
    spray_decision: 'spray_recommended',
    decision_reason: 'पत्तियों पर साफ गोल घेरे वाले काले और भूरे धब्बे दिखाई दे रहे हैं, जो बीमारी के फैलने का संकेत है।',
    treatment: 'मैनकोजेब आधारित फफूंदनाशक (Mancozeb-based fungicide)',
    treatment_steps: [
      'दवा छिड़कते समय हाथों में दस्ताने और चेहरे पर मास्क जरूर लगाएं।',
      'दवा का छिड़काव सुबह या शाम के समय शांत मौसम में करें।',
      'उत्पाद के पैकेट पर लिखे निर्देशों का सावधानी से पालन करें।',
    ],
    prevention_tips: ['अगली फसल में स्वस्थ बीजों का चयन करें।', 'खेत में पानी जमा न होने दें और सही दूरी पर पौधे लगाएं।', 'रोग ग्रसित पत्तियों को इकट्ठा करके नष्ट कर दें।'],
    organic_alternative: 'नीम आधारित कीटनाशक या फफूंदनाशक का छिड़काव शुरुआती अवस्था में मददगार हो सकता है।',
  },
  en: {
    crop_name: 'Tomato',
    disease_name: 'Early Blight [Alternaria solani]',
    cause: 'A fungus that grows well in warm, humid weather and wet leaves.',
    severity: 'medium',
    confidence: 'high',
    spray_decision: 'spray_recommended',
    decision_reason: 'Dark spots with ring patterns and dying leaf edges are clearly visible, which can spread fast in warm and wet weather.',
    treatment: 'A chlorothalonil or mancozeb-based protective fungicide.',
    treatment_steps: [
      'Wear clean gloves and a face mask before handling any product.',
      'Carefully follow the instructions written on the product label.',
      'Spray uniformly in calm weather during the morning or evening.',
      'Remove and safely bury heavily damaged leaves to stop further spread.',
    ],
    prevention_tips: [
      'Use healthy, disease-free seeds or seedlings for planting.',
      'Keep proper distance between plants so air can pass freely.',
      'Water the soil directly instead of wetting the leaves.',
      'Rotate your crops every season with non-related plants.',
    ],
    organic_alternative: 'Neem-based oil spray can help if applied early when spots first appear.',
  },
};

// A healthy paddy check from 12 days ago whose follow-up said "no change": gives the Savings card a real "no spray" story.
export const DEMO_RICE: Record<Language, Diagnosis> = {
  hi: {
    crop_name: 'धान (Rice)',
    disease_name: 'स्वस्थ फसल — कोई रोग नहीं दिखा',
    cause: 'पत्तियाँ हरी और साफ़ हैं; किसी कीट या रोग का निशान नहीं दिखा।',
    severity: 'low',
    confidence: 'high',
    spray_decision: 'not_needed',
    decision_reason: 'कोई धब्बा, छेद या पीलापन नहीं — अभी दवा की ज़रूरत नहीं। पैसा बचाएँ और हर 3–5 दिन में खेत देखते रहें।',
    treatment: 'अभी कोई इलाज ज़रूरी नहीं',
    treatment_steps: ['हर 3–5 दिन में खेत की 5 जगह पौधे देखें।', 'कोई नया धब्बा या कीट दिखे तो फिर से फोटो लें।'],
    prevention_tips: ['यूरिया सिफ़ारिश से ज़्यादा न डालें — ज़्यादा नाइट्रोजन से माहू बढ़ता है।', 'मेड़ और खेत के आसपास खरपतवार साफ़ रखें।'],
  },
  en: {
    crop_name: 'Paddy (Rice)',
    disease_name: 'Healthy crop — no disease seen',
    cause: 'The leaves are green and clean; no sign of pests or disease.',
    severity: 'low',
    confidence: 'high',
    spray_decision: 'not_needed',
    decision_reason: 'No spots, holes or yellowing — no spray is needed now. Save the money and keep checking the field every 3–5 days.',
    treatment: 'No treatment needed now',
    treatment_steps: ['Every 3–5 days, look at plants in 5 spots of the field.', 'If new spots or insects appear, take a new photo.'],
    prevention_tips: ['Do not put more urea than recommended — extra nitrogen increases planthoppers.', 'Keep bunds and field edges free of weeds.'],
  },
};

export const DEMO_SOIL: Record<Language, SoilReport> = {
  hi: {
    soil_type: 'बलुई दोमट (Sandy Loam)',
    moisture: 'low',
    confidence: 'medium',
    observations: 'मिट्टी हल्के भूरे-लाल रंग की, भुरभुरी और दानेदार दिख रही है — रेत ज़्यादा, चिकनी मिट्टी कम। सतह सूखी है और सड़ी पत्तियाँ या गोबर जैसी जैविक चीज़ें कम दिख रही हैं।',
    possible_deficiencies: ['नाइट्रोजन — हल्का रंग और कम जैविक पदार्थ', 'पोटाश — रेतीली मिट्टी पोषक तत्व कम रोक पाती है'],
    fertilisers: [
      { name: 'NPK 19:19:19 (पानी में घुलने वाली खाद)', why: 'तीनों मुख्य पोषक तत्व बराबर; रेतीली मिट्टी में एक साथ ज़्यादा देने के बजाय कई बार थोड़ा देने के लिए ठीक' },
      { name: 'गोबर की सड़ी खाद / वर्मी कम्पोस्ट', why: 'मिट्टी की पानी और पोषक रोकने की ताक़त बढ़ाती है' },
    ],
    improvement_tips: ['खेत में सड़ी गोबर खाद या हरी खाद मिलाएँ', 'कम पानी से, पर ज़्यादा बार सिंचाई करें', 'पुआल या सूखी पत्तियों से मल्चिंग करें — नमी बचेगी'],
  },
  en: {
    soil_type: 'Sandy loam',
    moisture: 'low',
    confidence: 'medium',
    observations: 'Light brown-red, loose and grainy soil — more sand than clay. The surface is dry and there is little visible organic matter such as rotted leaves or manure.',
    possible_deficiencies: ['Nitrogen — light colour and little organic matter', 'Potash — sandy soil holds nutrients poorly'],
    fertilisers: [
      { name: 'NPK 19:19:19 (water-soluble)', why: 'Equal main nutrients; suits sandy soil when given little and often rather than all at once' },
      { name: 'Well-rotted farmyard manure / vermicompost', why: 'Helps the soil hold water and nutrients' },
    ],
    improvement_tips: ['Mix in rotted manure or green manure', 'Irrigate lightly but more often', 'Mulch with straw or dry leaves to keep moisture'],
  },
};

export const DEMO_SUMMARY = {
  tomato: 'आपकी टमाटर की फसल में अगेती अंगमारी रोग के लक्षण दिखाई दे रहे हैं। इसके बचाव के लिए मैंकोजेब आधारित फफूंदनाशक का छिड़काव करें। छिड़काव करने से पहले अपने नजदीकी कृषि केंद्र या खाद विक्रेता से सलाह जरूर लें।',
  soil: 'राम राम किसान भाई, आपकी यह बलुई दोमट मिट्टी सूखी दिख रही है और इसमें नमी बहुत कम है। खेत में नमी बनाए रखने के लिए सड़ी हुई गोबर की खाद या वर्मी कम्पोस्ट मिलाएँ और हल्की सिंचाई करें। यह जानकारी केवल एक अंदाज़ा है, इसलिए पक्की मात्रा जानने के लिए अपने पास के कृषि केंद्र जाकर मिट्टी की जाँच ज़रूर करवाएँ।',
  rice: 'आपकी धान की फसल बिल्कुल हरी और साफ़ है। अभी खेत में किसी भी दवा की कोई ज़रूरत नहीं है। बस अपनी फसल पर लगातार नज़र बनाए रखें।',
};

// Brown planthopper advice (Vision Brief §3.9 example) from the NIPHM Rice IPM package: ETL 10–15/hill, drain 3–4 days, no excess N.
export const DEMO_CHAT_ANSWER: Record<Language, string> = {
  hi: 'भूरा माहू पौधे के निचले हिस्से में, पानी के पास तने पर बैठता है।\n\n1. पहले गिनें: खेत की 5 जगह, हर जगह 4 पौधों के नीचे देखें। हर पौधे पर 10–15 से कम माहू हों तो दवा की ज़रूरत नहीं।\n2. ज़्यादा माहू हों तो खेत का पानी 3–4 दिन के लिए निकाल दें।\n3. यूरिया सिफ़ारिश से ज़्यादा न डालें, और किस्तों में डालें — ज़्यादा नाइट्रोजन से माहू बढ़ता है।\n4. दवा चाहिए तो धान के माहू के लिए सरकारी सूची में दर्ज दवा ही लें और लेबल पर लिखी मात्रा में पौधे के निचले हिस्से पर छिड़कें। ऐप का "दवा का घोल" हिसाब मदद करेगा।\n\nपक्का करने के लिए KVK या किसान कॉल सेंटर 1800-180-1551 (मुफ़्त) से बात करें।',
  en: 'Brown planthoppers sit low on the stem, near the water.\n\n1. Count first: look at the base of 4 plants in 5 spots. Fewer than 10–15 hoppers per plant means no spray is needed.\n2. If there are more, drain the field for 3–4 days.\n3. Do not put more urea than recommended, and split it — extra nitrogen increases planthoppers.\n4. If a spray is needed, use only a product registered for paddy planthopper, at the label amount, aimed at the base of the plants. The app\'s "Spray mix" calculator will help.\n\nConfirm with your KVK or the Kisan Call Centre 1800-180-1551 (free).',
};

export const DEMO_WEATHER: Omit<Weather, 'observed_at'> = {
  place: 'Durg',
  condition: 'Clouds',
  temp_c: 29,
  temp_max_c: 32,
  humidity: 74,
  wind_kmh: 7,
  rain_chance: 20,
};

// Same shape the read-soil-card function returns; values in typical Chhattisgarh ranges, invented.
export const DEMO_SOIL_CARD = {
  is_soil_health_card: true,
  sample_date: '12/03/2026',
  parameters: [
    { key: 'pH' as const, value: '6.2', unit: '', rating: 'Slightly acidic' },
    { key: 'EC' as const, value: '0.31', unit: 'dS/m', rating: 'Normal' },
    { key: 'OC' as const, value: '0.42', unit: '%', rating: 'Low' },
    { key: 'N' as const, value: '210', unit: 'kg/ha', rating: 'Low' },
    { key: 'P' as const, value: '18', unit: 'kg/ha', rating: 'Medium' },
    { key: 'K' as const, value: '245', unit: 'kg/ha', rating: 'Medium' },
    { key: 'S' as const, value: '9', unit: 'ppm', rating: 'Low' },
    { key: 'Zn' as const, value: '0.5', unit: 'ppm', rating: 'Deficient' },
    { key: 'B' as const, value: '0.4', unit: 'ppm', rating: 'Deficient' },
    { key: 'Fe' as const, value: '12.0', unit: 'ppm', rating: 'Sufficient' },
    { key: 'Mn' as const, value: '8.1', unit: 'ppm', rating: 'Sufficient' },
    { key: 'Cu' as const, value: '0.9', unit: 'ppm', rating: 'Sufficient' },
  ],
};

// Matches the CIB&RC register exactly (Chlorantraniliprole 18.50% SC → paddy 150 ml/ha).
export const DEMO_LABEL = { is_pesticide_label: true, brand_name: 'KHETRAJ', composition: 'Chlorantraniliprole 18.5% w/w SC' };
