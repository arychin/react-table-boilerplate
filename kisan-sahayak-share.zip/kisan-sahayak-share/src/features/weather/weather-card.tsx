import { useEffect, useState } from 'react';
import { ActivityIndicator, StyleSheet, Text, View } from 'react-native';

import { Button } from '@/components/ui/button';
import { Spacing } from '@/constants/theme';
import { useApp } from '@/features/auth/app-context';
import { useDeviceLocation } from '@/hooks/use-device-location';
import { useTheme } from '@/hooks/use-theme';

import { adviceFor } from './advice';
import { fetchWeather, type Weather } from './api';

const ICON: Record<string, string> = { Clear: '☀️', Clouds: '☁️', Rain: '🌧️', Drizzle: '🌦️', Thunderstorm: '⛈️' };

// Vision Brief §3.5: current local weather + 1–2 lines of practical advice. Uses an already-granted location only.
export function WeatherCard() {
  const { t, language } = useApp();
  const theme = useTheme();
  const location = useDeviceLocation(false);
  const [result, setResult] = useState<{ weather: Weather | null; offline: boolean } | null>(null);
  const lat = location.coords?.latitude;
  const lng = location.coords?.longitude;

  useEffect(() => {
    if (lat !== undefined && lng !== undefined) fetchWeather({ latitude: lat, longitude: lng }).then(setResult);
  }, [lat, lng]);

  const box = [styles.card, { backgroundColor: theme.backgroundElement }];
  if (location.status !== 'ready' && location.status !== 'locating') {
    return (
      <View style={box}>
        <Text style={[styles.title, { color: theme.text }]}>🌦️ {t.weatherTitle}</Text>
        <Text style={[styles.note, { color: theme.textSecondary }]}>{location.status === 'denied' ? t.weatherDenied : t.weatherNeedsLocation}</Text>
        {location.status !== 'denied' && <Button label={t.weatherUseLocation} variant="secondary" onPress={location.locate} />}
      </View>
    );
  }
  if (!result) {
    return (
      <View style={[box, styles.row]}>
        <ActivityIndicator color={theme.primary} />
        <Text style={[styles.note, { color: theme.textSecondary }]}>{t.weatherLoading}</Text>
      </View>
    );
  }
  const w = result.weather;
  if (!w) {
    return (
      <View style={box}>
        <Text style={[styles.title, { color: theme.text }]}>🌦️ {t.weatherTitle}</Text>
        <Text style={[styles.note, { color: theme.textSecondary }]}>{result.offline ? t.weatherOffline : t.weatherUnavailable}</Text>
      </View>
    );
  }

  const time = new Date(w.observed_at).toLocaleTimeString(language === 'hi' ? 'hi-IN' : 'en-IN', { hour: 'numeric', minute: '2-digit' });
  return (
    <View style={box} accessibilityRole="summary">
      <View style={styles.row}>
        <Text style={styles.icon}>{ICON[w.condition] ?? '🌫️'}</Text>
        <View style={styles.flex}>
          <Text style={[styles.temp, { color: theme.text }]}>{w.temp_c}°C · {t.weatherCondition[w.condition as keyof typeof t.weatherCondition] ?? t.weatherCondition.Mist}</Text>
          <Text style={[styles.note, { color: theme.textSecondary }]}>{[w.place, t.weatherAt(time)].filter(Boolean).join(' · ')}</Text>
        </View>
      </View>
      <Text style={[styles.facts, { color: theme.text }]}>
        {t.weatherRain(w.rain_chance)}   {t.weatherHumidity(w.humidity)}   {t.weatherWind(w.wind_kmh)}
      </Text>
      {adviceFor(w).map((key) => (
        <Text key={key} style={[styles.advice, { color: theme.primary }]}>👉 {t.weatherAdvice[key]}</Text>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  card: { borderRadius: Spacing.four, padding: Spacing.three, gap: Spacing.two },
  row: { flexDirection: 'row', alignItems: 'center', gap: Spacing.three },
  flex: { flex: 1 },
  icon: { fontSize: 36 },
  title: { fontSize: 18, fontWeight: '800' },
  temp: { fontSize: 22, fontWeight: '800' },
  facts: { fontSize: 16, fontWeight: '600' },
  advice: { fontSize: 17, fontWeight: '700', lineHeight: 24 },
  note: { fontSize: 15, lineHeight: 21 },
});
