// TRD §6.2 standalone Bolo function: returns a short-lived URL to the cached Hindi audio for a diagnosis.
// diagnose-crop normally prepares it in the background; this generates it only if that hasn't happened.
import { BOLO_BUCKET, boloPath, type Kind, prepareBolo } from '../_shared/bolo.ts';
import type { Diagnosis } from '../_shared/diagnosis.ts';
import { adminClient, cors, fail, signedInFarmer } from '../_shared/http.ts';
import type { SoilReport } from '../_shared/soil.ts';

const URL_TTL_SECONDS = 600; // TRD §8: short-lived signed URLs only
const BACKGROUND_WINDOW_MS = 25_000; // diagnose-crop's background job normally finishes well inside this
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  if (req.method !== 'POST') return fail(405, 'method_not_allowed');

  const t0 = performance.now();
  const ms: Record<string, number> = {};
  const mark = (step: string) => { ms[step] = Math.round(performance.now() - t0); };

  const farmerId = signedInFarmer(req);
  if (!farmerId) return fail(401, 'unauthorized');
  const body = await req.json().catch(() => null) as { diagnosis_id?: unknown } | null;
  const diagnosisId = typeof body?.diagnosis_id === 'string' && UUID.test(body.diagnosis_id) ? body.diagnosis_id : null;
  if (!diagnosisId) return fail(400, 'bad_request');

  const admin = adminClient();
  // The path comes from the verified JWT, so the cache check can only ever touch the caller's own folder.
  const audioPath = boloPath(farmerId, diagnosisId);
  const signCached = () => admin.storage.from(BOLO_BUCKET).createSignedUrl(audioPath, URL_TTL_SECONDS);
  const [{ data: row }, firstLook] = await Promise.all([
    admin.from('diagnoses').select('type, diagnosis_json, hindi_summary, created_at').eq('id', diagnosisId).eq('farmer_id', farmerId).maybeSingle(),
    signCached(),
  ]);
  if (!row) return fail(404, 'not_found');
  mark('lookup');
  let cached = firstLook;

  // A brand-new diagnosis is still being voiced by diagnose-crop: wait for it instead of paying twice.
  while (!cached.data?.signedUrl && Date.now() - new Date(row.created_at).getTime() < BACKGROUND_WINDOW_MS) {
    await new Promise((r) => setTimeout(r, 700));
    cached = await signCached();
  }
  if (cached.data?.signedUrl) {
    mark('ready');
    const { data: saved } = row.hindi_summary ? { data: row } : await admin.from('diagnoses').select('hindi_summary').eq('id', diagnosisId).single();
    return Response.json({ url: cached.data.signedUrl, summary: saved?.hindi_summary ?? null, cached: true, timings_ms: ms }, { headers: cors });
  }

  let summary: string;
  try {
    summary = await prepareBolo(admin, farmerId, diagnosisId, row.type as Kind, row.diagnosis_json as Diagnosis | SoilReport, row.hindi_summary);
  } catch (e) {
    console.warn(`bolo: generation failed for ${diagnosisId}: ${String(e).slice(0, 200)}`);
    return fail(503, 'voice_unavailable');
  }
  const signed = await signCached();
  if (!signed.data?.signedUrl) return fail(500, 'store_failed');
  mark('generated');

  console.log(`bolo: ${diagnosisId} generated on demand ms=${JSON.stringify(ms)}`);
  return Response.json({ url: signed.data.signedUrl, summary, cached: false, timings_ms: ms }, { headers: cors });
});
