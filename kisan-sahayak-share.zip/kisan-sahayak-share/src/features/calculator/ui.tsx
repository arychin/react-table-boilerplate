import { Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';

import { MinTouchTarget, Spacing } from '@/constants/theme';
import { useApp } from '@/features/auth/app-context';
import { useTheme } from '@/hooks/use-theme';

import type { AreaUnit, Range } from './compute';

/** Whole numbers from 10 up; one decimal below (a 16 L tank often needs 4.9 ml). */
export const fmt = (n: number) => (n >= 10 ? Math.round(n).toLocaleString('en-IN') : String(Math.round(n * 10) / 10));
export const fmtRange = (r: Range) => (fmt(r[0]) === fmt(r[1]) ? fmt(r[0]) : `${fmt(r[0])}–${fmt(r[1])}`);
export const num = (s: string) => {
  const n = Number(s.replace(',', '.'));
  return Number.isFinite(n) ? n : 0;
};
export const cleanNumber = (s: string) => s.replace(/[^0-9.,]/g, '').slice(0, 7);

export function Chip({ label, selected, onPress }: { label: string; selected: boolean; onPress: () => void }) {
  const theme = useTheme();
  return (
    <Pressable
      accessibilityRole="radio"
      accessibilityState={{ selected }}
      onPress={onPress}
      style={[styles.chip, { borderColor: theme.primary, backgroundColor: selected ? theme.primary : 'transparent' }]}>
      <Text style={[styles.chipText, { color: selected ? theme.onPrimary : theme.primary }]}>{label}</Text>
    </Pressable>
  );
}

export function ChipRow<T extends string>({ options, value, label, onChange }: { options: readonly T[]; value: T; label: (o: T) => string; onChange: (o: T) => void }) {
  return (
    <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.chipRow} keyboardShouldPersistTaps="handled">
      {options.map((o) => (
        <Chip key={o} label={label(o)} selected={o === value} onPress={() => onChange(o)} />
      ))}
    </ScrollView>
  );
}

export function NumberField({ label, value, onChange, suffix }: { label: string; value: string; onChange: (v: string) => void; suffix?: string }) {
  const theme = useTheme();
  return (
    <View style={styles.field}>
      <Text style={[styles.fieldLabel, { color: theme.text }]}>{label}</Text>
      <TextInput
        value={value}
        onChangeText={(v) => onChange(cleanNumber(v))}
        keyboardType="decimal-pad"
        placeholder="0"
        placeholderTextColor={theme.textSecondary}
        accessibilityLabel={label}
        style={[styles.input, { color: theme.text, borderColor: theme.border, backgroundColor: theme.background }]}
      />
      {!!suffix && <Text style={[styles.suffix, { color: theme.textSecondary }]}>{suffix}</Text>}
    </View>
  );
}

const UNITS: AreaUnit[] = ['dismil', 'acre', 'ha'];

export function AreaInput({ value, unit, onValue, onUnit }: { value: string; unit: AreaUnit; onValue: (v: string) => void; onUnit: (u: AreaUnit) => void }) {
  const { t } = useApp();
  return (
    <View style={styles.block}>
      <NumberField label={t.calcArea} value={value} onChange={onValue} />
      <View style={styles.wrap}>
        {UNITS.map((u) => (
          <Chip key={u} label={t.areaUnit[u]} selected={u === unit} onPress={() => onUnit(u)} />
        ))}
      </View>
    </View>
  );
}

export function SectionTitle({ children }: { children: string }) {
  const theme = useTheme();
  return <Text style={[styles.section, { color: theme.text }]}>{children}</Text>;
}

export const calcStyles = StyleSheet.create({
  content: { padding: Spacing.four, gap: Spacing.three, paddingBottom: Spacing.six },
  card: { borderRadius: Spacing.three, padding: Spacing.three, gap: Spacing.two },
  note: { fontSize: 14, lineHeight: 21 },
  body: { fontSize: 16, lineHeight: 23 },
  strong: { fontSize: 16, lineHeight: 23, fontWeight: '700' },
  error: { fontSize: 16, fontWeight: '600' },
  link: { minHeight: MinTouchTarget, justifyContent: 'center' },
  linkText: { fontSize: 16, fontWeight: '700' },
  resultRow: { flexDirection: 'row', alignItems: 'baseline', gap: Spacing.two },
  resultLabel: { flex: 1, fontSize: 16 },
  resultValue: { fontSize: 22, fontWeight: '800' },
  option: { minHeight: MinTouchTarget, borderWidth: 1.5, borderRadius: Spacing.two, padding: Spacing.two, justifyContent: 'center' },
});

const styles = StyleSheet.create({
  chip: { minHeight: MinTouchTarget, borderWidth: 1.5, borderRadius: Spacing.five, paddingHorizontal: Spacing.three, justifyContent: 'center' },
  chipText: { fontSize: 15, fontWeight: '700' },
  chipRow: { gap: Spacing.two, paddingVertical: 2 },
  wrap: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.two },
  block: { gap: Spacing.two },
  field: { flexDirection: 'row', alignItems: 'center', gap: Spacing.two },
  fieldLabel: { flex: 1, fontSize: 16, fontWeight: '600' },
  input: { width: 110, minHeight: MinTouchTarget, borderWidth: 1.5, borderRadius: Spacing.two, paddingHorizontal: Spacing.two, fontSize: 18, textAlign: 'right' },
  suffix: { minWidth: 36, fontSize: 14 },
  section: { fontSize: 18, fontWeight: '800', marginTop: Spacing.two },
});
