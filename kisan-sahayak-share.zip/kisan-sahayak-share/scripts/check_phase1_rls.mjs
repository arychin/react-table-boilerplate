// Phase 1 DoD check: OTP login with the two Supabase test numbers, then cross-farmer RLS.
// Run: node --env-file=.env scripts/check_phase1_rls.mjs
// Uses ONLY the public anon key — exactly what the app has.
import { createClient } from '@supabase/supabase-js';

const url = process.env.EXPO_PUBLIC_SUPABASE_URL;
const anonKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY;
const FARMERS = [
  { phone: '+919000000001', otp: '246810' },
  { phone: '+919000000002', otp: '135790' },
];

let failures = 0;
const check = (label, ok, detail = '') => {
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${label}${detail ? `  (${detail})` : ''}`);
  if (!ok) failures += 1;
};

async function signIn({ phone, otp }) {
  const client = createClient(url, anonKey, { auth: { persistSession: false } });
  const sent = await client.auth.signInWithOtp({ phone });
  check(`send OTP ${phone}`, !sent.error, sent.error?.message);
  const { data, error } = await client.auth.verifyOtp({ phone, token: otp, type: 'sms' });
  check(`verify OTP ${phone}`, !error && !!data.session, error?.message);
  return { client, userId: data.user?.id };
}

const a = await signIn(FARMERS[0]);
const b = await signIn(FARMERS[1]);

// Trigger created the farmers row with id = auth uid and only the phone filled in.
const own = await a.client.from('farmers').select('*');
check('A sees exactly 1 farmers row', own.data?.length === 1, own.error?.message ?? `rows=${own.data?.length}`);
check('A row id = A auth uid', own.data?.[0]?.id === a.userId);
check('A row phone is E.164', own.data?.[0]?.phone_number === FARMERS[0].phone, own.data?.[0]?.phone_number);
check('A row name/district start null', own.data?.[0]?.name === null && own.data?.[0]?.district === null);
check('A preferred_language defaults to hi', own.data?.[0]?.preferred_language === 'hi');

// Cross-farmer read is denied (RLS filters it to nothing).
const cross = await a.client.from('farmers').select('id').eq('id', b.userId);
check('A cannot read B farmers row', !cross.error && cross.data.length === 0, cross.error?.message ?? `rows=${cross.data.length}`);

// Cross-farmer write is denied.
const crossUpd = await a.client.from('farmers').update({ name: 'hacked' }).eq('id', b.userId).select();
check('A cannot update B farmers row', (crossUpd.data ?? []).length === 0, crossUpd.error?.message ?? `rows=${crossUpd.data?.length}`);

// Own profile update works for allowed columns (Account/Settings).
const upd = await a.client.from('farmers').update({ name: 'Test Kisan A', district: 'Durg' }).eq('id', a.userId).select();
check('A can update own name + district', !upd.error && upd.data?.[0]?.name === 'Test Kisan A', upd.error?.message);

// Identity columns are not writable.
const phoneUpd = await a.client.from('farmers').update({ phone_number: '+919999999999' }).eq('id', a.userId).select();
check('A cannot change own phone_number', !!phoneUpd.error, phoneUpd.error?.code ?? 'update was allowed');

// chat_messages: own insert ok; insert as B denied; B cannot read A's message.
const msgA = await a.client.from('chat_messages').insert({ farmer_id: a.userId, role: 'user', content: 'rls test' }).select();
check('A can insert own chat message', !msgA.error, msgA.error?.message);
const spoof = await a.client.from('chat_messages').insert({ farmer_id: b.userId, role: 'user', content: 'spoof' });
check('A cannot insert chat message as B', !!spoof.error, spoof.error?.code ?? 'insert was allowed');
const bReads = await b.client.from('chat_messages').select('id').eq('farmer_id', a.userId);
check('B cannot read A chat messages', !bReads.error && bReads.data.length === 0, `rows=${bReads.data?.length}`);

// Server-only tables: farmer cannot write diagnoses / engagement_events (4A metric integrity).
const diag = await a.client.from('diagnoses').insert({ farmer_id: a.userId, type: 'crop', image_url: 'x', diagnosis_json: {} });
check('A cannot insert diagnoses directly', !!diag.error, diag.error?.code ?? 'insert was allowed');
const evt = await a.client.from('engagement_events').insert({ farmer_id: a.userId, event_type: 'loop_completed' });
check('A cannot forge engagement_events', !!evt.error, evt.error?.code ?? 'insert was allowed');

// Anonymous (no session) sees nothing on any table.
const anon = createClient(url, anonKey, { auth: { persistSession: false } });
for (const table of ['farmers', 'diagnoses', 'follow_ups', 'chat_messages', 'engagement_events']) {
  const r = await anon.from(table).select('*').limit(1);
  check(`anon cannot read ${table}`, !!r.error || r.data.length === 0, r.error?.code ?? `rows=${r.data.length}`);
}

console.log(failures === 0 ? '\nALL CHECKS PASSED' : `\n${failures} CHECK(S) FAILED`);
process.exit(failures === 0 ? 0 : 1);
