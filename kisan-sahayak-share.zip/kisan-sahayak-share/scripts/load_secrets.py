#!/usr/bin/env python3
"""Read Kisan Sahayak credentials from the files Kuldeep sent and print shell exports.

Usage (never redirect the export output into a file inside this project):
    eval "$(python3 scripts/load_secrets.py)"
    eval "$(python3 scripts/load_secrets.py --with-service-role)"   # adds SUPABASE_SERVICE_ROLE_KEY (test reset only)
    python3 scripts/load_secrets.py --write-client-env .env   # writes ONLY the two EXPO_PUBLIC_* values
"""
import base64
import json
import re
import shlex
import sys
from pathlib import Path

import fitz  # PyMuPDF

PDF = Path.home() / 'Downloads/jai_shree_ram-2/Kisan_Sahayak_Credentials_For_Achint.pdf'
NOTE = Path.home() / 'Downloads/Achi.txt'


def between(text: str, start: str, end: str) -> str:
    return ''.join(text.split(start, 1)[1].split(end, 1)[0].split())


def jwt_role(token: str) -> str:
    payload = token.split('.')[1]
    return json.loads(base64.urlsafe_b64decode(payload + '=' * (-len(payload) % 4)))['role']


def main() -> None:
    pdf = ''.join(page.get_text() for page in fitz.open(PDF))
    note = NOTE.read_text()

    url = re.search(r'https://([a-z0-9]+)\.supabase\.co', pdf)
    values = {
        'GEMINI_API_KEY': re.search(r'AQ\.[\w\-]+', pdf),
        'SARVAM_API_KEY': re.search(r'sk_\w+', pdf),
        'OPENWEATHER_API_KEY': re.search(r'\b[0-9a-f]{32}\b', pdf.split('4. OpenWeatherMap', 1)[1]),
        'EXPO_TOKEN': re.search(r'EXPO_TOKEN=(\S+)', pdf),
        'SUPABASE_ACCESS_TOKEN': re.search(r'sbp_[0-9a-f]+', note),
    }
    missing = [k for k, m in values.items() if m is None] + ([] if url else ['EXPO_PUBLIC_SUPABASE_URL'])
    if missing:
        sys.exit(f'Could not find: {", ".join(missing)}')

    out = {k: (m.group(1) if m.re.groups else m.group(0)) for k, m in values.items()}
    out['EXPO_PUBLIC_SUPABASE_URL'] = url.group(0)
    out['SUPABASE_PROJECT_REF'] = url.group(1)
    out['EXPO_PUBLIC_SUPABASE_ANON_KEY'] = between(pdf, 'anon key', 'service_role key')
    out['SUPABASE_DB_PASSWORD'] = between(pdf, 'Database Password', 'API Key (Secret')

    # Guards against the PDF layout shifting and the wrong JWT being picked up.
    if jwt_role(out['EXPO_PUBLIC_SUPABASE_ANON_KEY']) != 'anon':
        sys.exit('Parsed anon key does not have role=anon')

    if sys.argv[1:2] == ['--write-client-env']:
        target = Path(sys.argv[2])
        target.write_text(
            f"EXPO_PUBLIC_SUPABASE_URL={out['EXPO_PUBLIC_SUPABASE_URL']}\n"
            f"EXPO_PUBLIC_SUPABASE_ANON_KEY={out['EXPO_PUBLIC_SUPABASE_ANON_KEY']}\n"
        )
        target.chmod(0o600)
        print(f'Wrote client env to {target}')
        return

    for key, value in out.items():
        print(f'export {key}={shlex.quote(value)}')
    if '--with-service-role' in sys.argv[1:]:
        service_role = between(pdf, 'service_role key', '4. OpenWeatherMap')
        if jwt_role(service_role) != 'service_role':
            sys.exit('Parsed service_role key does not have role=service_role')
        print(f'export SUPABASE_SERVICE_ROLE_KEY={shlex.quote(service_role)}')


if __name__ == '__main__':
    main()
