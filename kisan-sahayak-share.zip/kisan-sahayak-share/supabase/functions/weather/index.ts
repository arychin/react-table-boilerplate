// TRD §6.4 weather: current conditions + next-12-hour rain chance from OpenWeatherMap (free tier).
// The API key stays server-side (TRD §11). The advice mapping is plain rules in the app, not AI.
import { cors, fail, signedInFarmer } from '../_shared/http.ts';

const OWM = 'https://api.openweathermap.org/data/2.5';
const FORECAST_SLOTS = 4; // 3-hour slots → next 12 hours ("today" for the farmer)

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  if (req.method !== 'POST') return fail(405, 'method_not_allowed');
  if (!signedInFarmer(req)) return fail(401, 'unauthorized');

  const body = await req.json().catch(() => null) as { lat?: unknown; lng?: unknown } | null;
  const lat = Number(body?.lat);
  const lng = Number(body?.lng);
  // India only; ~1 km precision is plenty for weather and keeps the farmer's exact spot out of third-party logs.
  if (!(lat >= 6 && lat <= 38 && lng >= 68 && lng <= 98)) return fail(400, 'bad_location');
  const q = `lat=${lat.toFixed(2)}&lon=${lng.toFixed(2)}&units=metric&appid=${Deno.env.get('OPENWEATHER_API_KEY') ?? ''}`;

  try {
    const get = (path: string) => fetch(`${OWM}/${path}`, { signal: AbortSignal.timeout(8_000) }).then((r) => {
      if (!r.ok) throw new Error(`openweather ${path.split('?')[0]} ${r.status}`);
      return r.json();
    });
    const [now, forecast] = await Promise.all([get(`weather?${q}`), get(`forecast?${q}&cnt=${FORECAST_SLOTS}`)]);
    const slots: { pop?: number; main?: { temp_max?: number } }[] = forecast.list ?? [];
    return Response.json({
      place: now.name || null,
      condition: now.weather?.[0]?.main ?? 'Clear',
      temp_c: Math.round(now.main.temp),
      temp_max_c: Math.round(Math.max(now.main.temp, ...slots.map((s) => s.main?.temp_max ?? -99))),
      humidity: Math.round(now.main.humidity),
      wind_kmh: Math.round((now.wind?.speed ?? 0) * 3.6),
      rain_chance: Math.round(100 * Math.max(0, ...slots.map((s) => s.pop ?? 0))),
      observed_at: new Date((now.dt ?? Date.now() / 1000) * 1000).toISOString(),
    }, { headers: cors });
  } catch (e) {
    console.warn(`weather: ${String(e).slice(0, 200)}`);
    return fail(503, 'weather_unavailable');
  }
});
