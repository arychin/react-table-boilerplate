// Measures diagnose-crop the way the app calls it (raw bytes, one automatic retry on 503), and reports
// correctly classified outcomes. Run: node --env-file=.env scripts/measure_diagnose_latency.mjs [rounds]
// Uses test farmer A; run scripts/reset_test_farmers.mjs afterwards. Mind the 20/hour rate limit.
import { createClient } from '@supabase/supabase-js';
import { readFileSync } from 'node:fs';

const rounds = Number(process.argv[2] ?? 2);
const files = ['potato_late_blight', 'tomato_early_blight', 'rice_brown_spot', 'tomato_after_rain', 'not_a_leaf_field', 'rice_brown_spot'];
const client = createClient(process.env.EXPO_PUBLIC_SUPABASE_URL, process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY, { auth: { persistSession: false } });
await client.auth.signInWithOtp({ phone: '+919000000001' });
await client.auth.verifyOtp({ phone: '+919000000001', token: '246810', type: 'sms' });

async function once(bytes) {
  const { data, error } = await client.functions.invoke('diagnose-crop', {
    body: bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength),
    headers: { 'Content-Type': 'image/jpeg', 'x-ks-language': 'hi' },
  });
  if (data?.id) return { outcome: 'ok', model: data.model, serverMs: data.timings_ms?.save };
  const status = error?.context?.status;
  return { outcome: status ? `http_${status}` : `network(${error?.name})` };
}

const rows = [];
for (let r = 0; r < rounds; r++) {
  for (const f of files) {
    const bytes = readFileSync(`test-assets/${f}.jpg`);
    const started = Date.now();
    let result = await once(bytes);
    const retried = result.outcome === 'http_503';
    if (retried) result = await once(bytes); // same as the app (D-28)
    rows.push({ f, ms: Date.now() - started, retried, ...result });
  }
}
for (const r of rows) console.log(`${r.f.padEnd(20)} ${String(r.ms).padStart(6)} ms  ${r.outcome.padEnd(14)} ${r.retried ? 'retried ' : '        '}${r.model ?? ''} ${r.serverMs ? `server=${r.serverMs}ms` : ''}`);
const ok = rows.filter((r) => r.outcome === 'ok').map((r) => r.ms).sort((a, b) => a - b);
console.log(`\nsucceeded ${ok.length}/${rows.length} | median ${ok[Math.floor(ok.length / 2)]} ms | p90 ${ok[Math.floor(ok.length * 0.9)]} ms | max ${ok.at(-1)} ms | retries ${rows.filter((r) => r.retried).length} | over 10 s ${rows.filter((r) => r.ms > 10_000).length}`);
