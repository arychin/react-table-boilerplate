import * as ImagePicker from 'expo-image-picker';
import { useState } from 'react';
import { ActivityIndicator, Pressable, ScrollView, Text, TextInput, View } from 'react-native';

import { Button } from '@/components/ui/button';
import { useApp } from '@/features/auth/app-context';
import { readPesticideLabel, type LabelRead } from '@/features/calculator/api';
import { ACRES_PER_HA, perAcre, spray, toAcres, type AreaUnit, type Range } from '@/features/calculator/compute';
import { CROP_IDS, matchComposition, rowsFor, searchProducts, type CropId, type LabelMatch, type Product } from '@/features/calculator/register';
import { AreaInput, Chip, ChipRow, cleanNumber, fmt, fmtRange, num, NumberField, calcStyles as s, SectionTitle } from '@/features/calculator/ui';
import { prepareImage } from '@/features/diagnosis/api';
import { useTheme } from '@/hooks/use-theme';

const waterDefault = (perHa: Range) => String(Math.round(perHa[0] / ACRES_PER_HA / 10) * 10);

// Vision Brief §3.16 + D-41: dose from the CIB&RC register (or the farmer's label); the app only does the arithmetic.
export default function SprayCalculatorScreen() {
  const { t } = useApp();
  const theme = useTheme();
  const [crop, setCrop] = useState<CropId>('rice');
  const [product, setProduct] = useState<Product | null>(null);
  const [rowIndex, setRowIndex] = useState(0);
  const [label, setLabel] = useState<LabelRead | null>(null);
  const [match, setMatch] = useState<LabelMatch | null>(null);
  const [query, setQuery] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [own, setOwn] = useState(false);
  const [ownAmount, setOwnAmount] = useState('');
  const [ownBasis, setOwnBasis] = useState<'acre' | 'litre'>('acre');
  const [ownUnit, setOwnUnit] = useState<'ml' | 'g'>('ml');
  const [area, setArea] = useState('1');
  const [unit, setUnit] = useState<AreaUnit>('acre');
  const [tank, setTank] = useState('16');
  const [water, setWater] = useState('200');

  const rows = product ? rowsFor(product, crop) : [];
  const row = rows[rowIndex] ?? null;

  const choose = (p: Product | null) => {
    setProduct(p);
    setRowIndex(0);
    setOwn(false);
    setQuery('');
    const first = p ? rowsFor(p, crop)[0] : null;
    if (first) {
      setWater(waterDefault(first.water));
      setOwnUnit(first.unit);
    }
  };
  const chooseRow = (i: number) => {
    setRowIndex(i);
    setWater(waterDefault(rows[i].water));
  };
  const restart = () => {
    choose(null);
    setLabel(null);
    setMatch(null);
    setError(null);
  };
  const changeCrop = (c: CropId) => {
    setCrop(c);
    restart();
  };

  const scan = async (source: 'camera' | 'gallery') => {
    setError(null);
    if (source === 'camera' && !(await ImagePicker.requestCameraPermissionsAsync()).granted) {
      setError(t.cameraDenied);
      return;
    }
    const options: ImagePicker.ImagePickerOptions = { mediaTypes: ['images'], quality: 1, exif: false };
    const result = source === 'camera' ? await ImagePicker.launchCameraAsync(options) : await ImagePicker.launchImageLibraryAsync(options);
    const asset = result.canceled ? null : result.assets[0];
    if (!asset) return;
    setBusy(true);
    const image = await prepareImage({ uri: asset.uri, width: asset.width, height: asset.height, mimeType: asset.mimeType });
    const read = image ? await readPesticideLabel(image) : null;
    setBusy(false);
    setLabel(read?.label ?? null);
    if (!read || read.errorKey) setError(t[read?.errorKey ?? 'errDiagnose']);
    const m = read?.label?.composition ? matchComposition(read.label.composition, crop) : null;
    setMatch(m);
    if (m && m.exact.length === 1) choose(m.exact[0]);
  };

  const ownNumber = num(ownAmount);
  const dose = own
    ? ownNumber > 0
      ? { basis: ownBasis, amount: [ownNumber, ownNumber] as Range }
      : null
    : row
      ? { basis: 'acre' as const, amount: perAcre(row.dose) }
      : null;
  const doseUnit = t.unitName[own ? ownUnit : (row?.unit ?? 'ml')];
  const acres = toAcres(num(area), unit);
  const result = dose ? spray({ acres, tankLitres: num(tank), waterPerAcre: num(water), dose }) : null;
  const results = product ? [] : searchProducts(query, crop);
  const unmatched = !!label?.composition && !!match && !match.exact.length && !match.similar.length;

  if (busy) {
    return (
      <View style={[s.content, { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: theme.background }]}>
        <ActivityIndicator size="large" color={theme.primary} />
        <Text style={[s.strong, { color: theme.text }]}>{t.sprayReading}</Text>
      </View>
    );
  }

  return (
    <ScrollView style={{ backgroundColor: theme.background }} contentContainerStyle={s.content} keyboardShouldPersistTaps="handled">
      <SectionTitle>{t.calcCrop}</SectionTitle>
      <ChipRow options={CROP_IDS} value={crop} label={(c) => t.cropNames[c]} onChange={changeCrop} />

      <SectionTitle>{t.sprayProduct}</SectionTitle>
      {product ? (
        <View style={[s.card, { backgroundColor: theme.backgroundElement }]}>
          <Text style={[s.strong, { color: theme.text }]}>{product.name}</Text>
          {!!label?.brand_name && <Text style={[s.note, { color: theme.textSecondary }]}>{label.brand_name}</Text>}
          {rows.length > 1 && (
            <>
              <Text style={[s.body, { color: theme.text }]}>{t.sprayChooseProblem}</Text>
              {rows.map((r, i) => (
                <Option key={`${r.crop}-${r.pest}-${i}`} selected={i === rowIndex} onPress={() => chooseRow(i)} text={`${r.pest} (${r.crop})`} />
              ))}
            </>
          )}
          {row && (
            <View style={[s.card, { backgroundColor: theme.successBg }]}>
              <Text style={[s.note, { color: theme.primary, fontWeight: '700' }]}>{t.sprayOfficial}</Text>
              <Text style={[s.body, { color: theme.text }]}>{t.sprayOfficialDose(`${fmtRange(perAcre(row.dose))} ${t.unitName[row.unit]}`)}</Text>
              <Text style={[s.body, { color: theme.text }]}>{t.sprayOfficialWater(fmtRange(perAcre(row.water)))}</Text>
              {row.wait !== null && <Text style={[s.body, { color: theme.warning }]}>{t.sprayWait(row.wait)}</Text>}
            </View>
          )}
          <Link text={own ? t.sprayUseRegister : t.sprayOwnDose} onPress={() => setOwn(!own)} />
          <Link text={t.sprayChangeProduct} onPress={restart} />
        </View>
      ) : (
        <>
          <Text style={[s.note, { color: theme.textSecondary }]}>{t.sprayPhotoHint}</Text>
          <Button label={t.takePhoto} onPress={() => scan('camera')} />
          <Button label={t.pickPhoto} variant="secondary" onPress={() => scan('gallery')} />
          {error && <Text style={[s.error, { color: theme.danger }]}>{error}</Text>}
          {!!label && (label.brand_name || label.composition) && <Text style={[s.body, { color: theme.text }]}>{t.sprayLabelRead(label.brand_name, label.composition)}</Text>}
          {match?.notForCrop && <Warning text={t.sprayNotForCrop(t.cropNames[crop])} />}
          {unmatched && !match?.notForCrop && <Warning text={t.sprayNotInRegister} />}
          {!!match && (
            <>
              {match.exact.map((p) => (
                <Option key={p.name} text={p.name} selected={false} onPress={() => choose(p)} />
              ))}
              {!!match.similar.length && <Text style={[s.body, { color: theme.text }]}>{t.spraySimilar}</Text>}
              {match.similar.map((p) => (
                <Option key={p.name} text={p.name} selected={false} onPress={() => choose(p)} />
              ))}
            </>
          )}
          <TextInput
            value={query}
            onChangeText={setQuery}
            placeholder={t.spraySearch}
            placeholderTextColor={theme.textSecondary}
            autoCapitalize="none"
            autoCorrect={false}
            accessibilityLabel={t.spraySearch}
            style={[s.option, { color: theme.text, borderColor: theme.border, fontSize: 16 }]}
          />
          {results.map((p) => (
            <Option key={p.name} text={p.name} selected={false} onPress={() => choose(p)} />
          ))}
          {query.trim().length >= 3 && !results.length && <Text style={[s.note, { color: theme.textSecondary }]}>{t.sprayNoResults}</Text>}
          {!own && !match?.notForCrop && <Link text={t.sprayManual} onPress={() => setOwn(true)} />}
        </>
      )}

      {own && (
        <View style={[s.card, { backgroundColor: theme.backgroundElement }]}>
          <NumberField label={t.sprayManualDose} value={ownAmount} onChange={setOwnAmount} suffix={t.unitName[ownUnit]} />
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
            <Chip label={t.unitName.ml} selected={ownUnit === 'ml'} onPress={() => setOwnUnit('ml')} />
            <Chip label={t.unitName.g} selected={ownUnit === 'g'} onPress={() => setOwnUnit('g')} />
            <Chip label={t.sprayDoseBasis.acre} selected={ownBasis === 'acre'} onPress={() => setOwnBasis('acre')} />
            <Chip label={t.sprayDoseBasis.litre} selected={ownBasis === 'litre'} onPress={() => setOwnBasis('litre')} />
          </View>
        </View>
      )}

      <AreaInput value={area} unit={unit} onValue={setArea} onUnit={setUnit} />
      <NumberField label={t.sprayTank} value={tank} onChange={setTank} suffix="L" />
      <NumberField label={t.sprayWater} value={water} onChange={(v) => setWater(cleanNumber(v))} suffix="L" />

      <View style={[s.card, { backgroundColor: theme.backgroundElement, borderWidth: 2, borderColor: theme.primary }]}>
        <Text style={[s.strong, { color: theme.text }]}>{t.sprayResult}</Text>
        {!(acres > 0) ? (
          <Text style={[s.note, { color: theme.textSecondary }]}>{t.sprayNeedArea}</Text>
        ) : !result ? (
          <Text style={[s.note, { color: theme.textSecondary }]}>{t.sprayNeedDose}</Text>
        ) : (
          <>
            <Result label={t.sprayPerTank} value={`${fmtRange(result.perTank)} ${doseUnit}`} />
            <Result label={t.sprayTanks} value={String(result.tanks)} />
            <Result label={t.sprayTotal} value={`${fmtRange(result.total)} ${doseUnit}`} />
            <Result label={t.sprayTotalWater} value={`${fmt(result.totalWater)} L`} />
          </>
        )}
      </View>
      <Text style={[s.note, { color: theme.text }]}>{t.spraySafety}</Text>
    </ScrollView>
  );
}

function Option({ text, selected, onPress }: { text: string; selected: boolean; onPress: () => void }) {
  const theme = useTheme();
  return (
    <Pressable
      accessibilityRole="radio"
      accessibilityState={{ selected }}
      onPress={onPress}
      style={({ pressed }) => [s.option, { borderColor: selected ? theme.primary : theme.border, backgroundColor: selected ? theme.backgroundSelected : theme.background }, pressed && { opacity: 0.6 }]}>
      <Text style={[s.body, { color: theme.text }]}>{text}</Text>
    </Pressable>
  );
}

function Link({ text, onPress }: { text: string; onPress: () => void }) {
  const theme = useTheme();
  return (
    <Pressable accessibilityRole="button" onPress={onPress} style={s.link}>
      <Text style={[s.linkText, { color: theme.primary }]}>{text}</Text>
    </Pressable>
  );
}

function Warning({ text }: { text: string }) {
  const theme = useTheme();
  return (
    <View style={[s.card, { backgroundColor: theme.warningBg }]}>
      <Text style={[s.body, { color: theme.warning }]}>{text}</Text>
    </View>
  );
}

function Result({ label, value }: { label: string; value: string }) {
  const theme = useTheme();
  return (
    <View style={s.resultRow}>
      <Text style={[s.resultLabel, { color: theme.text }]}>{label}</Text>
      <Text style={[s.resultValue, { color: theme.text }]}>{value}</Text>
    </View>
  );
}
