# decisions.md

Plain-language closing summary of each session (Working Instructions §6).
Full decision records with reasons and trade-offs are in [project_memory/DECISIONS.md](project_memory/DECISIONS.md).

---

## Phase 0 — Environment & Project Setup (2026-10-02)

**What was decided**
- Started from the Expo SDK 57 default template, trimmed to the TRD §3 layout. Example screens and assets were removed.
- Used Expo Router's standard JS `Tabs` rather than the template's `unstable-native-tabs`, because the native tabs API is marked unstable.
- Changed web output from `static` to `single`. Static pre-rendering runs without a browser `window`, which breaks Supabase's AsyncStorage session storage.
- Secrets are read from Kuldeep's files by `scripts/load_secrets.py` into the shell only. The client `.env` holds just the two public Supabase values.
- The corporate proxy (Zscaler) re-signs HTTPS with Shell's root CA. The Supabase and EAS CLIs needed a CA bundle (`~/.certs/ca-bundle-with-shell.pem`) to trust it.
- Gemini and Sarvam are blocked from this laptop by the proxy. Both keys were checked from Supabase's servers with a temporary Edge Function, which was then deleted.
- Removed the template's `use-color-scheme.web.ts`. It only existed for static web rendering (now off), and it failed lint (`react-hooks/set-state-in-effect`).
- Added `eslint` and `eslint-config-expo` as devDependencies only. `expo install` had also put the config under runtime dependencies; that was removed.
- Did not run `npm audit fix --force`. The 16 findings are in Expo's own tooling dependencies, and forcing upgrades would break Expo's pinned versions.

**Files modified** — see [project_memory/FILE_INDEX.md](project_memory/FILE_INDEX.md).

**Manually tested (real command output, 2026-10-02)**
- `npx tsc --noEmit` → exit 0. It failed until the first `expo start` generated `expo-env.d.ts`.
- `npm run lint` → exit 0
- `npx expo-doctor` → 21/21 checks passed
- `npx expo start` → Metro up on :8081. The Android bundle, fetched with the manifest's own URL (`routerRoot=src/app`), returned HTTP 200 and contains all 4 tab screens.
- Bundle secret scan: Gemini, Sarvam, OpenWeather, Expo token, Supabase access token and DB password each found 0 times
- supabase-js with the client `.env` → `PGRST205` (table not found). This is expected before Phase 1 and proves the project is reachable and the anon key accepted. Run from Node on the laptop, not yet from the phone.
- Gemini: HTTP 200 from Supabase servers; Flash models listed
- Sarvam: HTTP 200 from Supabase servers; Hindi audio returned
- OpenWeather: HTTP 200 (Durg, 25.6 °C)
- Supabase CLI: project linked; 3 secrets set; key-check function deleted (`functions list` is empty)
- EAS: `whoami` → kisan-sahayak-agritech (Admin); project linked (ID in app.json)
- No `.git` in poc/

**Deferred**
- Opening the app on the physical phone (Expo Go on the same Wi-Fi as `exp://192.168.1.8:8081`)
- `npm test` setup
- The 16 npm audit findings in Expo's transitive dependencies

---

## Phase 1 — Data Layer & Identity (2026-10-03)

**What was decided**
- The database follows TRD §5 exactly (5 tables, exact column names), with row-level security on every table before the app touches it.
- A farmer can only see their own rows. The public anon key alone can read nothing. Farmers can edit only their name, district, language and last location, never their phone number.
- Diagnoses and engagement events can only be written by the server. This means the "one metric that matters" (Vision Brief §4A) can't be faked from a phone.
- When a farmer verifies their OTP, a database trigger creates their `farmers` row automatically. No profile step blocks entry (TRD §6.6).
- Login uses two Supabase **test numbers** with fixed codes. No SMS is sent: real SMS in India needs a provider plus DLT registration (D-7).
  - **Farmer A:** +91 9000000001, code 246810
  - **Farmer B:** +91 9000000002, code 135790
- Email login was switched off on the server; the Vision Brief says no email anywhere.
- OTP expiry raised from 60 s to 5 minutes, because farmers type the code by hand.
- Shops: 967 real shops kept from the 1,186-row CSV.
  - 219 non-shops removed (pest-control services, tractor dealers, colleges, offices …).
  - 200 shops have trustworthy GPS points. The rest will open Directions by name + address.
- The whole app is bilingual (Hindi default, one-tap English), with large touch targets and a green theme.

**Files modified** — see [project_memory/FILE_INDEX.md](project_memory/FILE_INDEX.md) (Phase 1 section).

**Manually tested (real output)**
- Live database check script: **23/23 pass**
  - both test numbers log in
  - farmer A cannot read or edit farmer B
  - A cannot change their own phone number
  - A cannot write diagnoses or engagement events
  - the anon key alone sees nothing
- Browser run of the real app, end to end:
  - Hindi phone screen → switch to English
  - invalid number rejected with a clear message
  - wrong code rejected; correct code goes straight to Home
  - Account: saved a name and district; after a reload they came back from the server
  - Log out returns to the phone screen, and the server session is revoked
- Type check and lint pass; the Android bundle builds; no server secrets in the bundle

**Deferred**
- Real SMS + automatic OTP fill on the phone (needs an SMS provider, DLT and a native build). The OTP field already has the Android "fill from SMS" hint.
- Running on the physical phone: try it with Expo Go and test number 9000000001 / 246810
- Proper tab icons and label spacing (design pass)

---

## Phase 2 — Core Diagnosis Loop (2026-10-03)

**What was decided**
- **AI model:** Gemini **3.5-flash-lite**, with 3.1-flash-lite as an automatic backup. I tested 7 Gemini models on 5 real leaf photos:
  - The bigger Flash models were "overloaded" (503) on both runs, and the older 2.5-flash is retired.
  - 3.5-flash-lite got all 5 right in about 3 seconds: early blight, late blight, rice brown spot, a healthy plant, and "this isn't a leaf".
- **One request per diagnosis.** The phone sends the resized photo straight to the server. The server saves it privately and asks Gemini at the same time. This brought tap-to-result from **10.4 s down to about 4.5–5 s**. Farmers also can no longer upload directly to storage, so the saved photo is always exactly the one that was diagnosed.
- **Should-I-Spray built in** (newer Vision Brief §3.11): every result says 🟢 no spray needed, 🟡 wait and watch, or 🔴 spray recommended, with the reason.
  - It always ends with "confirm with your local Krishi Kendra or dealer".
  - A result the AI isn't sure about can **never** say "spray"; the server enforces this.
- **No doses, ever.** The AI is told never to give amounts; across all tests it gave none. Where a treatment applies, the app says "use only the label amount, confirm at your Krishi Kendra/KVK".
- **Honest uncertainty** (§2.2): a blurry or irrelevant photo shows "not sure — take a clear close-up or show your KVK". Every result carries "AI advice from one photo, not a certain diagnosis".
- Each diagnosis also schedules a follow-up 3 days later and logs "diagnosis completed" for the engagement metric, from day one.
- Limit of 20 diagnoses per farmer per hour, to protect the AI budget.

**Files modified** — see [project_memory/FILE_INDEX.md](project_memory/FILE_INDEX.md) (Phase 2 section).

**Manually tested (real output)**
- Live server check, all passing (run twice):
  - JPEG and **PNG** both work
  - the result has every TRD field
  - the follow-up is scheduled exactly 3 days out
  - farmer B can't see farmer A's diagnosis or photo
  - a fake login token is rejected
  - a non-image file is rejected
- In the real app (browser):
  - PNG tomato leaf → Hindi "early blight", 🔴, in **4.5 s**
  - tractor photo → English "photo is unclear", 🟡, in 5.1 s
  - healthy tomato → 🟢, in 4.7 s
  - History shows past checks; old photos load securely
- Type check, lint and the server type check all pass. The Android build compiles, contains no secret keys, and never talks to Gemini directly.

**Deferred**
- Running it on the physical phone with a real leaf (please try: Expo Go → `exp://192.168.1.8:8081`, login 9000000001 / 246810)
- Accuracy on real Chhattisgarh field photos (so far only 5 reference photos)
- Hindi voice summary + Bolo button (Phase 3); "buy at nearby shops" on the result (Phase 4)

---

## Phase 3 — Hindi Voice, the Bolo button (2026-10-06)

**What was decided**
- **Voice: Sarvam "priya" (female), as MP3.** The TRD's voice "anushka" doesn't exist in Sarvam's current model (the API rejected it). You chose priya after listening to 6 samples. MP3 is about 2.5× smaller than WAV, which matters on village networks.
- **The Hindi summary is a separate AI call** made after the diagnosis is saved, as the docs require. If voice fails, the diagnosis is untouched. I proved this by deliberately breaking the voice key: the diagnosis still worked, and Bolo showed "tap to retry".
- **The voice is prepared in the background** right after the diagnosis, so it's usually ready by the time the farmer looks for the button. It's saved once per diagnosis, so replays never pay for the voice service again.
- **Summary rules:** 2–3 simple Hindi sentences; one problem, one fix; no doses ever. When unsure: "photo not clear, send a close-up". Healthy: "no medicine needed". When spraying is involved: "confirm with your Krishi Kendra or dealer".
- **No microphone or background permissions:** Bolo only plays while its screen is open.
- **Reliability:** testing showed Google's AI occasionally stalls for 15+ s. The app now:
  - asks a backup model in parallel after 3.5 s
  - stops waiting at 9 s
  - retries once automatically

  Result: **18 out of 18 diagnoses succeeded**, typical time 4 s. One in about 20 still takes longer than 10 s because of Google's side. **Demo Mode (Phase 9) will remove this risk for the pitch.**

**Files modified** — see [project_memory/FILE_INDEX.md](project_memory/FILE_INDEX.md) (Phase 3 section).

**Manually tested (real output)**
- Bolo for a diseased leaf, a healthy plant and an unclear photo: correct Hindi summaries, valid audio. Second play comes from the cache (no new voice charge).
- Farmer B can't hear farmer A's diagnosis. Nobody can upload audio directly.
- In the app (browser): tap 🔊 plays immediately; tap again stops; reopening from History is ready in about 2 s
- All Phase 1, 2 and 3 checks pass together. The Android build has no secret keys and no browser speech engine.

**Deferred**
- **Hearing it on the real Android phone.** An Android test build (EAS) has been started; once it's ready, install it and tap Bolo on a diagnosis.
- Accuracy on real Chhattisgarh field photos
- "Buy at nearby shops" on the result (Phase 4)

---

## Phase 4 — Offline Shop Finder (2026-10-07)

**What was decided**
- **More shops: only 5 could be found legitimately.** OpenStreetMap has 5 real agri shops in Chhattisgarh (3 in Kapsi, 1 in Lakhanpur, 1 in Raipur), and they are added with OpenStreetMap's required credit.
  - The official dealer list (urvarak.nic.in) needs a login.
  - The other government sites are blocked or have no lists.
  - Copying Google Maps isn't allowed.
  - **The real route to more shops is the district agriculture office or a KVK.**
- **Your list's map locations were mostly wrong, so I fixed them properly.** Testing showed a Rajnandgaon shop "2 km from Durg".
  - Checking against the location code (Plus Code) in each address showed most CSV pins were 10–45 km off.
  - Now a shop gets an exact location only if its Plus Code is unique and OpenStreetMap confirms it's in Chhattisgarh at the town/PIN in the address. That gives **151 shops with exact locations.**
  - The other 642 show "Distance unknown" and open Google Maps by name + address, which was Kuldeep's rule (b).
  - A wrong distance is worse than no distance.
- **Cleaned out non-shops:** Aadhaar/Lok Seva centres, petrol pumps, pest-control companies, dairies, markets, coaching classes, nurseries, goat farms and similar. I checked every removed name by hand and restored 5 real shops.
  - Also removed 34 shops in Odisha, Maharashtra, MP, Karnataka and UP.
  - **Final: 793 shops**, all with the 33 official district names.
- **How the list works:** shops with a known location within 50 km, nearest first, plus every shop in the farmer's district.
  - Search finds any shop or district in Hindi or English.
  - The diagnosis never influences which shop is shown.
- **Location:** asked only on the Shops tab. Never in the background. Works in airplane mode (GPS needs no internet).

**Files modified** — see [project_memory/FILE_INDEX.md](project_memory/FILE_INDEX.md) (Phase 4 section).

**Manually tested (real output)**
- With a simulated location in Durg, the Shops tab lists real Durg shops at 1.0–1.2 km; Kapsi finds the OpenStreetMap shops at 0.1 km
- Location refused → a clear message, and search still works
- Directions opens Google Maps at the right point; Call dials the number
- A real late-blight diagnosis shows "Ask for the treatment at these nearby shops" with 3 shops
- Type check and lint pass. The Android build has no secret keys. There is exactly one distance formula in the code.

**Deferred**
- **On the phone:** the Shops tab with real GPS, then in airplane mode. This needs a new test build, because the location library was added after the last one.
- More shops from an official list

---

## Phase 5 — Soil Analysis + Weather (2026-10-07)

**What was decided**
- **Soil uses the same machinery as crop photos** (one function, same upload, storage and voice), as the Plan asks.
- **A soil photo is never presented as a lab test** (Vision Brief §2.2):
  - Every result says "estimate from a photo — get a Soil Health Card test at your KVK"
  - Nutrient issues are only "possible", with the visible reason
  - Fertilisers are named, but never with amounts
  - If the photo isn't soil (we tried a mud hut and a leaf), the app says so and recommends nothing
- **Bolo works on soil results** in plain Hindi, and always ends with the "only a guess from a photo" line.
- **Shops personalised:** "Ask for Vermicompost at these nearby shops", and the Shops tab reminds the farmer what to ask for. It doesn't filter shops, because we don't know their stock.
- **Soil has no 3-day follow-up.** That loop is for crop disease.
- **Weather card on Home:** live OpenWeather data, with the key kept on the server. Advice comes from simple fixed rules, not AI:
  - rain → don't spray
  - strong wind → wait
  - 40 °C+ → avoid 11–3
  - very humid → watch for fungus
  - otherwise good for spraying
  - Location is rounded to about 1 km before it's sent, and the permission text now says location is used for weather too.

**Files modified** — see [project_memory/FILE_INDEX.md](project_memory/FILE_INDEX.md) (Phase 5 section).

**Manually tested (real output)**
- Live check: 5 test photos in Hindi and English, 2.5–7.6 s each, no amounts anywhere, non-soil photos refused politely; soil voice works; weather live for Durg and Jagdalpur
- All Phase 1, 2, 3 and 5 checks pass back to back from a clean start
- In the app (browser, Hindi): weather card shows Durg weather and "छिड़काव के लिए अच्छा मौसम"; a red-soil photo → result in 3.4 s with fertilisers, nearby shops and the voice summary
- Bugs caught by testing and fixed: half-Hindi product names in English mode; browsers blocking soil uploads (a missing header permission on the server); the weather button wrongly saying "show distance"

**Deferred**
- Phone test of Phases 1–5 (needs a new test build)
- Soil reading accuracy on real Chhattisgarh field photos (one test photo of black soil was read as laterite)

### Added: Soil Health Card scanner (2026-10-07)
- **A small green "🪪 Add your Soil Health Card" button** under the soil check on Home (your request; Vision Brief §3.15).
- The farmer photographs their government card. The app **copies the 12 test values exactly as printed** and never guesses. The farmer **checks and corrects** them, then saves.
- Each value gets a plain explanation (for example "Nitrogen low — affects leaf colour and growth"; "Acidic soil — lime helps, ask your KVK how much"). These are fixed sentences, not AI, and **never amounts**: amounts come only from the card itself or the KVK.
- Privacy: the card photo isn't stored, and the name, Aadhaar and survey numbers aren't read. The card is saved on the phone for now; linking it to a field comes with Farm Memory later.
- Tested in the app (Hindi) with a **made-up sample card** (no real card image is publicly available): read in 3.4 s, all 12 values correct, a farmer correction saved, kept after reopening. Still to test: a real card photographed on the phone.
- **Realistic test (2026-10-07):** a Hindi-first Chhattisgarh-style card (invented farmer in Bastar, with personal details and a dose section), as a clean scan and as a tilted, blurry, shadowed "phone photo".
  - Both read **12/12 values and ratings correctly** in about 3 s, with the date right. No personal details or doses were read.
  - **Bug found and fixed:** the card's word "अपर्याप्त" (insufficient) was shown as "ठीक" for zinc and boron. Now correctly "कम".

---

## Phase 6 — Agri Expert Chatbot (2026-10-07)

**What was decided**
- **"कृषि विशेषज्ञ" on the Advice tab** answers any farming question in the app's language, in short practical steps for Chhattisgarh.
- **The same safety rules as the rest of the app:**
  - never an amount for any pesticide or fertiliser; it points to the label, Soil Health Card or KVK
  - always spray safety
  - for serious problems: KVK or the free Kisan Call Centre 1800-180-1551
- **Farming only:** off-topic questions and "ignore your rules" tricks are politely refused.
- **Conversation is saved** on the server and comes back after reopening the app. The bot remembers the last few messages, so a follow-up like "और अगर बारिश हो जाए तो?" makes sense to it.
- **Quick-question buttons** for farmers who find typing hard. If the internet drops, the question stays on screen with a "फिर से भेजें" button.

**Files modified** — see [project_memory/FILE_INDEX.md](project_memory/FILE_INDEX.md) (Phase 6 section).

**Manually tested (real output)**
- Live check, 15/15:
  - Hindi questions → Hindi answers; English → English
  - the follow-up understood
  - "tell me exact ml of chlorpyrifos" → refused, pointing to label/KVK
  - a cricket question refused
  - history saved correctly and private to each farmer
- In the app (browser, Hindi): answers in 3–5 s; history back after reload; offline → clear message and a working retry
- Problems found by testing and fixed:
  - English questions sometimes got Hindi answers
  - slow AI answers were cut off too early
  - the quick-question buttons took half the screen
- All earlier phase checks still pass

**Deferred**
- Phone test (you deferred it)
- Bolo voice on chat answers, and voice input (optional per the brief)

---

## MVP step — In-app follow-up loop (2026-10-07)

**What was decided**
- **3 days after a crop check, a card appears at the top of Home:** "अब आपकी फसल कैसी है?". It asks:
  - "Did you use the suggested treatment?" (skipped when nothing was prescribed, e.g. a healthy plant or an unclear photo)
  - "How does the crop look now?" — getting better / same / getting worse
- **If it's not better,** the farmer gets the next steps the brief asks for: check again with a new photo, find a nearby Krishi Kendra, or call the free Kisan Call Centre.
- **Every answer is logged on the server** as a completed advisory loop. It's the "one metric that matters" from the brief, and the phone can't fake it.
- **Founder metrics report** (`scripts/metrics.mjs`), for the pitch:
  - weekly active farmers
  - repeat farmers
  - loops completed
  - crop-saves (farmer says "getting better")
- **Not in this MVP:** WhatsApp reminders and automatic scheduling (out of scope, agreed earlier); push notifications (need a new phone build). The card shows up when the farmer opens the app.

**Files modified** — see [project_memory/FILE_INDEX.md](project_memory/FILE_INDEX.md) (MVP item 7 section).

**Manually tested (real output)**
- Live check, 15/15:
  - a real diagnosis creates the 3-day follow-up
  - it can't be answered early, or by another farmer
  - the phone can't edit it directly
  - one answer = exactly one logged loop
- In the app (Hindi): both card types, the next-step buttons and the thank-you all work; answers saved exactly as tapped; the report showed "2 of 2 loops, 1 crop-save"
- **Note:** Google's AI service was overloaded at the end of this session ("high demand", confirmed with a temporary test that's now deleted). New diagnoses failed meanwhile, and the app showed its normal "try again" message. Nothing in our code caused it. I'll re-run all checks once it recovers.

**Deferred**
- Phone test (you deferred it)
- Reminder notifications (push or WhatsApp)

---

## Extra features before Phase 9 (Kuldeep, 2026-10-07)
- **No mandi prices:** Chhattisgarh farmers sell at cooperative societies at government-set prices.
- **To build, in order:** Savings Tracker → Dose/Tank/Cost Calculator → Daily Action Feed / crop calendar.

### Savings Tracker — done (2026-10-07)
- At the top of **History**: "💰 ऐप से आपको क्या फ़ायदा हुआ". Every number is labelled with where it comes from:
  - **App record:** crop checks done; times we said "no spray needed"
  - **You told us:** times the crop was fine without spraying; times it got better after the treatment
  - **Estimate:** money possibly saved = times we said "no spray" × **the farmer's own** cost of one spray. The formula and "not a promise of profit" are shown under it, as the brief requires.
- The founder metrics report now shows the same "no spray needed" count, so pitch numbers match the app.
- Tested: the maths against hand-made examples (I fixed one case where the app would have given itself too much credit); in the app, all numbers matched, and the cost was remembered after reopening.

### Daily action feed — done (2026-10-16)
A new Home card, "🗓️ आज खेत में क्या करें" (what to do in the field today), for paddy and chana.
- **Setup:** the farmer enters the crop and the date the seed went in.
  - Paddy: also how long the variety takes (short, medium or long)
  - Chana: the current stage
- **Every day the card shows:**
  - the day number and the approximate stage
  - paddy only: days to harvest
  - whether a field check is due today, and how to check (5 spots, 20 plants)
- **What to look for at this stage:** each pest or disease with the official "spray only if you see this much or more" count (e.g. 15–20 planthoppers per hill).
  - Below it: no spray, save the money
  - Above it, or unsure: check with a photo
- **Sources:** the Ministry of Agriculture's plant-health institute (NIPHM) for the thresholds and check intervals; IRRI for paddy's stage timing.
- **Why only paddy and chana:** they're the only crops with clean official stage-by-stage tables.
- Works offline; nothing leaves the phone.
- **Tested:** 49 checks, including every threshold number against the official table, and every step in the browser.
- **Bug I caught and fixed:** a sowing date typed in the future was taken as last year's.

### Backend was asleep (2026-10-16)
- The free Supabase plan paused the project after about a week of no use, so the app showed a blank page. With your OK it was restored in about 3 minutes; nothing was lost.
- **It will happen again after about 7 idle days.** Before the pitch, either keep using the app, add a keep-alive, or move to the paid plan.

### Calculator — done (2026-10-07)
Two calculators on Home under "🧮 हिसाब लगाएँ". Every number comes from an official government table or from the farmer's own label/card. The app only does the arithmetic.

**Spray mix (दवा का घोल)**
- The farmer picks the crop, then the product: photograph the bottle, or type its name.
- The AI only reads the product's chemical name from the photo. The dose comes from the government's pesticide register (CIB&RC, 31 March 2026), never from the AI.
- Shows: medicine per acre, water per acre, and how many days before harvest it must stop. Then, for the farmer's field and tank: medicine per tank, number of tanks, total medicine and total water.
- If the product isn't registered for that crop, a warning says don't use it on this crop and ask the KVK.
- The farmer can always enter the amount printed on their own label instead.

**Fertiliser (खाद का हिसाब)**
- Paddy, wheat or kharif maize, and the district. Uses ICAR's new district recommendation (June 2026), or the farmer's Soil Health Card numbers.
- Shows the kg and bags of urea, DAP and potash for their field, and the cost at government prices (editable).
- Optional: "how many bags do you put now?"
  - Says which fertiliser is above the recommendation and how much money that wastes
  - Says separately which fertiliser is below it (that can lower the yield)
  - The two are never netted against each other
- That money figure appears in the Savings card as an estimate.

**Tested**
- 37 maths and lookup checks
- The label reader on 4 realistic made-up labels: clear, blurred photo, Hindi-only, and a weedicide. Plus a urea bag and a leaf, which it correctly rejected.
- Every screen in the browser
- One mistake of mine was caught in testing and fixed: the first version netted extra potash against too little urea and called it a "saving".

### Keep-alive + Demo Mode — done (2026-10-16)
**Keep-alive.** The free Supabase plan put the backend to sleep after a week without use, and the app went blank. Now the backend calls itself twice a day (about 5:47 and 17:47) so it looks "in use". The first manual test call worked. Whether this is enough to stop the pause can only be proven after 7 days.

**Demo Mode (for the pitch).**
- **Turn on:** hold the app name on the login screen for 3 seconds (or the phone number in Account). Works with no internet and without logging in.
- **What it shows:** every feature works with sample data and makes zero internet calls (tested with all internet traffic blocked):
  - tomato early-blight diagnosis with Hindi voice
  - sandy-loam soil report
  - planthopper chat answer
  - Durg weather and real nearby-shop distances
  - history, savings, check-in and today's field check
  - label and Soil Health Card reading
- **Sample content:** produced once by our real AI and voice pipeline, so it reads and sounds exactly like the live app.
- **Turn off:** Account → "डेमो मोड बंद करें". The real account comes back.
- **Not done on purpose:** switching to demo automatically when the internet fails. A real farmer would get fake advice without knowing.

### Demo button for the judges (2026-10-16)
- A small "डेमो" button sits at the top right of Home, and also on the login screen. The login screen needs it in case the server is down and login itself fails.
- Tap it: it turns amber ("डेमो चालू"), and the whole app shows the sample data with no internet. Tap again to go back to live.
- Before the Play Store release: change one line (SHOW_DEMO_TOGGLE = false) and the button disappears.
