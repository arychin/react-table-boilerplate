// Phase 3 server check (anon key + test-number login, like the app). Run:
//   node --env-file=.env scripts/check_phase3_bolo.mjs
// Then reset test data: see scripts/reset_test_farmers.mjs.
import { createClient } from '@supabase/supabase-js';
import { readFileSync } from 'node:fs';

const url = process.env.EXPO_PUBLIC_SUPABASE_URL;
const anonKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY;
let failures = 0;
const check = (label, ok, detail = '') => {
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${label}${detail ? `  (${detail})` : ''}`);
  if (!ok) failures += 1;
};
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
// jsonb stores object keys in its own order, so compare with sorted keys.
const canonical = (v) => JSON.stringify(v, (_k, x) => (x && typeof x === 'object' && !Array.isArray(x) ? Object.fromEntries(Object.entries(x).sort()) : x));

async function login(phone, otp) {
  const client = createClient(url, anonKey, { auth: { persistSession: false } });
  await client.auth.signInWithOtp({ phone });
  const { data } = await client.auth.verifyOtp({ phone, token: otp, type: 'sms' });
  return { client, id: data.user.id };
}

async function diagnose(client, file) {
  const bytes = readFileSync(file);
  const { data } = await client.functions.invoke('diagnose-crop', {
    body: bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength),
    headers: { 'Content-Type': 'image/jpeg', 'x-ks-language': 'en' },
  });
  return data;
}

async function bolo(client, diagnosisId) {
  const started = Date.now();
  const { data, error } = await client.functions.invoke('bolo', { body: { diagnosis_id: diagnosisId } });
  return { data, status: error?.context?.status ?? 200, ms: Date.now() - started };
}

const a = await login('+919000000001', '246810');
await sleep(2500); // Supabase OTP throttle
const b = await login('+919000000002', '135790');

const DOSE = /\d|मि\.?ली|ग्राम|लीटर|किलो|प्रति एकड़|ml\b|gram|litre/i;
for (const [file, expect] of [
  ['test-assets/tomato_early_blight.jpg', 'treat'],
  ['test-assets/tomato_after_rain.jpg', 'healthy'],
  ['test-assets/not_a_leaf_field.jpg', 'unsure'],
]) {
  const d = await diagnose(a.client, file);
  const diagnosedAt = Date.now();
  check(`${file.split('/').pop()} diagnosed (${d?.diagnosis?.spray_decision}, conf=${d?.diagnosis?.confidence})`, !!d?.id);
  if (!d?.id) continue;

  // The app calls bolo as soon as the result opens; diagnose-crop has already started voicing it.
  const first = await bolo(a.client, d.id);
  check('  Bolo ready after the diagnosis', first.status === 200 && !!first.data?.url,
    `ready ${Date.now() - diagnosedAt} ms after the result, cached=${first.data?.cached}, server ${JSON.stringify(first.data?.timings_ms)}`);
  const summary = first.data?.summary ?? '';
  console.log(`      summary: ${summary}`);
  check('  summary is Devanagari only, 2–3 sentences', /[\u0900-\u097F]/.test(summary) && !/[A-Za-z]/.test(summary)
    && (summary.match(/[।?!]/g) ?? []).length >= 2 && (summary.match(/[।?!]/g) ?? []).length <= 4);
  check('  summary has no dose/number', !DOSE.test(summary), summary.match(DOSE)?.[0]);
  if (expect === 'treat') check('  summary asks to confirm with कृषि केंद्र/dealer', /कृषि केंद्र|दुकानदार|डीलर/.test(summary));
  if (expect === 'unsure') check('  unsure summary asks for a clearer photo', /फोटो|तस्वीर/.test(summary));

  const audio = await fetch(first.data.url);
  const bytes = new Uint8Array(await audio.arrayBuffer());
  const isMp3 = (bytes[0] === 0xff && (bytes[1] & 0xe0) === 0xe0) || (bytes[0] === 0x49 && bytes[1] === 0x44 && bytes[2] === 0x33);
  check('  signed URL serves an MP3', audio.ok && isMp3 && bytes.length > 10_000, `${audio.headers.get('content-type')}, ${bytes.length} bytes`);

  const second = await bolo(a.client, d.id);
  check('  replay is cached (no new Sarvam call)', second.data?.cached === true, `${second.ms} ms`);
  check('  replay returns the same summary', second.data?.summary === summary);

  const row = await a.client.from('diagnoses').select('hindi_summary, diagnosis_json').eq('id', d.id).single();
  check('  hindi_summary saved on the row', row.data?.hindi_summary === summary);
  check('  diagnosis itself unchanged by Bolo', canonical(row.data?.diagnosis_json) === canonical(d.diagnosis));

  if (expect === 'treat') {
    const bTry = await bolo(b.client, d.id);
    check('B cannot get A Bolo (404)', bTry.status === 404, `status ${bTry.status}`);
    const path = `${a.id}/${d.id}.mp3`;
    const bSign = await b.client.storage.from('bolo-audio').createSignedUrl(path, 60);
    check('B cannot sign A audio file', !bSign.data?.signedUrl, bSign.error?.message);
    const aSign = await a.client.storage.from('bolo-audio').createSignedUrl(path, 60);
    check('A can sign own audio file', !!aSign.data?.signedUrl);
    const aWrite = await a.client.storage.from('bolo-audio').upload(`${a.id}/x.mp3`, bytes, { contentType: 'audio/mpeg' });
    check('A cannot write to bolo-audio', !!aWrite.error, aWrite.error?.message);
  }
}

const anon = createClient(url, anonKey, { auth: { persistSession: false } });
const noAuth = await anon.functions.invoke('bolo', { body: { diagnosis_id: '00000000-0000-0000-0000-000000000000' } });
check('anon key alone is rejected', noAuth.error?.context?.status === 401, `status ${noAuth.error?.context?.status}`);
const bad = await bolo(a.client, 'not-a-uuid');
check('bad diagnosis id rejected (400)', bad.status === 400, `status ${bad.status}`);

console.log(failures === 0 ? '\nALL CHECKS PASSED' : `\n${failures} CHECK(S) FAILED`);
process.exit(failures === 0 ? 0 : 1);
