// TRD §6.1 diagnose-crop: photo bytes in → private Storage + Gemini structured diagnosis → diagnoses row.
// Also handles soil photos (x-ks-kind: soil, Plan Phase 5 step 1) through the same pipeline.
import { encodeBase64 } from 'jsr:@std/encoding@1';

import { prepareBolo } from '../_shared/bolo.ts';
import { diagnoseImage, type Diagnosis, type Language, sniffImageMime } from '../_shared/diagnosis.ts';
import { adminClient, cors, fail, signedInFarmer } from '../_shared/http.ts';
import { analyseSoil, type SoilReport } from '../_shared/soil.ts';

// Provided by the Supabase Edge Runtime; declared here instead of importing its heavy .d.ts.
declare const EdgeRuntime: { waitUntil(promise: Promise<unknown>): void };

const BUCKET = 'diagnosis-images';
const MAX_PER_HOUR = 20;
const MAX_BYTES = 10 * 1024 * 1024;
const FOLLOW_UP_DAYS = 3; // TRD §7: fixed default for V1
const EXT: Record<string, string> = { 'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp', 'image/heic': 'heic' };

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  if (req.method !== 'POST') return fail(405, 'method_not_allowed');

  const t0 = performance.now();
  const ms: Record<string, number> = {};
  const mark = (step: string) => { ms[step] = Math.round(performance.now() - t0); };

  const farmerId = signedInFarmer(req);
  if (!farmerId) return fail(401, 'unauthorized');
  if (Number(req.headers.get('content-length') ?? 0) > MAX_BYTES) return fail(413, 'image_too_large');
  const bytes = new Uint8Array(await req.arrayBuffer());
  if (bytes.byteLength > MAX_BYTES) return fail(413, 'image_too_large');
  const mimeType = sniffImageMime(bytes);
  if (!mimeType) return fail(415, 'unsupported_image');
  const language: Language = req.headers.get('x-ks-language') === 'en' ? 'en' : 'hi';
  const kind = req.headers.get('x-ks-kind') === 'soil' ? 'soil' : 'crop';
  mark('read');

  const admin = adminClient();
  const hourAgo = new Date(Date.now() - 3600_000).toISOString();
  const { count } = await admin.from('diagnoses').select('id', { count: 'exact', head: true })
    .eq('farmer_id', farmerId).gte('created_at', hourAgo);
  if ((count ?? 0) >= MAX_PER_HOUR) return fail(429, 'rate_limited');
  mark('rate_check');

  // Store the exact bytes being diagnosed (private bucket, server-chosen path) while Gemini runs.
  const imagePath = `${farmerId}/${crypto.randomUUID()}.${EXT[mimeType]}`;
  const stored = admin.storage.from(BUCKET).upload(imagePath, bytes, { contentType: mimeType });

  let diagnosis: Diagnosis | SoilReport | null = null;
  let modelUsed = '';
  try {
    const input = { language, mimeType, base64: encodeBase64(bytes) };
    ({ diagnosis, model: modelUsed } = kind === 'soil' ? await analyseSoil(input) : await diagnoseImage(input));
  } catch {
    // Every pinned model failed; reported as 503 below.
  }
  mark('ai');
  const { error: storeError } = await stored;
  if (!diagnosis) {
    // Don't keep a farmer's photo that no diagnosis points to.
    if (!storeError) await admin.storage.from(BUCKET).remove([imagePath]);
    return fail(503, 'ai_unavailable');
  }
  if (storeError) return fail(500, 'store_failed');

  const { data: row, error: insertError } = await admin.from('diagnoses').insert({
    farmer_id: farmerId,
    type: kind,
    image_url: imagePath,
    diagnosis_json: diagnosis,
    channel: 'app',
  }).select('id, created_at').single();
  if (insertError || !row) return fail(500, 'save_failed');
  mark('save');

  // TRD §7 step 1 and Vision Brief §4A, written after the response so the farmer never waits on them.
  // The follow-up loop (Vision Brief §3.3) is for the crop-disease journey only.
  const followUpAt = new Date(new Date(row.created_at).getTime() + FOLLOW_UP_DAYS * 86400_000).toISOString();
  if (kind === 'crop') EdgeRuntime.waitUntil(Promise.all([
    admin.from('follow_ups').insert({ diagnosis_id: row.id, scheduled_for: followUpAt }),
    admin.from('engagement_events').insert({ farmer_id: farmerId, event_type: 'diagnosis_completed', diagnosis_id: row.id }),
  ]).then(([followUp, event]) => {
    if (followUp.error || event.error) console.error(`diagnose-crop: side record failed for ${row.id}`);
  }));

  // TRD §6.2: voice the Hindi summary now, so Bolo is usually ready before the farmer taps.
  // A failure here never touches the diagnosis; the bolo function retries on demand.
  EdgeRuntime.waitUntil(
    prepareBolo(admin, farmerId, row.id, kind, diagnosis, null)
      .catch((e) => console.warn(`diagnose-crop: background bolo failed for ${row.id}: ${String(e).slice(0, 200)}`)),
  );

  // TRD §8: no phone numbers or image content in logs.
  console.log(`diagnose-crop: ${row.id} kind=${kind} model=${modelUsed} ms=${JSON.stringify(ms)} mime=${mimeType} bytes=${bytes.byteLength}`);
  return Response.json({ id: row.id, image_path: imagePath, diagnosis, model: modelUsed, timings_ms: ms }, { headers: cors });
});
