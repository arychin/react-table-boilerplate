import { FunctionsHttpError } from '@supabase/supabase-js';

import { demoAnswerFollowUp, demoDueFollowUp } from '@/features/demo/store';
import { isDemoMode } from '@/lib/demo-mode';
import { supabase } from '@/lib/supabase';
import type { Diagnosis } from '@/types/diagnosis';

// MVP version of the advisory loop (Vision Brief §3.3): an in-app check-in card instead of WhatsApp + pg_cron.
export type Outcome = 'improved' | 'no_change' | 'worse';
export type DueFollowUp = { id: string; diagnosisId: string; daysAgo: number; crop: string; problem: string; askApplied: boolean };

/** The newest crop follow-up that is due and not yet answered (RLS: own rows only). */
export async function fetchDueFollowUp(): Promise<DueFollowUp | null> {
  if (isDemoMode()) return demoDueFollowUp();
  const { data } = await supabase
    .from('follow_ups')
    .select('id, diagnoses!inner(id, created_at, diagnosis_json)')
    .eq('status', 'pending')
    .lte('scheduled_for', new Date().toISOString())
    .order('scheduled_for', { ascending: false })
    .limit(1)
    .maybeSingle();
  if (!data) return null;
  const d = data.diagnoses.diagnosis_json as Diagnosis;
  return {
    id: data.id,
    diagnosisId: data.diagnoses.id,
    daysAgo: Math.max(1, Math.round((Date.now() - new Date(data.diagnoses.created_at).getTime()) / 86400_000)),
    crop: d.crop_name,
    problem: d.disease_name,
    // Nothing was prescribed for a healthy plant or an unclear photo, so don't ask whether it was applied.
    askApplied: d.confidence !== 'low' && d.spray_decision !== 'not_needed',
  };
}

export async function answerFollowUp(id: string, outcome: Outcome, applied: boolean | null): Promise<'ok' | 'errNetwork' | 'errSave'> {
  if (isDemoMode()) {
    demoAnswerFollowUp(outcome, applied);
    return 'ok';
  }
  const { error } = await supabase.functions.invoke('follow-up-answer', { body: { follow_up_id: id, outcome, applied } });
  if (!error) return 'ok';
  const status = error instanceof FunctionsHttpError ? (error.context as Response).status : 0;
  if (status === 409) return 'ok'; // already answered (e.g. a double tap) — the loop is closed either way
  return status === 0 ? 'errNetwork' : 'errSave';
}
