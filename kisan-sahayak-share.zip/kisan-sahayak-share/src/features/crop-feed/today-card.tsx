import { router, useFocusEffect } from 'expo-router';
import { useCallback, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';

import { Button } from '@/components/ui/button';
import { MinTouchTarget, Spacing } from '@/constants/theme';
import { useApp } from '@/features/auth/app-context';
import { pickAndDiagnose } from '@/features/diagnosis/pick-image';
import { useTheme } from '@/hooks/use-theme';

import { loadPlan, markScouted } from './api';
import { CHECKS, todayFor, type CropPlan } from './feed';

// Vision Brief §7 "what should I do today": scouting first, spray only above the official threshold (§3.11 spirit).
export function TodayCard() {
  const { t, language, session } = useApp();
  const theme = useTheme();
  const farmerId = session?.user.id ?? '';
  const [state, setState] = useState<{ plan: CropPlan | null; today: string } | null>(null);
  const [showChecks, setShowChecks] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useFocusEffect(
    useCallback(() => {
      if (farmerId) loadPlan(farmerId).then(setState);
    }, [farmerId]),
  );

  if (!state) return null;
  const card = [styles.card, { backgroundColor: theme.backgroundElement, borderColor: theme.primary }];
  const title = <Text style={[styles.title, { color: theme.text }]}>🗓️ {t.feedTitle}</Text>;

  if (!state.plan) {
    return (
      <View style={card}>
        {title}
        <Text style={[styles.hint, { color: theme.textSecondary }]}>{t.feedSetupHint}</Text>
        <Button label={t.feedSetup} onPress={() => router.push('/crop-plan')} />
      </View>
    );
  }

  const plan = state.plan;
  const today = todayFor(plan, state.today);
  if (!today) return null;
  const checks = CHECKS[today.stage];
  const showList = today.scouting === 'due' || showChecks;

  return (
    <View style={card}>
      {title}
      <View style={styles.row}>
        <Text style={[styles.strong, { color: theme.text, flex: 1 }]}>{t.feedDay(t.planCrops[plan.crop], today.dayNo)}</Text>
        <Pressable accessibilityRole="button" onPress={() => router.push('/crop-plan')} style={styles.link}>
          <Text style={[styles.linkText, { color: theme.primary }]}>{t.feedChange}</Text>
        </Pressable>
      </View>
      <Text style={[styles.body, { color: theme.text }]}>{t.feedStage(t.stageNames[today.stage])}</Text>
      {today.harvestIn !== null && today.harvestIn > 0 && <Text style={[styles.hint, { color: theme.textSecondary }]}>{t.feedHarvestIn(today.harvestIn)}</Text>}

      {today.scouting === 'not_needed' && <Text style={[styles.body, { color: theme.text }]}>{t.feedHarvest}</Text>}
      {today.scouting === 'too_early' && <Text style={[styles.body, { color: theme.text }]}>{t.feedTooEarly(today.nextScoutIn)}</Text>}
      {today.scouting === 'due' && (
        <View style={[styles.due, { backgroundColor: theme.warningBg }]}>
          <Text style={[styles.strong, { color: theme.warning }]}>{t.feedScoutDue}</Text>
          <Text style={[styles.body, { color: theme.text }]}>{t.feedScoutHow}</Text>
        </View>
      )}
      {today.scouting === 'done' && (
        <View style={styles.row}>
          <Text style={[styles.strong, { color: theme.primary, flex: 1 }]}>✓ {t.feedNextIn(today.nextScoutIn)}</Text>
          <Pressable accessibilityRole="button" onPress={() => setShowChecks(!showChecks)} style={styles.link}>
            <Text style={[styles.linkText, { color: theme.primary }]}>{t.feedShowChecks}</Text>
          </Pressable>
        </View>
      )}

      {showList && !!checks.length && (
        <>
          <Text style={[styles.strong, { color: theme.text }]}>{t.feedLookFor}</Text>
          {checks.map((c) => (
            <View key={c.name.en} style={[styles.check, { borderColor: theme.border }]}>
              <Text style={[styles.checkName, { color: theme.text }]}>{c.name[language]}</Text>
              <Text style={[styles.hint, { color: theme.text }]}>{c.act[language]}</Text>
            </View>
          ))}
          <Text style={[styles.hint, { color: theme.text }]}>{t.feedBelow}</Text>
        </>
      )}

      {today.scouting === 'due' && (
        <>
          <Button label={t.feedDone} onPress={async () => setState({ ...state, plan: await markScouted(farmerId, plan) })} />
          {error && <Text style={[styles.hint, { color: theme.danger }]}>{error}</Text>}
          <Button label={t.feedPhoto} variant="secondary" onPress={() => pickAndDiagnose('camera', () => setError(t.cameraDenied))} />
        </>
      )}
      <Text style={[styles.source, { color: theme.textSecondary }]}>{t.feedSource}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  card: { borderRadius: Spacing.four, borderWidth: 2, padding: Spacing.four, gap: Spacing.two },
  title: { fontSize: 22, fontWeight: '800' },
  row: { flexDirection: 'row', alignItems: 'center', gap: Spacing.two },
  strong: { fontSize: 17, fontWeight: '700', lineHeight: 24 },
  body: { fontSize: 16, lineHeight: 23 },
  hint: { fontSize: 15, lineHeight: 21 },
  source: { fontSize: 12, lineHeight: 17 },
  link: { minHeight: MinTouchTarget, justifyContent: 'center' },
  linkText: { fontSize: 15, fontWeight: '700' },
  due: { borderRadius: Spacing.three, padding: Spacing.three, gap: Spacing.one },
  check: { borderLeftWidth: 3, paddingLeft: Spacing.two, gap: 2 },
  checkName: { fontSize: 16, fontWeight: '700' },
});
