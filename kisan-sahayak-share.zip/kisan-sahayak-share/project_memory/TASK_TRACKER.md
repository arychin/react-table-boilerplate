# Task Tracker

## Completed
- [x] 2026-09-29 Read and summarised all 4 planning documents
- [x] 2026-09-29 Difficulty assessment (about 7/10; not one-shottable)
- [x] 2026-09-29 Created /project_memory/ structure

## Blocked / waiting on user
- [x] OQ-1: use the v1 PDFs for the MVP (D-4)
- [x] OQ-5: keep both (project_memory + root decisions.md/flow.md, created in Phase 0)
- [x] Approve the MVP scope, D-6 and D-7 (D-8)
- [x] Share the shop dataset (1,186 rows received)
- [x] Weather API key (received)
- [x] OQ-7: Supabase `sbp_` access token (received 2026-10-02)
- [x] OQ-6: option (b) (D-12)
- [x] Approve the Phase 0 plan (2026-10-02, via Kuldeep's note)
- [ ] Settle git with Kuldeep: his note says git init; the user says no git (D-11 followed)
- [ ] Open the app on the physical phone via Expo Go (Phase 0 left this unverified)
- [x] OQ-8: Gemini model choice → gemini-3.5-flash-lite + 3.1-flash-lite fallback (D-21)
- [ ] Post-MVP: Meta verification + WhatsApp BSP, SMS DLT registration; rotate all shared keys
- [ ] PARKED (user, 2026-10-16): unexplained test-data deletion ~20:14–20:19 UTC on 2026-10-15; user did not run the reset. Retry the logs endpoint later.
- [ ] More shops: official district dealer list (agriculture office / KVK, via Kuldeep). Open sources are exhausted (D-32).
- [ ] New EAS dev build (expo-location is native) → on-phone Shops test incl. airplane mode

## MVP scope — APPROVED 2026-09-30 (D-8)
Priority order; cut from the bottom if time runs out.

1. [x] Phase 0 — setup, CLAUDE.md (no git, D-11). DONE 2026-10-02; see SESSION_LOG.
2. [x] Phase 1 (trimmed) — 5 tables + RLS; phone → OTP login using Supabase test numbers; optional profile screen; shops.json. DONE 2026-10-03; real-SMS auto-fill deferred (D-18).
3. [x] Phase 2 — photo → Gemini structured diagnosis → result screen (no doses, D-6) + Should-I-Spray + History. DONE 2026-10-03; physical-device run pending.
4. [x] Phase 3 — Hindi summary + Sarvam voice button, audio cached. DONE 2026-10-06 on server + browser; EAS dev build queued; on-device check pending (user).
5. [x] Phase 4 — offline shop finder. DONE 2026-10-07 in browser; data rebuilt with verified locations (D-31); on-device airplane-mode check pending (needs a new EAS build).
6. [x] Demo Mode (Phase 9) — DONE 2026-10-16 (D-44): hidden long-press switch, zero network calls (verified with all Supabase traffic blocked), bundled real Bolo audio
7. [x] Follow-up loop, in-app version — DONE 2026-10-07 (D-37): check-in card, answer function, loop_completed, metrics script
8. [x] Weather card (simple) — DONE 2026-10-07 (Phase 5)
8a. [x] Savings Tracker — DONE 2026-10-07 (D-39/D-40)
8b. [x] Dose/Tank/Cost Calculator — DONE 2026-10-07 (D-41): spray mix (CIB&RC register + label photo) and fertiliser (ICAR district GFR), savings link
8c. [x] Daily Action Feed / crop calendar — DONE 2026-10-16 (D-42): paddy + chana, NIPHM thresholds, IRRI stages, offline
8d. [-] Mandi prices — DROPPED by Kuldeep (D-39)
9. [x] Soil analysis (reuses the Phase 2 pipeline) — DONE 2026-10-07 (Phase 5)
10. [x] Chatbot — DONE 2026-10-07 (Phase 6)
11. [~] EAS preview APK built 2026-10-16 (build da295490, link expires 2026-10-29); user installing on phone → then rehearse; record video

Out of the MVP: WhatsApp, IVR, SMS auto-fill, real SMS OTP, pg_cron, full Phase 10 audit (the hard security rules still apply), production build.

## Pending — build phases (Implementation Plan v1)
Each phase has its own session and needs plan approval. Its Definition of Done must be verified before the next phase starts.

- [x] Phase 0 — Environment & Project Setup (2026-10-02; no commit per D-11)
- [x] Phase 1 — Data Layer & Identity (2026-10-03; DoD met except real-SMS auto-fill on device, D-18)
- [x] Phase 2 — Core Diagnosis Loop (2026-10-03; DoD met in browser + server; physical-device run pending)
- [x] Phase 3 — Hindi Voice, the Bolo button (2026-10-06; DoD met except "on a real Android device" — EAS dev build 805756e5 queued)
- [x] Phase 4 — Offline Shop Finder (2026-10-07; DoD met except the on-device airplane-mode run)
- [x] Phase 5 — Soil Analysis + Weather (2026-10-07; DoD met on server + browser; phone run pending)
- [x] Phase 6 — Agri Expert Chatbot (2026-10-07; DoD met on server + browser; phone run pending)
- [ ] Phase 7 — WhatsApp Voice-First Loop (depends on 2, 3)
- [ ] Phase 8 — Advisory Follow-Up Loop (depends on 7, 1)
- [x] Phase 9 — Demo Mode (2026-10-16; D-44/D-45; 0 network calls verified in browser; phone run pending)
- [ ] Phase 10 — Polish, Security & Performance (depends on 2–9)
- [ ] Phase 11 — Build & Release Readiness (depends on 10)
- [ ] Phase 12 — Staged Farmer Rollout (named in the Working Instructions only; not in the Plan v1 PDF)
