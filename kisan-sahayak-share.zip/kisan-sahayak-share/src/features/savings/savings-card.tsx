import { useFocusEffect } from 'expo-router';
import { useCallback, useState } from 'react';
import { StyleSheet, Text, TextInput, View } from 'react-native';

import { MinTouchTarget, Spacing } from '@/constants/theme';
import { useApp } from '@/features/auth/app-context';
import { loadFertSaving, type FertSaving } from '@/features/calculator/api';
import { useTheme } from '@/hooks/use-theme';

import { fetchSavingsInput, loadSprayCost, saveSprayCost } from './api';
import { computeSavings, type SavingsInput } from './compute';

type Source = 'measured' | 'told' | 'estimate';

export function SavingsCard() {
  const { t, session } = useApp();
  const theme = useTheme();
  const farmerId = session?.user.id ?? '';
  const [rows, setRows] = useState<SavingsInput[] | null>(null);
  const [cost, setCost] = useState('');
  const [fert, setFert] = useState<FertSaving | null>(null);

  useFocusEffect(
    useCallback(() => {
      fetchSavingsInput().then(setRows);
      loadSprayCost(farmerId).then((c) => setCost(c ? String(c) : ''));
      loadFertSaving(farmerId).then(setFert);
    }, [farmerId]),
  );

  if (!rows?.length && !fert) return null;
  const costNumber = Number(cost);
  const s = computeSavings(rows ?? [], Number.isFinite(costNumber) ? costNumber : null);

  return (
    <View style={[styles.card, { backgroundColor: theme.successBg, borderColor: theme.primary }]}>
      <Text style={[styles.title, { color: theme.primary }]}>💰 {t.savingsTitle}</Text>
      {!!rows?.length && (
        <>
          <Line value={s.checks} label={t.savingsChecks} source="measured" />
          <Line value={s.noSprayAdvice} label={t.savingsNoSpray} source="measured" />
          <Line value={s.avoidedConfirmed} label={t.savingsAvoided} source="told" />
          <Line value={s.recovered} label={t.savingsRecovered} source="told" />

          <View style={[styles.estimate, { borderColor: theme.border }]}>
            <View style={styles.costRow}>
              <Text style={[styles.costLabel, { color: theme.text }]}>{t.savingsCostLabel}</Text>
              <Text style={[styles.rupee, { color: theme.text }]}>₹</Text>
              <TextInput
                value={cost}
                onChangeText={(v) => setCost(v.replace(/[^0-9]/g, '').slice(0, 6))}
                onEndEditing={() => saveSprayCost(farmerId, Number(cost) || null)}
                onBlur={() => saveSprayCost(farmerId, Number(cost) || null)}
                keyboardType="number-pad"
                placeholder="0"
                placeholderTextColor={theme.textSecondary}
                accessibilityLabel={t.savingsCostLabel}
                style={[styles.input, { color: theme.text, borderColor: theme.border, backgroundColor: theme.background }]}
              />
            </View>
            {s.estimatedRupees !== null ? (
              <Line value={`₹${s.estimatedRupees.toLocaleString('en-IN')}`} label={t.savingsMoney} source="estimate" />
            ) : (
              <Text style={[styles.hint, { color: theme.textSecondary }]}>{t.savingsCostHint}</Text>
            )}
            <Text style={[styles.hint, { color: theme.textSecondary }]}>{t.savingsHow}</Text>
          </View>
        </>
      )}
      {fert && <Line value={`₹${fert.rupees.toLocaleString('en-IN')}`} label={t.savingsFert} source="estimate" />}
    </View>
  );
}

function Line({ value, label, source }: { value: number | string; label: string; source: Source }) {
  const { t } = useApp();
  const theme = useTheme();
  return (
    <View style={styles.line}>
      <Text style={[styles.value, { color: theme.text }]}>{value}</Text>
      <Text style={[styles.label, { color: theme.text }]}>{label}</Text>
      <Text style={[styles.tag, { color: theme.textSecondary, borderColor: theme.border }]}>{t.savingsSource[source]}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  card: { borderRadius: Spacing.four, borderWidth: 2, padding: Spacing.three, gap: Spacing.two, marginBottom: Spacing.two },
  title: { fontSize: 18, fontWeight: '800' },
  line: { flexDirection: 'row', alignItems: 'center', gap: Spacing.two },
  value: { minWidth: 44, fontSize: 20, fontWeight: '800' },
  label: { flex: 1, fontSize: 15, lineHeight: 21 },
  tag: { fontSize: 11, fontWeight: '700', borderWidth: 1, borderRadius: Spacing.two, paddingHorizontal: 6, paddingVertical: 2 },
  estimate: { borderTopWidth: 1, borderStyle: 'dashed', paddingTop: Spacing.two, gap: Spacing.two },
  costRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.two },
  costLabel: { flex: 1, fontSize: 15, fontWeight: '600' },
  rupee: { fontSize: 17, fontWeight: '700' },
  input: { width: 96, minHeight: MinTouchTarget, borderWidth: 1.5, borderRadius: Spacing.two, paddingHorizontal: Spacing.two, fontSize: 17, textAlign: 'right' },
  hint: { fontSize: 13, lineHeight: 19 },
});
