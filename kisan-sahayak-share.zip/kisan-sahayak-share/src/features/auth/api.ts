import type { AuthError } from '@supabase/supabase-js';

import type { Language, Strings } from '@/constants/strings';
import { isDemoMode } from '@/lib/demo-mode';
import { supabase } from '@/lib/supabase';
import type { Database } from '@/types/database';

export type Farmer = Database['public']['Tables']['farmers']['Row'];
export type ProfileUpdate = Pick<Database['public']['Tables']['farmers']['Update'], 'name' | 'district' | 'preferred_language'>;
type ErrorKey = keyof Pick<Strings, 'errInvalidCode' | 'errSmsUnavailable' | 'errNetwork' | 'errTooMany' | 'errSave'>;
export type Result = { errorKey: ErrorKey | null };

/** 10-digit Indian mobile → E.164, or null if it isn't one. */
export function toE164(input: string): string | null {
  const digits = input.replace(/\D/g, '').replace(/^(91|0)(?=\d{10}$)/, '');
  return /^[6-9]\d{9}$/.test(digits) ? `+91${digits}` : null;
}

function errorKeyFor(error: AuthError | { message: string; code?: string }): ErrorKey {
  const status = 'status' in error ? error.status : undefined;
  if (error.code === 'otp_expired') return 'errInvalidCode';
  if (status === 429 || error.code?.startsWith('over_')) return 'errTooMany';
  if (/sms provider/i.test(error.message)) return 'errSmsUnavailable';
  if (!status || /fetch|network/i.test(error.message)) return 'errNetwork';
  return 'errSave';
}

export async function sendOtp(phone: string): Promise<Result> {
  if (isDemoMode()) return { errorKey: null }; // demo signs in locally (long-press), never via OTP
  const { error } = await supabase.auth.signInWithOtp({ phone });
  return { errorKey: error ? errorKeyFor(error) : null };
}

export async function verifyOtp(phone: string, token: string): Promise<Result> {
  if (isDemoMode()) return { errorKey: null };
  const { error } = await supabase.auth.verifyOtp({ phone, token, type: 'sms' });
  return { errorKey: error ? errorKeyFor(error) : null };
}

export async function signOut(): Promise<void> {
  if (isDemoMode()) return;
  await supabase.auth.signOut();
}

export async function fetchFarmer(farmerId: string): Promise<Farmer | null> {
  if (isDemoMode()) return { id: farmerId, name: 'रामलाल साहू', district: 'Durg', phone_number: '+919000000000', preferred_language: 'hi', created_at: '2026-09-29T00:00:00Z', last_known_lat: null, last_known_lng: null };
  const { data } = await supabase.from('farmers').select('*').eq('id', farmerId).maybeSingle();
  return data;
}

export async function updateProfile(farmerId: string, changes: ProfileUpdate): Promise<Result> {
  if (isDemoMode()) return { errorKey: null };
  const { error } = await supabase.from('farmers').update(changes).eq('id', farmerId);
  return { errorKey: error ? errorKeyFor(error) : null };
}

export function isLanguage(value: string | null | undefined): value is Language {
  return value === 'hi' || value === 'en';
}
