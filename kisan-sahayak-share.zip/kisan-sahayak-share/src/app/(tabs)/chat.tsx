import { useEffect, useRef, useState } from 'react';
import { ActivityIndicator, FlatList, KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';

import { MinTouchTarget, Spacing } from '@/constants/theme';
import { useApp } from '@/features/auth/app-context';
import { fetchChatHistory, sendChatMessage, type ChatMessage } from '@/features/chat/api';
import { useTheme } from '@/hooks/use-theme';

type Pending = { localId: string; text: string; failed: string | null };

// Plan Phase 6 / Vision Brief §3.6: ask any farming question; history persists for the farmer.
export default function ChatScreen() {
  const { t, language, session } = useApp();
  const theme = useTheme();
  const [messages, setMessages] = useState<ChatMessage[] | null>(null);
  const [loadFailed, setLoadFailed] = useState(false);
  const [pending, setPending] = useState<Pending | null>(null);
  const [input, setInput] = useState('');
  const list = useRef<FlatList<ChatMessage>>(null);
  const farmerId = session?.user.id;

  useEffect(() => {
    if (!farmerId) return;
    fetchChatHistory().then((rows) => {
      setLoadFailed(rows === null);
      setMessages(rows ?? []);
    });
  }, [farmerId]);

  const send = async (text: string) => {
    const message = text.trim();
    if (!message || (pending && !pending.failed)) return;
    const localId = `local-${Date.now()}`;
    setInput('');
    setMessages((m) => [...(m ?? []).filter((x) => x.id !== pending?.localId), { id: localId, role: 'user', content: message, created_at: new Date().toISOString() }]);
    setPending({ localId, text: message, failed: null });
    const { reply, errorKey } = await sendChatMessage(message, language);
    if (reply) {
      setMessages((m) => [...(m ?? []), reply]);
      setPending(null);
    } else {
      setPending({ localId, text: message, failed: t[errorKey ?? 'chatFailed'] });
    }
  };

  if (messages === null) {
    return (
      <View style={[styles.center, { backgroundColor: theme.background }]}>
        <ActivityIndicator size="large" color={theme.primary} />
      </View>
    );
  }

  const thinking = pending && !pending.failed;
  return (
    <KeyboardAvoidingView style={[styles.flex, { backgroundColor: theme.background }]} behavior={Platform.OS === 'ios' ? 'padding' : undefined} keyboardVerticalOffset={Platform.OS === 'ios' ? 90 : 0}>
      <FlatList
        ref={list}
        style={styles.flex}
        contentContainerStyle={styles.list}
        data={messages}
        keyExtractor={(m) => m.id}
        onContentSizeChange={() => list.current?.scrollToEnd({ animated: true })}
        keyboardShouldPersistTaps="handled"
        ListHeaderComponent={
          <View style={[styles.bubble, styles.left, { backgroundColor: theme.backgroundElement }]}>
            <Text style={[styles.who, { color: theme.primary }]}>👨‍🌾 {t.chatExpert}</Text>
            <Text style={[styles.text, { color: theme.text }]}>{t.chatIntro}</Text>
            {loadFailed && <Text style={[styles.note, { color: theme.danger }]}>{t.errNetwork}</Text>}
          </View>
        }
        renderItem={({ item }) => {
          const mine = item.role === 'user';
          return (
            <View style={[styles.bubble, mine ? styles.right : styles.left, { backgroundColor: mine ? theme.primary : theme.backgroundElement }]}>
              {!mine && <Text style={[styles.who, { color: theme.primary }]}>👨‍🌾 {t.chatExpert}</Text>}
              <Text style={[styles.text, { color: mine ? theme.onPrimary : theme.text }]} selectable>{item.content}</Text>
            </View>
          );
        }}
        ListFooterComponent={
          thinking ? (
            <View style={[styles.bubble, styles.left, styles.row, { backgroundColor: theme.backgroundElement }]} accessibilityLiveRegion="polite">
              <ActivityIndicator color={theme.primary} />
              <Text style={[styles.text, { color: theme.textSecondary }]}>{t.chatThinking}</Text>
            </View>
          ) : pending?.failed ? (
            <View style={styles.failed} accessibilityLiveRegion="polite">
              <Text style={[styles.note, { color: theme.danger }]}>{pending.failed}</Text>
              <Pressable accessibilityRole="button" onPress={() => send(pending.text)} style={[styles.retry, { borderColor: theme.primary }]}>
                <Text style={[styles.retryText, { color: theme.primary }]}>{t.chatRetry}</Text>
              </Pressable>
            </View>
          ) : null
        }
      />

      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.chipRow} contentContainerStyle={styles.chips} keyboardShouldPersistTaps="handled">
        {t.chatChips.map((chip) => (
          <Pressable key={chip} accessibilityRole="button" onPress={() => send(chip)} disabled={!!thinking}
            style={({ pressed }) => [styles.chip, { borderColor: theme.primary }, (pressed || thinking) && styles.dim]}>
            <Text style={[styles.chipText, { color: theme.primary }]}>{chip}</Text>
          </Pressable>
        ))}
      </ScrollView>

      <View style={[styles.inputRow, { borderTopColor: theme.border }]}>
        <TextInput
          value={input}
          onChangeText={setInput}
          placeholder={t.chatPlaceholder}
          placeholderTextColor={theme.textSecondary}
          accessibilityLabel={t.chatPlaceholder}
          multiline
          maxLength={1000}
          style={[styles.input, { color: theme.text, borderColor: theme.border, backgroundColor: theme.backgroundElement }]}
        />
        <Pressable accessibilityRole="button" accessibilityLabel={t.chatSend} onPress={() => send(input)} disabled={!input.trim() || !!thinking}
          style={[styles.send, { backgroundColor: theme.primary }, (!input.trim() || thinking) && styles.dim]}>
          <Text style={[styles.sendText, { color: theme.onPrimary }]}>{t.chatSend}</Text>
        </Pressable>
      </View>
      <Text style={[styles.disclaimer, { color: theme.textSecondary }]}>{t.chatNote}</Text>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  list: { padding: Spacing.three, gap: Spacing.two },
  bubble: { maxWidth: '88%', borderRadius: Spacing.three, padding: Spacing.three, gap: Spacing.one },
  left: { alignSelf: 'flex-start', borderTopLeftRadius: Spacing.one },
  right: { alignSelf: 'flex-end', borderTopRightRadius: Spacing.one },
  row: { flexDirection: 'row', alignItems: 'center', gap: Spacing.two },
  who: { fontSize: 13, fontWeight: '800' },
  text: { fontSize: 17, lineHeight: 25 },
  note: { fontSize: 15, fontWeight: '600' },
  failed: { alignSelf: 'flex-end', alignItems: 'flex-end', gap: Spacing.two },
  retry: { minHeight: MinTouchTarget, borderWidth: 1.5, borderRadius: Spacing.three, paddingHorizontal: Spacing.three, justifyContent: 'center' },
  retryText: { fontSize: 16, fontWeight: '700' },
  chipRow: { flexGrow: 0 },
  chips: { paddingHorizontal: Spacing.three, paddingVertical: Spacing.two, gap: Spacing.two, alignItems: 'center' },
  chip: { minHeight: MinTouchTarget - 8, borderWidth: 1.5, borderRadius: Spacing.five, paddingHorizontal: Spacing.three, justifyContent: 'center' },
  chipText: { fontSize: 15, fontWeight: '600' },
  dim: { opacity: 0.5 },
  inputRow: { flexDirection: 'row', alignItems: 'flex-end', gap: Spacing.two, paddingHorizontal: Spacing.three, paddingTop: Spacing.two, borderTopWidth: 1 },
  input: { flex: 1, minHeight: MinTouchTarget, maxHeight: 140, borderWidth: 1.5, borderRadius: Spacing.three, paddingHorizontal: Spacing.three, paddingVertical: Spacing.two, fontSize: 17 },
  send: { minHeight: MinTouchTarget, minWidth: MinTouchTarget + 16, borderRadius: Spacing.three, paddingHorizontal: Spacing.three, alignItems: 'center', justifyContent: 'center' },
  sendText: { fontSize: 17, fontWeight: '800' },
  disclaimer: { fontSize: 12, textAlign: 'center', paddingHorizontal: Spacing.three, paddingVertical: Spacing.one },
});
