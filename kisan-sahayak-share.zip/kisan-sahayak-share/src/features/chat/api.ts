import { FunctionsHttpError } from '@supabase/supabase-js';

import type { Language } from '@/constants/strings';
import { demoChatHistory, demoChatSend } from '@/features/demo/store';
import { demoDelay, isDemoMode } from '@/lib/demo-mode';
import { supabase } from '@/lib/supabase';

export type ChatMessage = { id: string; role: 'user' | 'assistant'; content: string; created_at: string };
type ErrorKey = 'errAiBusy' | 'errTooMany' | 'errNetwork' | 'chatFailed';

const HISTORY_LIMIT = 100;

/** The farmer's own saved conversation (RLS), oldest first. */
export async function fetchChatHistory(): Promise<ChatMessage[] | null> {
  if (isDemoMode()) return demoChatHistory();
  const { data, error } = await supabase
    .from('chat_messages')
    .select('id, role, content, created_at')
    .order('created_at', { ascending: false })
    .limit(HISTORY_LIMIT);
  if (error) return null;
  return (data as ChatMessage[]).reverse();
}

/** The server saves both the question and the answer; the app only shows them. */
export async function sendChatMessage(message: string, language: Language): Promise<{ reply: ChatMessage | null; errorKey: ErrorKey | null }> {
  if (isDemoMode()) {
    await demoDelay(1800);
    return { reply: demoChatSend(message, language), errorKey: null };
  }
  const send = () => supabase.functions.invoke<{ id: string; created_at: string; reply: string }>('chat', { body: { message, language } });
  const statusOf = (e: unknown) => (e instanceof FunctionsHttpError ? (e.context as Response).status : 0);
  let { data, error } = await send();
  // Rare upstream AI stalls; a fresh request almost always succeeds (D-28).
  if (error && statusOf(error) === 503) ({ data, error } = await send());
  if (error || !data) {
    const status = statusOf(error);
    return { reply: null, errorKey: status === 503 ? 'errAiBusy' : status === 429 ? 'errTooMany' : status === 0 ? 'errNetwork' : 'chatFailed' };
  }
  return { reply: { id: data.id, role: 'assistant', content: data.reply, created_at: data.created_at }, errorKey: null };
}
