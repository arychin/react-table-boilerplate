// Follow-up loop check (MVP in-app version of Plan Phase 8 / TRD §7). Farmer actions use only the anon key + test logins.
// The service-role key is used ONLY to backdate the follow-up, as the Plan's DoD suggests ("test by inserting a backdated row").
// Run: eval "$(python3 scripts/load_secrets.py --with-service-role)" && node --env-file=.env scripts/check_followup_loop.mjs
import { createClient } from '@supabase/supabase-js';
import { readFileSync } from 'node:fs';

const url = process.env.EXPO_PUBLIC_SUPABASE_URL;
const anonKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY;
if (!process.env.SUPABASE_SERVICE_ROLE_KEY) {
  console.error('SUPABASE_SERVICE_ROLE_KEY not set — see the usage line at the top of this file.');
  process.exit(1);
}
const admin = createClient(url, process.env.SUPABASE_SERVICE_ROLE_KEY, { auth: { persistSession: false } });
let failures = 0;
const check = (label, ok, detail = '') => {
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${label}${detail ? `  (${detail})` : ''}`);
  if (!ok) failures += 1;
};

async function login(phone, otp) {
  const client = createClient(url, anonKey, { auth: { persistSession: false } });
  await client.auth.signInWithOtp({ phone });
  const { data } = await client.auth.verifyOtp({ phone, token: otp, type: 'sms' });
  return { client, id: data.user.id };
}
const answer = async (client, body) => {
  const { error } = await client.functions.invoke('follow-up-answer', { body });
  return error?.context?.status ?? 200;
};

const a = await login('+919000000001', '246810');
await new Promise((r) => setTimeout(r, 2500)); // Supabase OTP throttle between sends
const b = await login('+919000000002', '135790');

// 1. A real crop diagnosis creates the follow-up (TRD §7 step 1).
const leaf = readFileSync('test-assets/tomato_early_blight.jpg');
let dx = await a.client.functions.invoke('diagnose-crop', {
  body: leaf.buffer.slice(leaf.byteOffset, leaf.byteOffset + leaf.byteLength),
  headers: { 'Content-Type': 'image/jpeg', 'x-ks-language': 'hi' },
});
if (dx.error?.context?.status === 503) dx = await a.client.functions.invoke('diagnose-crop', { // same one retry the app does
  body: leaf.buffer.slice(leaf.byteOffset, leaf.byteOffset + leaf.byteLength),
  headers: { 'Content-Type': 'image/jpeg', 'x-ks-language': 'hi' },
});
check('crop diagnosis created', !!dx.data?.id, dx.error?.message);
await new Promise((r) => setTimeout(r, 2000)); // follow-up is written after the response
const { data: fu } = await a.client.from('follow_ups').select('id, status, scheduled_for').eq('diagnosis_id', dx.data.id).single();
check('follow-up pending, due in ~3 days', fu?.status === 'pending' && Math.abs(new Date(fu.scheduled_for) - Date.now() - 3 * 86400_000) < 120_000);

// 2. Not answerable before it is due.
check('answer before due → 409', (await answer(a.client, { follow_up_id: fu.id, outcome: 'improved', applied: true })) === 409);

// 3. Backdate (test only) and see it in the farmer's due list, exactly as the Home card queries it.
await admin.from('follow_ups').update({ scheduled_for: new Date(Date.now() - 3600_000).toISOString() }).eq('id', fu.id);
const { data: due } = await a.client.from('follow_ups').select('id, diagnoses!inner(id, type)').eq('status', 'pending').lte('scheduled_for', new Date().toISOString());
check('due follow-up visible to its farmer', (due ?? []).some((d) => d.id === fu.id));
const { data: bDue } = await b.client.from('follow_ups').select('id').eq('id', fu.id);
check('B cannot see A follow-up', (bDue ?? []).length === 0);

// 4. Guard rails.
check('B answering A follow-up → 404', (await answer(b.client, { follow_up_id: fu.id, outcome: 'worse', applied: false })) === 404);
check('bad outcome → 400', (await answer(a.client, { follow_up_id: fu.id, outcome: 'great' })) === 400);
const direct = await a.client.from('follow_ups').update({ status: 'responded' }).eq('id', fu.id).select('id');
check('farmer cannot update follow_ups directly', !!direct.error || (direct.data ?? []).length === 0, direct.error?.code ?? 'no rows changed');
const forged = await a.client.from('engagement_events').insert({ farmer_id: a.id, event_type: 'loop_completed', diagnosis_id: dx.data.id });
check('farmer cannot write loop_completed directly', !!forged.error, forged.error?.code);
const anon = createClient(url, anonKey, { auth: { persistSession: false } });
const noAuth = await anon.functions.invoke('follow-up-answer', { body: { follow_up_id: fu.id, outcome: 'improved' } });
check('anon key alone is rejected', noAuth.error?.context?.status === 401, `status ${noAuth.error?.context?.status}`);

// 5. The real answer closes the loop (TRD §7 step 4) — once only.
check('A answers: applied + improved → 200', (await answer(a.client, { follow_up_id: fu.id, outcome: 'improved', applied: true })) === 200);
const { data: after } = await a.client.from('follow_ups').select('status, farmer_response, treatment_applied, responded_at').eq('id', fu.id).single();
check('follow-up responded / improved / applied', after?.status === 'responded' && after.farmer_response === 'improved' && after.treatment_applied === true && !!after.responded_at, JSON.stringify(after));
const { data: events } = await a.client.from('engagement_events').select('event_type').eq('diagnosis_id', dx.data.id);
const kinds = (events ?? []).map((e) => e.event_type).sort();
check('engagement_events: diagnosis_completed + exactly one loop_completed', JSON.stringify(kinds) === '["diagnosis_completed","loop_completed"]', JSON.stringify(kinds));
check('second answer → 409, no extra event', (await answer(a.client, { follow_up_id: fu.id, outcome: 'worse', applied: false })) === 409);
const { count } = await admin.from('engagement_events').select('id', { count: 'exact', head: true }).eq('diagnosis_id', dx.data.id).eq('event_type', 'loop_completed');
check('  still exactly one loop_completed', count === 1, `count=${count}`);

console.log(failures ? `\n${failures} FAILED` : '\nALL PASS');
process.exit(failures ? 1 : 0);
