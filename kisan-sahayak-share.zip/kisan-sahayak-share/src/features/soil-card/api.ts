import AsyncStorage from '@react-native-async-storage/async-storage';
import { FunctionsHttpError } from '@supabase/supabase-js';

import { DEMO_SOIL_CARD } from '@/features/demo/data';
import type { PreparedImage } from '@/features/diagnosis/api';
import { demoDelay, isDemoMode } from '@/lib/demo-mode';
import { supabase } from '@/lib/supabase';

// Vision Brief §3.15: values are read from the farmer's own card, shown for confirmation, then saved.
export const CARD_KEYS = ['pH', 'EC', 'OC', 'N', 'P', 'K', 'S', 'Zn', 'B', 'Fe', 'Mn', 'Cu'] as const;
export type CardKey = (typeof CARD_KEYS)[number];
export type Level = 'low' | 'ok' | 'high' | 'acidic' | 'neutral' | 'alkaline' | 'normal' | 'salty' | 'unknown';
export type CardRow = { key: CardKey; value: string; unit: string; level: Level };
export type SoilCard = { sample_date: string; rows: CardRow[]; saved_at: string };
type ReadResult = { is_soil_health_card: boolean; sample_date: string; parameters: { key: CardKey; value: string; unit: string; rating: string }[] };

export const LEVEL_CHOICES: Record<'pH' | 'EC' | 'nutrient', Level[]> = {
  pH: ['acidic', 'neutral', 'alkaline'],
  EC: ['normal', 'salty'],
  nutrient: ['low', 'ok', 'high'],
};
export const choicesFor = (key: CardKey) => (key === 'pH' || key === 'EC' ? LEVEL_CHOICES[key] : LEVEL_CHOICES.nutrient);

/** pH and EC follow the Soil Health Card classes from the number; nutrients follow the rating printed on the card. */
export function levelFor(key: CardKey, value: string, rating: string): Level {
  const n = Number(value.replace(',', '.'));
  const r = rating.toLowerCase();
  if (key === 'pH') {
    if (Number.isFinite(n) && n > 0) return n < 6.5 ? 'acidic' : n <= 7.5 ? 'neutral' : 'alkaline';
    return r.includes('acid') ? 'acidic' : r.includes('alkal') ? 'alkaline' : r.includes('neutral') ? 'neutral' : 'unknown';
  }
  if (key === 'EC') {
    if (Number.isFinite(n) && n >= 0 && value.trim()) return n < 1 ? 'normal' : 'salty';
    return r.includes('normal') ? 'normal' : r ? 'salty' : 'unknown';
  }
  // "Insufficient"/"अपर्याप्त" contain "sufficient"/"पर्याप्त", so the low words must be tested first.
  if (/deficien|insufficien|inadequate|low|कम|न्यून|अपर्याप्त|कमी/.test(r)) return 'low';
  if (/high|excess|अधिक|उच्च|ज़्यादा|ज्यादा/.test(r)) return 'high';
  if (/medium|moderate|sufficien|adequate|normal|मध्यम|पर्याप्त|सामान्य/.test(r)) return 'ok';
  return 'unknown';
}

type ErrorKey = 'cardNotCard' | 'cardNothingRead' | 'errAiBusy' | 'errBadImage' | 'errNetwork' | 'errDiagnose';

export async function readSoilCard(image: PreparedImage): Promise<{ card: Omit<SoilCard, 'saved_at'> | null; errorKey: ErrorKey | null }> {
  let data: ReadResult;
  if (isDemoMode()) {
    await demoDelay(2200);
    data = DEMO_SOIL_CARD;
  } else {
    const body = image.bytes.buffer.slice(image.bytes.byteOffset, image.bytes.byteOffset + image.bytes.byteLength) as ArrayBuffer;
    const res = await supabase.functions.invoke<ReadResult>('read-soil-card', { body, headers: { 'Content-Type': image.contentType } });
    if (res.error || !res.data) {
      const status = res.error instanceof FunctionsHttpError ? (res.error.context as Response).status : 0;
      return { card: null, errorKey: status === 503 ? 'errAiBusy' : status === 413 || status === 415 ? 'errBadImage' : status === 0 ? 'errNetwork' : 'errDiagnose' };
    }
    data = res.data;
  }
  if (!data.is_soil_health_card) return { card: null, errorKey: 'cardNotCard' };
  const rows = CARD_KEYS.flatMap((key) => {
    const p = data.parameters.find((x) => x.key === key);
    return p ? [{ key, value: p.value, unit: p.unit === '—' ? '' : p.unit, level: levelFor(key, p.value, p.rating) }] : [];
  });
  if (!rows.length) return { card: null, errorKey: 'cardNothingRead' };
  return { card: { sample_date: data.sample_date, rows }, errorKey: null };
}

// Saved on the phone for now; Farm Memory (Vision Brief §3.14) will attach it to a field later.
const storageKey = (farmerId: string) => `ks.soilCard.${farmerId}`;

export async function loadSoilCard(farmerId: string): Promise<SoilCard | null> {
  const raw = await AsyncStorage.getItem(storageKey(farmerId));
  return raw ? (JSON.parse(raw) as SoilCard) : null;
}

export async function saveSoilCard(farmerId: string, card: Omit<SoilCard, 'saved_at'>): Promise<SoilCard> {
  const saved = { ...card, saved_at: new Date().toISOString() };
  await AsyncStorage.setItem(storageKey(farmerId), JSON.stringify(saved));
  return saved;
}
