-- Phase 1: TRD §5 schema + §5.6 Row Level Security.
-- Column names are final per TRD §5; do not rename without updating the TRD first.

-- 5.1 farmers ---------------------------------------------------------------
-- App sign-ups get id = auth.users.id (trigger below), so RLS can use auth.uid().
-- No FK to auth.users: WhatsApp-only farmers (TRD 6.3, post-MVP) have no auth user.
create table public.farmers (
  id                 uuid primary key default gen_random_uuid(),
  phone_number       text not null unique check (phone_number ~ '^\+[1-9][0-9]{7,14}$'),
  name               text,
  preferred_language text not null default 'hi' check (preferred_language in ('hi', 'en')),
  district           text,
  last_known_lat     numeric,
  last_known_lng     numeric,
  created_at         timestamptz not null default now()
);

-- 5.2 diagnoses -------------------------------------------------------------
create table public.diagnoses (
  id             uuid primary key default gen_random_uuid(),
  farmer_id      uuid not null references public.farmers (id) on delete cascade,
  type           text not null check (type in ('crop', 'soil')),
  image_url      text not null,
  diagnosis_json jsonb not null,
  hindi_summary  text, -- nullable: the summary is a separate, non-blocking call (TRD §6.1)
  channel        text not null default 'app' check (channel in ('app', 'whatsapp', 'ivr')),
  created_at     timestamptz not null default now()
);
create index diagnoses_farmer_id_created_at_idx on public.diagnoses (farmer_id, created_at desc);

-- 5.3 follow_ups ------------------------------------------------------------
create table public.follow_ups (
  id              uuid primary key default gen_random_uuid(),
  diagnosis_id    uuid not null references public.diagnoses (id) on delete cascade,
  scheduled_for   timestamptz not null,
  status          text not null default 'pending' check (status in ('pending', 'sent', 'responded', 'failed')),
  farmer_response text,
  responded_at    timestamptz
);
create index follow_ups_diagnosis_id_idx on public.follow_ups (diagnosis_id);
create index follow_ups_due_idx on public.follow_ups (scheduled_for) where status = 'pending';

-- 5.4 chat_messages ---------------------------------------------------------
create table public.chat_messages (
  id         uuid primary key default gen_random_uuid(),
  farmer_id  uuid not null references public.farmers (id) on delete cascade,
  role       text not null check (role in ('user', 'assistant')),
  content    text not null,
  created_at timestamptz not null default now()
);
create index chat_messages_farmer_id_created_at_idx on public.chat_messages (farmer_id, created_at);

-- 5.5 engagement_events -----------------------------------------------------
create table public.engagement_events (
  id           uuid primary key default gen_random_uuid(),
  farmer_id    uuid not null references public.farmers (id) on delete cascade,
  event_type   text not null check (event_type in ('diagnosis_completed', 'loop_completed')),
  diagnosis_id uuid references public.diagnoses (id) on delete set null,
  created_at   timestamptz not null default now()
);
create index engagement_events_farmer_id_idx on public.engagement_events (farmer_id);
create index engagement_events_type_created_at_idx on public.engagement_events (event_type, created_at);

-- 5.6 Row Level Security — enabled on every table before any app use --------
alter table public.farmers           enable row level security;
alter table public.diagnoses         enable row level security;
alter table public.follow_ups        enable row level security;
alter table public.chat_messages     enable row level security;
alter table public.engagement_events enable row level security;

-- Explicit, least-privilege grants (don't rely on platform defaults).
revoke all on public.farmers, public.diagnoses, public.follow_ups, public.chat_messages, public.engagement_events from anon, authenticated;
grant all on public.farmers, public.diagnoses, public.follow_ups, public.chat_messages, public.engagement_events to service_role;
grant select on public.farmers, public.diagnoses, public.follow_ups, public.chat_messages, public.engagement_events to authenticated;
grant update (name, preferred_language, district, last_known_lat, last_known_lng) on public.farmers to authenticated;
grant insert on public.chat_messages to authenticated;

-- farmers: read own row; update only the granted profile columns (never id or phone_number).
create policy "farmers: read own row" on public.farmers
  for select to authenticated using (id = (select auth.uid()));
create policy "farmers: update own row" on public.farmers
  for update to authenticated using (id = (select auth.uid())) with check (id = (select auth.uid()));

-- diagnoses / engagement_events: written only by Edge Functions (service role) so the 4A metric can't be forged.
create policy "diagnoses: read own" on public.diagnoses
  for select to authenticated using (farmer_id = (select auth.uid()));
create policy "engagement_events: read own" on public.engagement_events
  for select to authenticated using (farmer_id = (select auth.uid()));

-- follow_ups: owned through the parent diagnosis.
create policy "follow_ups: read own" on public.follow_ups
  for select to authenticated using (
    exists (select 1 from public.diagnoses d where d.id = diagnosis_id and d.farmer_id = (select auth.uid()))
  );

-- chat_messages: farmer reads and writes own history.
create policy "chat_messages: read own" on public.chat_messages
  for select to authenticated using (farmer_id = (select auth.uid()));
create policy "chat_messages: insert own" on public.chat_messages
  for insert to authenticated with check (farmer_id = (select auth.uid()));

-- TRD §6.6: create the farmers row as soon as phone OTP verification creates the auth user.
create function public.handle_new_auth_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if new.phone is not null and new.phone <> '' then
    insert into public.farmers (id, phone_number)
    values (new.id, '+' || ltrim(new.phone, '+'))
    -- never block sign-up; linking an existing WhatsApp-only farmer row is a Phase 7 task
    on conflict do nothing;
  end if;
  return new;
end;
$$;
revoke execute on function public.handle_new_auth_user() from public, anon, authenticated;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_auth_user();
