import { router, useFocusEffect } from 'expo-router';
import { useCallback, useState } from 'react';
import { Linking, Pressable, StyleSheet, Text, View } from 'react-native';

import { Button } from '@/components/ui/button';
import { MinTouchTarget, Spacing } from '@/constants/theme';
import { useApp } from '@/features/auth/app-context';
import { useTheme } from '@/hooks/use-theme';

import { answerFollowUp, fetchDueFollowUp, type DueFollowUp, type Outcome } from './api';

const KISAN_CALL_CENTRE = 'tel:18001801551';

// Vision Brief §3.3: "did you apply the treatment, and is it getting better?" — then a next step if not.
export function CheckInCard() {
  const { t } = useApp();
  const theme = useTheme();
  const [due, setDue] = useState<DueFollowUp | null>(null);
  const [applied, setApplied] = useState<boolean | null>(null);
  const [outcome, setOutcome] = useState<Outcome | null>(null);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useFocusEffect(
    useCallback(() => {
      fetchDueFollowUp().then((next) => {
        setDue(next);
        setApplied(null);
        setOutcome(null);
      });
    }, []),
  );

  if (!due) return null;

  const submit = async (choice: Outcome) => {
    setSaving(true);
    setError(null);
    const result = await answerFollowUp(due.id, choice, due.askApplied ? applied : null);
    setSaving(false);
    if (result === 'ok') setOutcome(choice);
    else setError(t[result]);
  };
  const openReport = () => router.push({ pathname: '/diagnosis/[id]', params: { id: due.diagnosisId } });

  return (
    <View style={[styles.card, { backgroundColor: theme.successBg, borderColor: theme.primary }]} accessibilityLiveRegion="polite">
      <Text style={[styles.title, { color: theme.primary }]}>🌱 {t.checkInTitle}</Text>
      <Pressable accessibilityRole="link" onPress={openReport}>
        <Text style={[styles.subject, { color: theme.text }]}>{due.crop} · {due.problem}</Text>
        <Text style={[styles.note, { color: theme.textSecondary }]}>{t.checkInAgo(due.daysAgo)}</Text>
      </Pressable>

      {outcome === 'improved' ? (
        <Text style={[styles.question, { color: theme.text }]}>{t.checkInThanks}</Text>
      ) : outcome ? (
        <>
          <Text style={[styles.question, { color: theme.text }]}>{applied === false ? t.checkInNotApplied : t.checkInNextSteps}</Text>
          {applied === false && <Button label={t.checkInOpenReport} variant="secondary" onPress={openReport} />}
          <Button label={`📸 ${t.checkInNewPhoto}`} onPress={() => router.push({ pathname: '/diagnosis/camera', params: { kind: 'crop' } })} />
          <Button label={`🏪 ${t.checkInShops}`} variant="secondary" onPress={() => router.push('/shops')} />
          <Button label={`📞 ${t.checkInCall}`} variant="secondary" onPress={() => Linking.openURL(KISAN_CALL_CENTRE)} />
        </>
      ) : due.askApplied && applied === null ? (
        <>
          <Text style={[styles.question, { color: theme.text }]}>{t.checkInApplied}</Text>
          <View style={styles.row}>
            <Choice label={t.checkInYes} onPress={() => setApplied(true)} />
            <Choice label={t.checkInNo} onPress={() => setApplied(false)} />
          </View>
        </>
      ) : (
        <>
          <Text style={[styles.question, { color: theme.text }]}>{t.checkInHow}</Text>
          <View style={styles.column}>
            <Choice label={`🌱 ${t.checkInOutcome.improved}`} onPress={() => submit('improved')} disabled={saving} />
            <Choice label={`😐 ${t.checkInOutcome.no_change}`} onPress={() => submit('no_change')} disabled={saving} />
            <Choice label={`🥀 ${t.checkInOutcome.worse}`} onPress={() => submit('worse')} disabled={saving} />
          </View>
          {error && <Text style={[styles.note, { color: theme.danger }]}>{error}</Text>}
        </>
      )}
    </View>
  );
}

function Choice({ label, onPress, disabled = false }: { label: string; onPress: () => void; disabled?: boolean }) {
  const theme = useTheme();
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{ disabled }}
      disabled={disabled}
      onPress={onPress}
      style={({ pressed }) => [styles.choice, { borderColor: theme.primary, backgroundColor: theme.background }, (pressed || disabled) && styles.dim]}>
      <Text style={[styles.choiceText, { color: theme.primary }]}>{label}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: { borderRadius: Spacing.four, borderWidth: 2, padding: Spacing.three, gap: Spacing.two },
  title: { fontSize: 18, fontWeight: '800' },
  subject: { fontSize: 17, fontWeight: '700' },
  note: { fontSize: 14 },
  question: { fontSize: 18, fontWeight: '700', lineHeight: 26, marginTop: Spacing.one },
  row: { flexDirection: 'row', gap: Spacing.two },
  column: { gap: Spacing.two },
  choice: { flex: 1, minHeight: MinTouchTarget, borderWidth: 2, borderRadius: Spacing.three, alignItems: 'center', justifyContent: 'center', paddingHorizontal: Spacing.three },
  choiceText: { fontSize: 18, fontWeight: '800' },
  dim: { opacity: 0.6 },
});
