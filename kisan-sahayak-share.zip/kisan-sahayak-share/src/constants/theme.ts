/**
 * Below are the colors that are used in the app. The colors are defined in the light and dark mode.
 * There are many other ways to style your app. For example, [Nativewind](https://www.nativewind.dev/), [Tamagui](https://tamagui.dev/), [unistyles](https://reactnativeunistyles.vercel.app), etc.
 */

import '@/global.css';

import { Platform } from 'react-native';

export const Colors = {
  light: {
    text: '#11181C',
    background: '#ffffff',
    backgroundElement: '#F1F5F0',
    backgroundSelected: '#DCEBD8',
    textSecondary: '#4A5548',
    primary: '#1B6E3A',
    onPrimary: '#ffffff',
    border: '#B9C7B5',
    danger: '#B42318',
    warning: '#B54708',
    warningBg: '#FEF0C7',
    successBg: '#DCFAE6',
    dangerBg: '#FEE4E2',
  },
  dark: {
    text: '#ffffff',
    background: '#0C120D',
    backgroundElement: '#1A231B',
    backgroundSelected: '#253526',
    textSecondary: '#B7C4B4',
    primary: '#4CBF73',
    onPrimary: '#06210F',
    border: '#3A4A3B',
    danger: '#F97066',
    warning: '#FDB022',
    warningBg: '#4E1D09',
    successBg: '#053321',
    dangerBg: '#55160C',
  },
} as const;

// Vision Brief §9: big targets for muddy or wet hands.
export const MinTouchTarget = 56;

export type ThemeColor = keyof typeof Colors.light & keyof typeof Colors.dark;

export const Fonts = Platform.select({
  ios: {
    /** iOS `UIFontDescriptorSystemDesignDefault` */
    sans: 'system-ui',
    /** iOS `UIFontDescriptorSystemDesignSerif` */
    serif: 'ui-serif',
    /** iOS `UIFontDescriptorSystemDesignRounded` */
    rounded: 'ui-rounded',
    /** iOS `UIFontDescriptorSystemDesignMonospaced` */
    mono: 'ui-monospace',
  },
  default: {
    sans: 'normal',
    serif: 'serif',
    rounded: 'normal',
    mono: 'monospace',
  },
  web: {
    sans: 'var(--font-display)',
    serif: 'var(--font-serif)',
    rounded: 'var(--font-rounded)',
    mono: 'var(--font-mono)',
  },
});

export const Spacing = {
  half: 2,
  one: 4,
  two: 8,
  three: 16,
  four: 24,
  five: 32,
  six: 64,
} as const;

export const BottomTabInset = Platform.select({ ios: 50, android: 80 }) ?? 0;
export const MaxContentWidth = 800;
