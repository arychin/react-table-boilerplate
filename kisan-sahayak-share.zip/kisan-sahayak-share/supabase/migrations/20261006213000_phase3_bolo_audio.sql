-- Phase 3: private cache for Bolo audio (TRD §6.2: "cache the decoded audio … against the diagnosis id").
-- Path: <farmer id>/<diagnosis id>.mp3. Only the bolo Edge Function (service role) writes here.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('bolo-audio', 'bolo-audio', false, 2097152, array['audio/mpeg'])
on conflict (id) do nothing;

create policy "bolo-audio: read own folder" on storage.objects
  for select to authenticated
  using (bucket_id = 'bolo-audio' and (storage.foldername(name))[1] = (select auth.uid())::text);
