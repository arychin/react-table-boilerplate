// In-app follow-up answer (TRD §7 step 4 without WhatsApp; Vision Brief §3.3 + §4A).
// Server-side so the 4A metric (loop_completed) can't be written by the app directly.
import { adminClient, cors, fail, signedInFarmer } from '../_shared/http.ts';

const OUTCOMES = ['improved', 'no_change', 'worse'];
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  if (req.method !== 'POST') return fail(405, 'method_not_allowed');
  const farmerId = signedInFarmer(req);
  if (!farmerId) return fail(401, 'unauthorized');

  const body = await req.json().catch(() => null) as { follow_up_id?: unknown; outcome?: unknown; applied?: unknown } | null;
  const id = typeof body?.follow_up_id === 'string' && UUID.test(body.follow_up_id) ? body.follow_up_id : null;
  const outcome = typeof body?.outcome === 'string' && OUTCOMES.includes(body.outcome) ? body.outcome : null;
  const applied = typeof body?.applied === 'boolean' ? body.applied : null;
  if (!id || !outcome) return fail(400, 'bad_request');

  const admin = adminClient();
  const { data: row } = await admin.from('follow_ups')
    .select('id, status, scheduled_for, diagnosis_id, diagnoses!inner(farmer_id)')
    .eq('id', id).eq('diagnoses.farmer_id', farmerId).maybeSingle();
  if (!row) return fail(404, 'not_found');
  if (row.status === 'responded') return fail(409, 'already_answered');
  if (new Date(row.scheduled_for).getTime() > Date.now()) return fail(409, 'not_due');

  const respondedAt = new Date().toISOString();
  // The status filter makes a double tap or a parallel request a no-op instead of a second loop_completed.
  const { data: updated } = await admin.from('follow_ups')
    .update({ status: 'responded', farmer_response: outcome, treatment_applied: applied, responded_at: respondedAt })
    .eq('id', id).in('status', ['pending', 'sent']).select('id');
  if (!updated?.length) return fail(409, 'already_answered');

  const { error } = await admin.from('engagement_events')
    .insert({ farmer_id: farmerId, event_type: 'loop_completed', diagnosis_id: row.diagnosis_id });
  if (error) console.error(`follow-up-answer: loop_completed not logged for ${id}`);

  return Response.json({ ok: true, responded_at: respondedAt }, { headers: cors });
});
