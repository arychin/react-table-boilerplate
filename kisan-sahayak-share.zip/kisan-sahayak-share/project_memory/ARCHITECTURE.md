# Architecture

Status: **PLANNED ONLY — nothing built.** Everything below comes from the TRD v1 PDF. It is not an observed implementation.

Source documents, kept outside the repo, not yet copied to /docs:
`/Users/Achint.Tiwary/Downloads/New folder/`
- Kisan_Sahayak_Vision_Brief_v4_FINAL.pdf (PRD)
- Kisan_Sahayak_TRD_v1.pdf (TRD)
- Kisan_Sahayak_Implementation_Plan_v1.pdf (build order)
- Kisan_Sahayak_Working_Instructions.md (process rules)

## Product in one line
AI advisory agent for smallholder farmers in Chhattisgarh:
photo → Hindi diagnosis (text and voice) → nearby shop → follow-up check-in about 3 days later.

## Locked stack (TRD §2)
| Layer | Choice |
|---|---|
| App | React Native + Expo, TypeScript strict, Expo Router |
| Backend / DB | Supabase (Postgres, Auth, Storage, Edge Functions) |
| Vision / chat AI | Gemini Flash; structured output via responseSchema |
| Hindi TTS | Sarvam AI Bulbul v3 (REST) |
| Messaging | WhatsApp Cloud API via a BSP (AiSensy / Interakt) |
| Weather | OpenWeatherMap or equivalent |
| Shop finder | Bundled src/data/shops.json + src/lib/haversine.ts; no network |
| Scheduling | pg_cron + pg_net → send-followup Edge Function |
| Build | EAS Build + EAS Update (profiles: development / preview / production) |

## Planned data flow
```
Android app (Expo) ──HTTPS──> Supabase Edge Functions ──> Gemini / Sarvam / WhatsApp / Weather
      │                              │
      │ (anon key + RLS)             └── Postgres: farmers, diagnoses, follow_ups,
      │                                            chat_messages, engagement_events
      └── on-device: shops.json + haversine.ts (offline)

WhatsApp user ──> whatsapp-webhook (verify signature, return 200 at once, then process async)
                  └──> same diagnosis + TTS pipeline ──> voice-note reply
pg_cron (hourly) ──pg_net──> send-followup ──> WhatsApp template ──> reply ──> engagement_events
```

## Hard rules (TRD §3, §6, §8, §11)
- No third-party API keys in src/. Only EXPO_PUBLIC_SUPABASE_URL and EXPO_PUBLIC_SUPABASE_ANON_KEY are allowed client-side
- RLS enabled on every table before the app uses it
- Exactly one Haversine implementation
- MIME type auto-detected; never hardcode image/jpeg
- The Hindi summary is a separate, non-blocking call
- isDemoMode is checked first in every function that makes a network or AI call
- Webhook: HMAC-SHA256 signature check; iterate all arrays in the payload
- Service-role key kept in Supabase Vault, never in migrations
- Private storage bucket; signed URLs only

## Evolution
- 2026-09-29: architecture recorded from TRD v1. No deviations yet.
- 2026-10-02 (Phase 0): the skeleton matches TRD §3.
  - Actual versions: Expo SDK 57 / RN 0.86 / React 19.2 / TS 6.0
  - Supabase project: Tokyo region (OQ-9)
  - Environment constraint: the corporate proxy blocks Gemini and Sarvam from the dev laptop, so AI Edge Functions are tested only when deployed (D-14). This is consistent with the TRD rule that every AI call goes through Edge Functions.
  - Web output set to `single` (D-15)
- 2026-10-07 (Phase 4): shop finder as the TRD specifies: bundled JSON + on-device Haversine, no network
  - Coordinates come only from Nominatim-verified Plus Codes in the addresses (D-31); everything else gets Directions by name + address
  - Location is expo-location, foreground only
