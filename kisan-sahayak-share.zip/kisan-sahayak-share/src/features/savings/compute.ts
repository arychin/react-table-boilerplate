// Savings Tracker (Vision Brief Phase 4 vision, D-39): every number is labelled measured, farmer-confirmed or estimated.
export type SavingsInput = {
  spray_decision: 'not_needed' | 'wait_and_watch' | 'spray_recommended';
  confidence: 'low' | 'medium' | 'high';
  response: 'improved' | 'no_change' | 'worse' | null; // follow-up answer, null if not answered
  applied: boolean | null;
};

export type Savings = {
  checks: number; // measured: crop checks done
  noSprayAdvice: number; // measured: times the app said no spray is needed
  avoidedConfirmed: number; // farmer-confirmed: crop was fine without spraying
  recovered: number; // farmer-confirmed: treatment applied and crop got better
  estimatedRupees: number | null; // estimate: noSprayAdvice × the farmer's own cost of one spray
};

export function computeSavings(rows: SavingsInput[], costPerSpray: number | null): Savings {
  const noSprayAdvice = rows.filter((r) => r.spray_decision === 'not_needed' && r.confidence !== 'low').length;
  // An unclear photo gave no real advice, so it never counts as the app's credit.
  const okWithoutSpray = (r: SavingsInput) =>
    r.confidence !== 'low' &&
    (r.response === 'improved' || r.response === 'no_change') &&
    (r.spray_decision === 'not_needed' || (r.spray_decision === 'wait_and_watch' && r.applied === false));
  return {
    checks: rows.length,
    noSprayAdvice,
    avoidedConfirmed: rows.filter(okWithoutSpray).length,
    recovered: rows.filter((r) => r.response === 'improved' && r.applied === true).length,
    estimatedRupees: costPerSpray && costPerSpray > 0 ? Math.round(noSprayAdvice * costPerSpray) : null,
  };
}
