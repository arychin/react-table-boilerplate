import type { Weather } from './api';

// Vision Brief §3.5: plain conditional rules, not AI (TRD §6.4). Most urgent first; the card shows the top two.
export type AdviceKey = 'rain' | 'wind' | 'heat' | 'fungus' | 'spray_ok' | 'normal';

const RAIN_CHANCE = 60; // % in the next 12 h
const WIND_KMH = 15; // spray drifts above ~15 km/h
const HEAT_C = 40; // IMD heat-wave threshold for the plains
const HUMID = 85; // %, fungal disease weather

export function adviceFor(w: Weather): AdviceKey[] {
  const raining = ['Rain', 'Drizzle', 'Thunderstorm'].includes(w.condition);
  const out: AdviceKey[] = [];
  if (raining || w.rain_chance >= RAIN_CHANCE) out.push('rain');
  if (w.wind_kmh >= WIND_KMH) out.push('wind');
  if (w.temp_max_c >= HEAT_C) out.push('heat');
  if (w.humidity >= HUMID) out.push('fungus');
  if (!out.length && w.rain_chance < 30 && w.wind_kmh < 10 && w.humidity < 80) out.push('spray_ok');
  if (!out.length) out.push('normal');
  return out.slice(0, 2);
}
