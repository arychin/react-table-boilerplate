import { DISTRICTS } from '@/constants/districts';
import shopData from '@/data/shops.json';
import type { Coords } from '@/hooks/use-device-location';
import { haversine } from '@/lib/haversine';

// TRD §6.5: bundled data + on-device Haversine only. No network, no AI.
// Ranking is distance only (then "has a phone", then name) — the diagnosis never influences which shop is shown.
export type Shop = (typeof shopData)[number];
export type ShopHit = Shop & { distanceKm: number | null };

const NEAR_KM = 50;
const SHOPS: Shop[] = shopData;
const HINDI_DISTRICT = new Map<string, string>(DISTRICTS.map((d) => [d.en, d.hi]));

/**
 * Most shops have no trusted coordinates (D-12), so the list is: every located shop within NEAR_KM,
 * plus every shop in the farmer's district. The district is the one saved in their profile, else the
 * district of the nearest located shop. A search query looks across the whole state instead.
 */
export function findShops({ from, district, query = '' }: { from: Coords | null; district: string | null; query?: string }) {
  const hits: ShopHit[] = SHOPS.map((s) => ({
    ...s,
    distanceKm:
      from && s.latitude !== null && s.longitude !== null
        ? haversine(from.latitude, from.longitude, s.latitude, s.longitude)
        : null,
  }));
  hits.sort(byDistance);

  const q = query.trim().toLowerCase();
  if (q) {
    const matches = hits.filter((h) =>
      `${h.name} ${h.address} ${h.district ?? ''} ${HINDI_DISTRICT.get(h.district ?? '') ?? ''}`.toLowerCase().includes(q),
    );
    return { shops: matches, area: null };
  }

  const nearest = hits[0]?.distanceKm != null && hits[0].distanceKm <= NEAR_KM ? hits[0] : null;
  const area = district ?? nearest?.district ?? null;
  const shops = hits.filter((h) => (h.distanceKm !== null && h.distanceKm <= NEAR_KM) || (area !== null && h.district === area));
  return { shops, area };
}

function byDistance(a: ShopHit, b: ShopHit): number {
  if (a.distanceKm !== null || b.distanceKm !== null) {
    if (a.distanceKm === null) return 1;
    if (b.distanceKm === null) return -1;
    return a.distanceKm - b.distanceKm;
  }
  if (!!a.phone !== !!b.phone) return a.phone ? -1 : 1;
  return a.name.localeCompare(b.name);
}

export function districtLabel(district: string, language: 'hi' | 'en'): string {
  return language === 'hi' ? (HINDI_DISTRICT.get(district) ?? district) : district;
}

/** Vision Brief §3.7 URL. Without trusted coordinates, search by name + address instead (D-12). */
export function directionsUrl(shop: Shop): string {
  const query = shop.latitude !== null && shop.longitude !== null ? `${shop.latitude},${shop.longitude}` : `${shop.name}, ${shop.address}`;
  return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(query)}`;
}
