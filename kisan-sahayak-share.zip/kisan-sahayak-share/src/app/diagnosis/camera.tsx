import { Image } from 'expo-image';
import { router, Stack, useLocalSearchParams } from 'expo-router';
import { useCallback, useEffect, useRef, useState } from 'react';
import { ActivityIndicator, ScrollView, StyleSheet, Text, View } from 'react-native';

import { Button } from '@/components/ui/button';
import { Spacing } from '@/constants/theme';
import { useApp } from '@/features/auth/app-context';
import { diagnosePhoto, prepareImage, type PreparedImage } from '@/features/diagnosis/api';
import { PhotoTips } from '@/features/diagnosis/photo-tips';
import { pickAndDiagnose } from '@/features/diagnosis/pick-image';
import { useTheme } from '@/hooks/use-theme';
import type { Kind } from '@/types/diagnosis';

type Stage = 'preparing' | 'analysing' | 'error' | 'idle';

// Plan Phase 2: capture/pick → diagnose-crop (stores the photo privately + Gemini) → result screen. Soil uses the same path.
export default function CameraScreen() {
  const params = useLocalSearchParams<{ uri?: string; width?: string; height?: string; mimeType?: string; kind?: string }>();
  const kind: Kind = params.kind === 'soil' ? 'soil' : 'crop';
  const { language, t } = useApp();
  const theme = useTheme();
  const [stage, setStage] = useState<Stage>(params.uri ? 'preparing' : 'idle');
  const [preview, setPreview] = useState(params.uri);
  const [error, setError] = useState<string | null>(null);
  const prepared = useRef<PreparedImage | null>(null);

  // Every state change happens after an await, so the effect below never sets state synchronously.
  const process = useCallback(async () => {
    if (!params.uri) return;
    const image = prepared.current ?? (await prepareImage({
      uri: params.uri,
      width: Number(params.width),
      height: Number(params.height),
      mimeType: params.mimeType || null,
    }));
    if (!image) return;
    prepared.current = image;
    setPreview(image.previewUri);
    setStage('analysing');
    const result = await diagnosePhoto(image, language, kind);
    if (result.errorKey || !result.id) {
      setStage('error');
      setError(t[result.errorKey ?? 'errDiagnose']);
      return;
    }
    router.replace({ pathname: '/diagnosis/[id]', params: { id: result.id } });
  }, [params.uri, params.width, params.height, params.mimeType, language, t, kind]);

  useEffect(() => {
    process();
  }, [process]);

  const retry = () => {
    setError(null);
    setStage('analysing');
    process();
  };
  const denied = () => setError(t.cameraDenied);
  const title = <Stack.Screen options={{ title: kind === 'soil' ? t.soilCheck : t.cropProblem }} />;

  if (stage === 'idle') {
    return (
      <ScrollView style={{ backgroundColor: theme.background }} contentContainerStyle={styles.content}>
        {title}
        <PhotoTips kind={kind} />
        {error && <Text style={[styles.error, { color: theme.danger }]}>{error}</Text>}
        <Button label={t.takePhoto} onPress={() => pickAndDiagnose('camera', denied, kind)} />
        <Button variant="secondary" label={t.pickPhoto} onPress={() => pickAndDiagnose('gallery', denied, kind)} />
      </ScrollView>
    );
  }

  const stageText = stage === 'preparing' ? t.stagePreparing : kind === 'soil' ? t.stageAnalysingSoil : t.stageAnalysing;
  return (
    <ScrollView style={{ backgroundColor: theme.background }} contentContainerStyle={styles.content}>
      {title}
      <Image
        source={{ uri: preview }}
        style={[styles.preview, stage !== 'error' && styles.previewBusy]}
        contentFit="cover"
        accessibilityIgnoresInvertColors
      />
      {stage === 'error' ? (
        <>
          <Text style={[styles.error, { color: theme.danger }]}>{error}</Text>
          <Button label={t.tryAgain} onPress={retry} />
          <Button variant="secondary" label={t.takePhoto} onPress={() => pickAndDiagnose('camera', denied, kind)} />
        </>
      ) : (
        <View style={styles.progress} accessibilityLiveRegion="polite">
          <ActivityIndicator size="large" color={theme.primary} />
          <Text style={[styles.stage, { color: theme.text }]}>{stageText}</Text>
          <StageDots stage={stage} />
        </View>
      )}
    </ScrollView>
  );
}

function StageDots({ stage }: { stage: Stage }) {
  const theme = useTheme();
  const order: Stage[] = ['preparing', 'analysing'];
  const current = order.indexOf(stage);
  return (
    <View style={styles.dots}>
      {order.map((s, i) => (
        <View key={s} style={[styles.dot, { backgroundColor: i <= current ? theme.primary : theme.border }]} />
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  content: { padding: Spacing.four, gap: Spacing.three },
  preview: { width: '100%', aspectRatio: 1, borderRadius: Spacing.three },
  previewBusy: { opacity: 0.6 },
  progress: { alignItems: 'center', gap: Spacing.three, paddingVertical: Spacing.four },
  stage: { fontSize: 20, fontWeight: '700' },
  dots: { flexDirection: 'row', gap: Spacing.two },
  dot: { width: 28, height: 6, borderRadius: 3 },
  error: { fontSize: 17, fontWeight: '600' },
});
