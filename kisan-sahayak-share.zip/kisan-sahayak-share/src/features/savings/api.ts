import AsyncStorage from '@react-native-async-storage/async-storage';

import { demoSavingsInputs } from '@/features/demo/store';
import { isDemoMode } from '@/lib/demo-mode';
import { supabase } from '@/lib/supabase';
import type { Diagnosis } from '@/types/diagnosis';

import type { SavingsInput } from './compute';

/** The farmer's own crop checks with their follow-up answers (RLS: own rows only). */
export async function fetchSavingsInput(): Promise<SavingsInput[] | null> {
  if (isDemoMode()) return demoSavingsInputs();
  const { data, error } = await supabase
    .from('diagnoses')
    .select('diagnosis_json, follow_ups(status, farmer_response, treatment_applied)')
    .eq('type', 'crop');
  if (error) return null;
  return (data ?? []).map((r) => {
    const d = r.diagnosis_json as Diagnosis;
    const fu = r.follow_ups.find((f) => f.status === 'responded');
    return {
      spray_decision: d.spray_decision,
      confidence: d.confidence,
      response: (fu?.farmer_response as SavingsInput['response']) ?? null,
      applied: fu?.treatment_applied ?? null,
    };
  });
}

// The farmer's own estimate, so the money figure is theirs, not ours. Kept on the phone.
const costKey = (farmerId: string) => `ks.sprayCost.${farmerId}`;

export async function loadSprayCost(farmerId: string): Promise<number | null> {
  const raw = await AsyncStorage.getItem(costKey(farmerId));
  return raw ? Number(raw) : null;
}

export async function saveSprayCost(farmerId: string, cost: number | null): Promise<void> {
  if (cost && cost > 0) await AsyncStorage.setItem(costKey(farmerId), String(Math.round(cost)));
  else await AsyncStorage.removeItem(costKey(farmerId));
}
