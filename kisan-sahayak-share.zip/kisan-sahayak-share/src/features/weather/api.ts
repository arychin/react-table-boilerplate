import { FunctionsHttpError } from '@supabase/supabase-js';

import { DEMO_WEATHER } from '@/features/demo/data';
import type { Coords } from '@/hooks/use-device-location';
import { demoDelay, isDemoMode } from '@/lib/demo-mode';
import { supabase } from '@/lib/supabase';

export type Weather = {
  place: string | null;
  condition: string; // OpenWeatherMap "main" group: Clear, Clouds, Rain, Drizzle, Thunderstorm, Mist, Haze, …
  temp_c: number;
  temp_max_c: number; // highest over the next 12 h
  humidity: number;
  wind_kmh: number;
  rain_chance: number; // % over the next 12 h
  observed_at: string;
};

const FRESH_MS = 15 * 60_000;
let last: { key: string; at: number; weather: Weather } | null = null;

export async function fetchWeather(coords: Coords): Promise<{ weather: Weather | null; offline: boolean }> {
  if (isDemoMode()) {
    await demoDelay(400);
    return { weather: { ...DEMO_WEATHER, observed_at: new Date().toISOString() }, offline: false };
  }
  const key = `${coords.latitude.toFixed(2)},${coords.longitude.toFixed(2)}`;
  if (last && last.key === key && Date.now() - last.at < FRESH_MS) return { weather: last.weather, offline: false };
  const { data, error } = await supabase.functions.invoke<Weather>('weather', {
    body: { lat: coords.latitude, lng: coords.longitude },
  });
  if (error || !data) return { weather: null, offline: !(error instanceof FunctionsHttpError) };
  last = { key, at: Date.now(), weather: data };
  return { weather: data, offline: false };
}
