# Kisan Sahayak — setup on a personal laptop

This folder is a copy of the project **without** `node_modules`, `.env` and caches.
No secret keys are inside. Follow the steps in order.

---

## 1. Install once

| Tool | How | Check |
|---|---|---|
| Node.js 20 LTS or newer | https://nodejs.org | `node -v` |
| Python 3 (only for data scripts) | usually already on Mac | `python3 --version` |
| Android phone + USB cable (optional) | — | — |

Nothing else needs a global install — Expo, EAS and Supabase CLIs run through `npx`.

## 2. Install project packages

```bash
cd kisan-sahayak-share
npm install
```

This rebuilds `node_modules` (~660 MB) from `package-lock.json`.

## 3. Create `.env` (2 values only)

```bash
cp .env.example .env
```

Open `.env` and fill:

```
EXPO_PUBLIC_SUPABASE_URL=https://vbexwxzfmjjollhwpaop.supabase.co
EXPO_PUBLIC_SUPABASE_ANON_KEY=<copy "anon public" key from the credentials PDF>
```

Rules:
- Only these two `EXPO_PUBLIC_*` values go in `.env`. They end up inside the app anyway.
- **Never** put the service-role key, DB password, Gemini / Sarvam / OpenWeather keys in
  `.env` or in `src/`. Those live only as Supabase Edge Function secrets (already set on the server).
- `scripts/load_secrets.py` reads the credentials PDF from `~/Downloads/...` on the work
  laptop. On this laptop just fill `.env` by hand as above.

## 4. Run the app

### a) In the browser (fastest check)
```bash
npx expo start --web
```

### b) On an Android phone (live reload)
The app uses `expo-dev-client`, so **Expo Go will not work**. Build a development app once:

```bash
npx eas-cli login                       # account: kisan-sahayak-agritech
npx eas-cli build -p android --profile development
```
Install the APK from the link EAS prints, then:
```bash
npx expo start --dev-client
```
Phone and laptop on the same Wi-Fi → open the dev app → pick the server shown.

### c) Stand-alone APK (no laptop needed, for demos / testers)
```bash
npx eas-cli build -p android --profile preview
```
Takes ~20 min in the cloud. EAS prints a download link (valid ~14 days).
The signing key is stored on Expo's servers, so it matches earlier builds.

## 5. Test login

| Farmer | Phone | OTP |
|---|---|---|
| A | +91 9000000001 | 246810 |
| B | +91 9000000002 | 135790 |

No real SMS is sent — these are Supabase test numbers.

**Demo Mode:** tap the small "डेमो" pill at the top of Home (or on sign-in).
Everything then runs with built-in data and **no internet**. Use this as the fail-safe
during the pitch. Before Play Store: set `SHOW_DEMO_TOGGLE = false` in
`src/features/demo/demo-toggle.tsx`.

## 6. Checks before calling anything "done"

```bash
npx tsc --noEmit     # type check — must be 0 errors
npm run lint         # must be 0 problems
npx --yes tsx --env-file=.env --tsconfig tsconfig.json scripts/check_calculator.mts   # 37 checks
npx --yes tsx --env-file=.env --tsconfig tsconfig.json scripts/check_crop_feed.mts    # 49 checks
```

`npm test` is not configured. Other `scripts/check_*.mjs` hit the live backend and need
the service-role key in the shell (see step 7) — do not write it to a file.

## 7. Backend (Supabase) — only if you change server code

Project ref: `vbexwxzfmjjollhwpaop` (region ap-northeast-1). Already deployed and working;
you do **not** need this to run the app.

```bash
npx --yes supabase@2.119.0 login
npx --yes supabase@2.119.0 link --project-ref vbexwxzfmjjollhwpaop    # asks DB password
```

| Task | Command |
|---|---|
| Deploy one Edge Function | `npx --yes supabase@2.119.0 functions deploy <name> --use-api` |
| Type-check a function | `cd supabase/functions && npx --yes deno@latest check <name>/index.ts` |
| New DB migration — dry run | `npx --yes supabase@2.119.0 db push --linked --dry-run` |
| Apply migration | `npx --yes supabase@2.119.0 db push --linked` |
| Set a server secret | `npx --yes supabase@2.119.0 secrets set NAME=value` |

Edge Functions: `diagnose-crop`, `bolo`, `weather`, `read-soil-card`, `chat`,
`follow-up-answer`, `read-pesticide-label` (all `verify_jwt = true` in `supabase/config.toml`).

If a secret must be in the shell for a script, type it with `export NAME=...` in that terminal
only, and `unset NAME` when done.

**Free plan pauses after ~7 idle days.** A pg_cron keep-alive job pings every 12 h
(migration `20261016020000_keep_alive.sql`). If the app shows a blank page / network error,
check the project status first:
```bash
npx --yes supabase@2.119.0 projects list
```

## 8. Differences from the work laptop

These lines in `CLAUDE.md` are **work-laptop only** — skip them here:
- `SSL_CERT_FILE` / `NODE_EXTRA_CA_CERTS` (corporate proxy certificates)
- `EAS_NO_VCS=1 EAS_PROJECT_ROOT=...` (work home folder is a git repo)
- "Gemini and Sarvam are blocked" — they are not blocked on a personal network.
- `eval "$(python3 scripts/load_secrets.py)"` — needs the credentials PDF in Downloads.

## 9. If you put it on GitHub

- Make the repo **Private** (docs, test numbers and project ref are inside).
- Use `git` on the command line, not the web uploader (the web uploader ignores `.gitignore`).
- Before the first commit: `git status` — `.env` and `node_modules/` must **not** be listed.
- If you add a git repo here, EAS will use it automatically (no `EAS_NO_VCS` needed),
  but it only builds **committed** files.

## 10. Where to read more

- `README.md` — overview and spec links
- `CLAUDE.md` — coding rules (no `any`, no keys in `src/`, demo-mode check first, etc.)
- `project_memory/CURRENT_STATE.md`, `TASK_TRACKER.md`, `DECISIONS.md` — what is done and why
- `decisions.md`, `flow.md` — plain-English history
