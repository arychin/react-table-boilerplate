# Kisan Sahayak — Working Instructions for Claude Code

*Read this file, CLAUDE.md, decisions.md, and flow.md at the start of every session — before touching any code.*

## 1. The three planning documents

Three documents together define this entire project. Nothing about what to build, why, or in what order should be decided outside of them.

| File | Role | What it answers |
|---|---|---|
| `Kisan_Sahayak_Vision_Brief_v4_FINAL` | **PRD** | What we're building, who it's for, and why. Sections 1–2 cover the farmer and the core Decision Loop (2.1), plus what the product will and will not promise (2.2). Section 3 specifies every feature (3.1–3.17 — the original 10 plus 7 newly added: Should-I-Spray, Validated Intervention Guidance, Treatment Verification, Farm Memory, Soil Health Card Scanner, Input Doctor, and the Cooperative/Impact Dashboards). Section 11 covers investor/government positioning, including verified funding-scheme figures (11.4). Section 12 covers the long-term roadmap. |
| `Kisan_Sahayak_TRD_v1` | **TRD** | The exact technical specification. Section 2 is the locked stack; Section 2A names the Expert Console and Cooperative/FPO Console as formal system components. Section 5 is the database schema, including the case_status lifecycle and the audit_events table. Section 6 is the exact API contracts, plus the Golden Rule for agrochemical data (6.7) and the Confidence & Escalation Framework (6.8). Section 8 is non-negotiable security rules, including data retention. Section 10 covers Claude Code conventions, decisions.md/flow.md, and incremental-change discipline (10A). Section 11 lists explicit anti-patterns — treat these as hard rules, not suggestions. |
| `Kisan_Sahayak_Implementation_Plan_v1` | **Build sequence** | The phased order to build in: Phase 0 through Phase 12. Section 2A cross-references the Vision Brief's feature priority tiers (P0–P3) against these phases. Each phase states its Goal, what it Depends On, its Build Steps, its Definition of Done, and a Watch Out box. Phase 12 is the staged farmer rollout (25 → 100 → 500 → 1,000), which continues after the app is technically built. |

Put all three in a `/docs` folder in the repository — not just pasted into one chat — so they're read fresh every session, not relied on from memory of an earlier conversation.

## 2. Follow the phase order exactly — do not reorder or skip

The Implementation Plan's phases exist in this order for a specific reason: Phase 2 (the core diagnosis loop) is deliberately built as a thin, working, end-to-end slice before anything else, so that the riskiest part of the whole system — photo in, Gemini out — is proven early, not assumed to work after four other features are already built around it.

| Phase | Name | Depends on |
|---|---|---|
| 0 | Environment & Project Setup | — |
| 1 | Data Layer & Identity | Phase 0 |
| 2 | Core Diagnosis Loop (walking skeleton) | Phases 0–1 |
| 3 | Hindi Voice — the Bolo Button | Phase 2 |
| 4 | Offline Shop Finder | Phase 0 (independent of 2–3) |
| 5 | Soil Analysis + Weather | Phase 2 (reuses its pipeline), Phase 4 |
| 6 | Agri Expert Chatbot | Phase 0 |
| 7 | WhatsApp Voice-First Loop | Phases 2 and 3 |
| 8 | Advisory Follow-Up Loop | Phase 7, Phase 1 |
| 9 | Demo Mode | Phases 2–8 |
| 10 | Polish, Security & Performance Pass | Phases 2–9 |
| 11 | Build & Release Readiness | Phase 10 |
| 12 | Staged Farmer Rollout & Validation | Phase 11 — ongoing, not a single build task |

Do not start a phase before the phases it depends on have actually met their Definition of Done — not "mostly working," met. Where a P0/P1 feature added to Section 3 of the Vision Brief isn't yet named as its own phase (e.g. Should-I-Spray, Farm Memory), it's built as an extension of the phase that already owns its underlying pipeline — see Implementation Plan Section 2A for the exact mapping.

## 3. One phase, one Claude Code session

Each phase above should be its own session — not one long continuous session spanning multiple phases. At the start of each session:

1. State which phase this session is for.
2. Re-read that phase's Goal, Depends On, Build Steps, and Definition of Done directly from the Implementation Plan.
3. Confirm the phase(s) it depends on are genuinely done first.
4. Read `decisions.md` and `flow.md` for context on what was decided and how execution currently flows — don't rely on memory of an earlier session.

Starting fresh per phase is deliberate — long sessions are where small misreadings of the spec compound into bigger problems several phases later.

## 4. Always use Plan Mode — and the plan gets reviewed, not auto-approved

Before editing files for a new phase, or a significant step within one, propose the plan first: which files will be touched, and the approach (TRD Section 10A spells this out in full — how the existing code works, exactly which files change and why, assumptions/risks/edge cases, and a comparison of approaches if more than one exists). Wait for explicit approval before writing code.

**The human reviewing this project should check the proposed plan against the TRD and Implementation Plan before approving it — approval should not be automatic.** If a plan doesn't match what those documents specify (a wrong field name, a skipped security rule, a reordered phase), say so and ask for a revised plan rather than proceeding.

## 5. Incremental-change discipline — do not let this app get stuck at Version 1

This is a common, well-documented failure mode for AI-coding-agent projects: a small feature request causes 20 files to change, something unrelated breaks, the fix touches more files, and the app never makes it past its first version. TRD Section 10A covers this in full; the short version:

- Never refactor, rename, move, or restructure code unrelated to the current task.
- Reuse existing components, utilities, and patterns before writing a new one.
- Do not add a new library or dependency unless there is a compelling reason the current stack can't do the job.
- If an unrelated architectural problem is discovered mid-task, report it and recommend a separate fix — do not silently fix it while also doing the requested feature.
- Implement in small, independently testable steps, each explained before moving to the next.

## 6. decisions.md and flow.md — update before ending a session, not "when convenient"

Two files at the project root, alongside CLAUDE.md:

- **`decisions.md`** — a running, plain-language log of meaningful decisions made while changing code, and why (e.g. "used X instead of Y because..."). This is also where the closing summary of a change belongs: files modified, what was manually tested, and what was deliberately deferred.
- **`flow.md`** — documents how execution actually travels through the codebase: the entry point, the overall execution path, which function calls which, and what the most recent session changed in that flow.

**Both must be updated before a session ends, not left for later.** They exist so a non-technical founder — or a future second developer — can understand what was built and why without reading every file, and so the next Claude Code session has real continuity instead of starting cold.

## 7. Closing out a phase

Before moving to the next phase:

- Run the type-check and lint commands (see CLAUDE.md for exact commands).
- Walk through that phase's Definition of Done from the Implementation Plan, item by item, and verify each one is actually true — not assumed true.
- Check that phase's Watch Out box specifically — most of these map directly to a named bug from the original build (TRD Section 11) or a non-negotiable rule from TRD Section 8. Confirm the specific thing it warns about was not reintroduced.
- Update `decisions.md` and `flow.md` (Section 6 above).
- Commit the work, with a message referencing the phase (e.g. `Phase 2: core diagnosis loop working end-to-end`).
- Push to GitHub.

## 8. Non-negotiables that apply in every phase, not just one

These come from TRD Sections 6.5, 6.7, 6.8, 8, and 11, and are easy to accidentally violate while focused on a single phase's feature work. Check these regardless of which phase is active:

- No Gemini, Sarvam, WhatsApp, or weather API key ever appears in client-side code (`src/`) — all such calls happen only inside Supabase Edge Functions.
- Row Level Security is enabled on a table before that table is used by the app, not added later (TRD Section 5.7).
- The single shared `src/lib/haversine.ts` is the only distance-calculation implementation in the codebase — never a second copy.
- `isDemoMode` is checked at the very top of any function that makes a network or AI call, before the request is sent.
- Image MIME type is always auto-detected from the file — never hardcoded.
- The Hindi voice summary is always a separate, non-blocking call from the main diagnosis result.
- **The Golden Rule (TRD 6.7): the AI never invents a dose, compatibility claim, registration status, or safety instruction — these always come from the curated, source-and-date-tagged data store.**
- **The Confidence & Escalation Framework (TRD 6.8) is applied before any diagnosis reaches DECISION MADE status — a Low, Out-of-scope, or Severe case is never presented as a confident result.**
- **The conflict-of-interest firewall (TRD 6.5): the shop finder's ranking never influences, and is never influenced by, the diagnosis/recommendation logic.**

## 9. When something isn't covered

If a situation comes up that the PRD, TRD, or Implementation Plan doesn't address, stop and flag it rather than guessing or filling the gap with a reasonable-sounding assumption — especially anything touching security, API keys, agrochemical guidance, or farmer data. Don't make it up.
