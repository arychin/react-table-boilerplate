// Reset ONLY the two test farmers (+91 9000000001/2): their diagnoses (follow_ups cascade), engagement
// events, stored images, chat, and profile fields. Needs the service-role key in the shell env:
//   eval "$(python3 scripts/load_secrets.py --with-service-role)" && node --env-file=.env scripts/reset_test_farmers.mjs
import { createClient } from '@supabase/supabase-js';

const TEST_PHONES = ['+919000000001', '+919000000002'];
const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
if (!key) {
  console.error('SUPABASE_SERVICE_ROLE_KEY not set — see the usage line at the top of this file.');
  process.exit(1);
}
const admin = createClient(process.env.EXPO_PUBLIC_SUPABASE_URL, key, { auth: { persistSession: false } });

const { data: farmers } = await admin.from('farmers').select('id').in('phone_number', TEST_PHONES);
const ids = (farmers ?? []).map((f) => f.id);
let images = 0;
for (const id of ids) {
  for (const bucket of ['diagnosis-images', 'bolo-audio']) {
    const { data: files } = await admin.storage.from(bucket).list(id, { limit: 1000 });
    if (files?.length) {
      await admin.storage.from(bucket).remove(files.map((f) => `${id}/${f.name}`));
      images += files.length;
    }
  }
}
// engagement_events.diagnosis_id is ON DELETE SET NULL, so delete test events explicitly.
const events = await admin.from('engagement_events').delete({ count: 'exact' }).in('farmer_id', ids);
const diagnoses = await admin.from('diagnoses').delete({ count: 'exact' }).in('farmer_id', ids);
await admin.from('chat_messages').delete().in('farmer_id', ids);
await admin.from('farmers').update({ name: null, district: null, preferred_language: 'hi' }).in('id', ids);
console.log(`reset ${ids.length} test farmers: ${diagnoses.count} diagnoses, ${events.count} events, ${images} stored files (images + audio)`);
