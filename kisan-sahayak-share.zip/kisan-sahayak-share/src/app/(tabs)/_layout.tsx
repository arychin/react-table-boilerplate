import { Link, Tabs } from 'expo-router';
import { Pressable, StyleSheet, Text } from 'react-native';

import { MinTouchTarget, Spacing } from '@/constants/theme';
import { useApp } from '@/features/auth/app-context';
import { useTheme } from '@/hooks/use-theme';

function AccountButton() {
  const { t } = useApp();
  const theme = useTheme();
  return (
    <Link href="/settings/account" asChild>
      <Pressable accessibilityRole="button" style={styles.account}>
        <Text style={[styles.accountText, { color: theme.primary }]}>{t.account}</Text>
      </Pressable>
    </Link>
  );
}

export default function TabLayout() {
  const { t } = useApp();
  const theme = useTheme();
  return (
    <Tabs
      screenOptions={{
        headerRight: () => <AccountButton />,
        tabBarActiveTintColor: theme.primary,
        tabBarLabelStyle: styles.tabLabel,
      }}>
      <Tabs.Screen name="index" options={{ title: t.tabHome }} />
      <Tabs.Screen name="shops" options={{ title: t.tabShops }} />
      <Tabs.Screen name="chat" options={{ title: t.tabChat }} />
      <Tabs.Screen name="history" options={{ title: t.tabHistory }} />
    </Tabs>
  );
}

const styles = StyleSheet.create({
  account: { minHeight: MinTouchTarget - 12, justifyContent: 'center', paddingHorizontal: Spacing.three },
  accountText: { fontSize: 16, fontWeight: '700' },
  tabLabel: { fontSize: 13, fontWeight: '600' },
});
