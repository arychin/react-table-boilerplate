import { FunctionsHttpError } from '@supabase/supabase-js';
import { ImageManipulator, SaveFormat } from 'expo-image-manipulator';

import type { Language, Strings } from '@/constants/strings';
import { demoAddDiagnosis, demoFindRow, demoImage, demoListRows } from '@/features/demo/store';
import { demoDelay, isDemoMode } from '@/lib/demo-mode';
import { supabase } from '@/lib/supabase';
import type { Diagnosis, Kind, SoilReport } from '@/types/diagnosis';

const BUCKET = 'diagnosis-images';
const MAX_EDGE = 1280; // measured: 2.5 MB PNG → ~0.4 MB JPEG before sending (D-21)

export type PickedImage = { uri: string; width: number; height: number; mimeType?: string | null };
export type PreparedImage = { bytes: Uint8Array; contentType: string; previewUri: string };
type RowBase = { id: string; created_at: string; image_url: string };
export type DiagnosisRow = (RowBase & { kind: 'crop'; diagnosis: Diagnosis }) | (RowBase & { kind: 'soil'; diagnosis: SoilReport });
type ErrorKey = keyof Pick<Strings, 'errAiBusy' | 'errBadImage' | 'errTooMany' | 'errNetwork' | 'errDiagnose'>;

// Results just produced on this device, so the result screen opens without another round trip.
const recent = new Map<string, DiagnosisRow & { localUri?: string }>();

export async function prepareImage(image: PickedImage): Promise<PreparedImage | null> {
  try {
    const context = ImageManipulator.manipulate(image.uri);
    if (Math.max(image.width, image.height) > MAX_EDGE) {
      context.resize(image.width >= image.height ? { width: MAX_EDGE } : { height: MAX_EDGE });
    }
    const rendered = await context.renderAsync();
    const saved = await rendered.saveAsync({ format: SaveFormat.JPEG, compress: 0.7, base64: true });
    if (saved.base64) return { bytes: base64ToBytes(saved.base64), contentType: 'image/jpeg', previewUri: saved.uri };
  } catch {
    // Fall through: send the original file; the server sniffs its real type from the bytes.
  }
  const original = await fetch(image.uri).then((r) => r.blob());
  const bytes = base64ToBytes(await blobToBase64(original));
  return { bytes, contentType: original.type || image.mimeType || 'application/octet-stream', previewUri: image.uri };
}

// One request: diagnose-crop stores the photo in the private bucket while Gemini runs (D-22). Soil uses the same function.
export async function diagnosePhoto(image: PreparedImage, language: Language, kind: Kind): Promise<{ id: string | null; errorKey: ErrorKey | null }> {
  if (isDemoMode()) {
    await demoDelay(2500);
    return { id: demoAddDiagnosis(kind, image.previewUri), errorKey: null };
  }
  const body = image.bytes.buffer.slice(image.bytes.byteOffset, image.bytes.byteOffset + image.bytes.byteLength) as ArrayBuffer;
  const send = () => supabase.functions.invoke<{ id: string; image_path: string; diagnosis: Diagnosis & SoilReport }>('diagnose-crop', {
    body,
    headers: { 'Content-Type': image.contentType, 'x-ks-language': language, 'x-ks-kind': kind },
  });
  const statusOf = (e: unknown) => (e instanceof FunctionsHttpError ? (e.context as Response).status : 0);
  let { data, error } = await send();
  // Rare upstream AI stalls are instance-specific; a fresh request almost always succeeds (D-28).
  if (error && statusOf(error) === 503) ({ data, error } = await send());
  if (error || !data) {
    const status = statusOf(error);
    const errorKey: ErrorKey =
      status === 503 ? 'errAiBusy'
      : status === 415 || status === 413 ? 'errBadImage'
      : status === 429 ? 'errTooMany'
      : status === 0 ? 'errNetwork'
      : 'errDiagnose';
    return { id: null, errorKey };
  }
  recent.set(data.id, {
    id: data.id,
    created_at: new Date().toISOString(),
    image_url: data.image_path,
    kind,
    diagnosis: data.diagnosis,
    localUri: image.previewUri,
  });
  return { id: data.id, errorKey: null };
}

type DbRow = { id: string; created_at: string; image_url: string; type: string; diagnosis_json: unknown };
const toRow = (r: DbRow) => ({
  id: r.id,
  created_at: r.created_at,
  image_url: r.image_url,
  kind: r.type,
  diagnosis: r.diagnosis_json,
}) as DiagnosisRow; // the type column ('crop' | 'soil', DB check) decides the JSON shape

export async function fetchDiagnosis(id: string): Promise<(DiagnosisRow & { localUri?: string }) | null> {
  if (isDemoMode()) return demoFindRow(id);
  const cached = recent.get(id);
  if (cached) return cached;
  const { data } = await supabase.from('diagnoses').select('id, created_at, image_url, type, diagnosis_json').eq('id', id).maybeSingle();
  return data ? toRow(data) : null;
}

export async function listDiagnoses(): Promise<DiagnosisRow[]> {
  if (isDemoMode()) return demoListRows();
  const { data } = await supabase
    .from('diagnoses')
    .select('id, created_at, image_url, type, diagnosis_json')
    .order('created_at', { ascending: false })
    .limit(50);
  return (data ?? []).map(toRow);
}

// TRD §8: images are private; show them only through short-lived signed URLs.
/** A short-lived signed URL, or in Demo Mode the bundled photo (a module id, which expo-image also accepts). */
export async function signedImageUrl(path: string): Promise<string | number | null> {
  if (isDemoMode()) return demoImage(path);
  const { data } = await supabase.storage.from(BUCKET).createSignedUrl(path, 600);
  return data?.signedUrl ?? null;
}

function base64ToBytes(base64: string): Uint8Array {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

function blobToBase64(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result).split(',')[1] ?? '');
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(blob);
  });
}
