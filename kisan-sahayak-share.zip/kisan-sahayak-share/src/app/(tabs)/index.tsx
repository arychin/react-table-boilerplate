import { router } from 'expo-router';
import { useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';

import { Button } from '@/components/ui/button';
import { MinTouchTarget, Spacing } from '@/constants/theme';
import { useApp } from '@/features/auth/app-context';
import { TodayCard } from '@/features/crop-feed/today-card';
import { DemoToggle } from '@/features/demo/demo-toggle';
import { PhotoTips } from '@/features/diagnosis/photo-tips';
import { pickAndDiagnose } from '@/features/diagnosis/pick-image';
import { CheckInCard } from '@/features/follow-up/check-in-card';
import { WeatherCard } from '@/features/weather/weather-card';
import { useTheme } from '@/hooks/use-theme';

// Vision Brief §2: no more than 3 taps from open to result — camera is on the home screen.
export default function HomeScreen() {
  const { t } = useApp();
  const theme = useTheme();
  const [error, setError] = useState<string | null>(null);
  const denied = () => setError(t.cameraDenied);

  return (
    <ScrollView style={{ backgroundColor: theme.background }} contentContainerStyle={styles.content}>
      <View style={styles.topRow}>
        <Text style={[styles.greeting, { color: theme.text }]}>{t.homeGreeting}</Text>
        <DemoToggle />
      </View>

      <CheckInCard />

      <WeatherCard />

      <View style={[styles.card, { backgroundColor: theme.backgroundElement, borderColor: theme.primary }]}>
        <Text style={[styles.cardTitle, { color: theme.text }]}>📸 {t.cropProblem}</Text>
        <Text style={[styles.cardHint, { color: theme.textSecondary }]}>{t.cropProblemHint}</Text>
        {error && <Text style={[styles.error, { color: theme.danger }]}>{error}</Text>}
        <Button label={t.takePhoto} onPress={() => pickAndDiagnose('camera', denied)} />
        <Button variant="secondary" label={t.pickPhoto} onPress={() => pickAndDiagnose('gallery', denied)} />
      </View>

      <PhotoTips />

      <TodayCard />

      <View style={[styles.card, { backgroundColor: theme.backgroundElement, borderColor: theme.border }]}>
        <Text style={[styles.cardTitle, { color: theme.text }]}>🧪 {t.soilCheck}</Text>
        <Text style={[styles.cardHint, { color: theme.textSecondary }]}>{t.soilCheckHint}</Text>
        <Button label={t.takePhoto} onPress={() => pickAndDiagnose('camera', denied, 'soil')} />
        <Button variant="secondary" label={t.pickPhoto} onPress={() => pickAndDiagnose('gallery', denied, 'soil')} />
        <Pressable
          accessibilityRole="button"
          onPress={() => router.push('/soil-card')}
          style={({ pressed }) => [styles.cardLink, { backgroundColor: theme.successBg }, pressed && styles.pressed]}>
          <Text style={[styles.cardLinkText, { color: theme.primary }]}>🪪 {t.soilCardButton}</Text>
        </Pressable>
      </View>

      <View style={[styles.card, { backgroundColor: theme.backgroundElement, borderColor: theme.border }]}>
        <Text style={[styles.cardTitle, { color: theme.text }]}>🧮 {t.calcTitle}</Text>
        <Text style={[styles.cardHint, { color: theme.textSecondary }]}>{t.calcHint}</Text>
        <Button label={t.calcSprayButton} variant="secondary" onPress={() => router.push('/spray-calculator')} />
        <Button label={t.calcFertButton} variant="secondary" onPress={() => router.push('/fertilizer-calculator')} />
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  content: { padding: Spacing.four, gap: Spacing.four },
  greeting: { flex: 1, fontSize: 22, fontWeight: '700' },
  topRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.two },
  card: { borderRadius: Spacing.four, borderWidth: 2, padding: Spacing.four, gap: Spacing.three },
  cardTitle: { fontSize: 24, fontWeight: '800' },
  cardHint: { fontSize: 16 },
  error: { fontSize: 16, fontWeight: '600' },
  cardLink: { alignSelf: 'flex-start', minHeight: MinTouchTarget, justifyContent: 'center', borderRadius: Spacing.five, paddingHorizontal: Spacing.three },
  cardLinkText: { fontSize: 16, fontWeight: '700' },
  pressed: { opacity: 0.6 },
});
