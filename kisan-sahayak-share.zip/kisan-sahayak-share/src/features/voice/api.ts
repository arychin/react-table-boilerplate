import { FunctionsHttpError } from '@supabase/supabase-js';

import { demoBolo } from '@/features/demo/store';
import { demoDelay, isDemoMode } from '@/lib/demo-mode';
import { supabase } from '@/lib/supabase';

/** source: a signed URL, or in Demo Mode the bundled MP3 (module id). */
export type BoloAudio = { source: string | number; summary: string | null; fetchedAt: number };

// Cached Hindi audio for a diagnosis; the server generates it only once (TRD §6.2).
export async function fetchBolo(diagnosisId: string): Promise<BoloAudio | null> {
  if (isDemoMode()) {
    await demoDelay(300);
    const demo = demoBolo(diagnosisId);
    return demo ? { ...demo, fetchedAt: Date.now() } : null;
  }
  const { data, error } = await supabase.functions.invoke<{ url: string; summary: string | null }>('bolo', {
    body: { diagnosis_id: diagnosisId },
  });
  if (error || !data?.url) {
    if (error instanceof FunctionsHttpError) console.warn(`bolo failed: ${(error.context as Response).status}`);
    return null;
  }
  return { source: data.url, summary: data.summary, fetchedAt: Date.now() };
}
