// Daily Action Feed (Vision Brief §7 future vision, D-39 item 3, D-42). Official sources only:
// - Stage timing (paddy): IRRI Rice Knowledge Bank — reproductive phase ≈ 35 days, ripening ≈ 30 days,
//   only the vegetative phase changes with variety; short 100–120, medium 120–140, long 160+ days.
// - What to check and when to act: NIPHM AESA-based IPM packages for Rice and Chickpea (Ministry of Agriculture),
//   "plant protection measures only when pests cross the Economic Threshold Level (ETL)". Scouting from 20 days
//   after sowing/transplanting; paddy once in 3–5 days, chickpea once in 7–10 days; 5 spots, 20 plants/hills.

export type FeedCrop = 'rice' | 'chana';
export type RiceDuration = 110 | 130 | 160;
export type ChanaStage = 'chana_seedling' | 'chana_veg' | 'chana_pod';
export type StageId = 'rice_veg' | 'rice_repro' | 'rice_ripen' | 'rice_harvest' | ChanaStage;

export type CropPlan = {
  crop: FeedCrop;
  sownOn: string; // YYYY-MM-DD
  duration: RiceDuration;
  chanaStage: ChanaStage;
  lastScouted: string | null; // YYYY-MM-DD
};

export const RICE_DURATIONS: RiceDuration[] = [110, 130, 160];
export const CHANA_STAGES: ChanaStage[] = ['chana_seedling', 'chana_veg', 'chana_pod'];
export const SCOUT_START_DAY = 20;
export const SCOUT_EVERY: Record<FeedCrop, number> = { rice: 3, chana: 7 };

const day = (iso: string) => Date.UTC(+iso.slice(0, 4), +iso.slice(5, 7) - 1, +iso.slice(8, 10)) / 86_400_000;
export const daysBetween = (from: string, to: string) => Math.round(day(to) - day(from));

/** IRRI: harvest − 65 days ≈ panicle initiation, harvest − 30 days ≈ flowering. */
export function riceStage(dayNo: number, duration: RiceDuration): StageId {
  if (dayNo >= duration) return 'rice_harvest';
  if (dayNo >= duration - 30) return 'rice_ripen';
  if (dayNo >= duration - 65) return 'rice_repro';
  return 'rice_veg';
}

export type Today = {
  dayNo: number;
  stage: StageId;
  scouting: 'too_early' | 'due' | 'done' | 'not_needed';
  nextScoutIn: number; // days until scouting is due (0 when due)
  harvestIn: number | null; // paddy only
};

export function todayFor(plan: CropPlan, today: string): Today | null {
  const dayNo = daysBetween(plan.sownOn, today);
  if (dayNo < 0) return null;
  const stage = plan.crop === 'rice' ? riceStage(dayNo, plan.duration) : plan.chanaStage;
  const harvestIn = plan.crop === 'rice' ? Math.max(0, plan.duration - dayNo) : null;
  if (stage === 'rice_harvest') return { dayNo, stage, scouting: 'not_needed', nextScoutIn: 0, harvestIn };
  if (dayNo < SCOUT_START_DAY) return { dayNo, stage, scouting: 'too_early', nextScoutIn: SCOUT_START_DAY - dayNo, harvestIn };
  const since = plan.lastScouted ? daysBetween(plan.lastScouted, today) : Infinity;
  const every = SCOUT_EVERY[plan.crop];
  return since >= every
    ? { dayNo, stage, scouting: 'due', nextScoutIn: 0, harvestIn }
    : { dayNo, stage, scouting: 'done', nextScoutIn: every - since, harvestIn };
}

type Text = { hi: string; en: string };
export type Check = { name: Text; act: Text };

// NIPHM ETL tables, only the ones a farmer can count in the field (nematode/soil counts left out).
export const CHECKS: Record<StageId, Check[]> = {
  rice_veg: [
    { name: { hi: 'तना छेदक', en: 'Stem borer' }, act: { hi: '10% पौधों में सूखी गोभ (डेड हार्ट), या 2 अंड-समूह प्रति वर्ग मीटर', en: '10% dead hearts, or 2 egg masses per m²' } },
    { name: { hi: 'पत्ती लपेटक', en: 'Leaf folder' }, act: { hi: 'हर पौधे (झुंड) पर 2 पूरी तरह खराब पत्तियाँ, इल्ली के साथ', en: '2 fully damaged leaves with larva per hill' } },
    { name: { hi: 'भूरा / सफ़ेद पीठ वाला माहू', en: 'Brown / white-backed planthopper' }, act: { hi: 'हर पौधे (झुंड) पर 10–15 माहू', en: '10–15 hoppers per hill' } },
    { name: { hi: 'गंगई (गॉल मिज)', en: 'Gall midge' }, act: { hi: '10% पौधों में पोंगा (सफ़ेद नली)', en: '10% silver shoots' } },
    { name: { hi: 'हिस्पा', en: 'Rice hispa' }, act: { hi: 'हर पौधे (झुंड) पर 2 कीट या 2 खराब पत्तियाँ', en: '2 adults or 2 damaged leaves per hill' } },
    { name: { hi: 'झुलसा (ब्लास्ट)', en: 'Leaf blast' }, act: { hi: 'एक पत्ती पर 3–5 धब्बे', en: '3–5 lesions per leaf' } },
    { name: { hi: 'भूरा धब्बा', en: 'Brown spot' }, act: { hi: 'एक पत्ती पर 2–3 धब्बे, और हर वर्ग मीटर में 2–3 रोगी पौधे', en: '2–3 spots per leaf and 2–3 infected plants per m²' } },
    { name: { hi: 'शीथ ब्लाइट', en: 'Sheath blight' }, act: { hi: '5–6 मिमी के धब्बे, और हर वर्ग मीटर में 2–3 रोगी पौधे', en: '5–6 mm lesions and 2–3 infected plants per m²' } },
    { name: { hi: 'जीवाणु झुलसा (BLB)', en: 'Bacterial leaf blight' }, act: { hi: 'हर वर्ग मीटर में 2–3 रोगी पत्तियाँ', en: '2–3 infected leaves per m²' } },
  ],
  rice_repro: [
    { name: { hi: 'तना छेदक', en: 'Stem borer' }, act: { hi: '2 अंड-समूह या 1 पतंगा प्रति वर्ग मीटर', en: '2 egg masses or 1 moth per m²' } },
    { name: { hi: 'पत्ती लपेटक', en: 'Leaf folder' }, act: { hi: 'हर पौधे (झुंड) पर 2 पूरी तरह खराब पत्तियाँ', en: '2 fully damaged leaves per hill' } },
    { name: { hi: 'भूरा / सफ़ेद पीठ वाला माहू', en: 'Brown / white-backed planthopper' }, act: { hi: 'हर पौधे (झुंड) पर 15–20 माहू', en: '15–20 hoppers per hill' } },
    { name: { hi: 'गर्दन झुलसा (नेक ब्लास्ट)', en: 'Neck blast' }, act: { hi: 'हर वर्ग मीटर में 2–5 पौधों की बाली की गर्दन काली', en: '2–5 plants with infected necks per m²' } },
    { name: { hi: 'शीथ रॉट', en: 'Sheath rot' }, act: { hi: 'हर वर्ग मीटर में 5 रोगी पौधे', en: '5 infected plants per m²' } },
  ],
  rice_ripen: [{ name: { hi: 'गंधी बग', en: 'Gundhi (rice earhead) bug' }, act: { hi: 'हर पौधे (झुंड) पर 2 कीट (फूल से दूध भरने तक)', en: '2 bugs per hill (flowering to milky grain)' } }],
  rice_harvest: [],
  chana_seedling: [
    { name: { hi: 'कटुआ इल्ली', en: 'Cutworm' }, act: { hi: 'कटे पौधे के पास मिट्टी में 1 इल्ली प्रति वर्ग मीटर', en: '1 larva per m² in the soil near a cut plant' } },
    { name: { hi: 'दीमक', en: 'Termite' }, act: { hi: 'हर वर्ग मीटर में 5 खराब पौधे', en: '5 damaged plants per m²' } },
    { name: { hi: 'सफ़ेद लट', en: 'White grub' }, act: { hi: 'हर वर्ग मीटर में 5 लट', en: '5 grubs per m²' } },
    { name: { hi: 'उकठा / जड़ सड़न', en: 'Wilt / root rot' }, act: { hi: '5–10% पौधे सूखते दिखें', en: '5–10% plants affected' } },
  ],
  chana_veg: [
    { name: { hi: 'चने की इल्ली (फली छेदक)', en: 'Gram pod borer' }, act: { hi: '10 पौधों पर 2 छोटी इल्लियाँ, या 1 बड़ी इल्ली (1 सेमी से लंबी)', en: '2 small larvae or 1 large larva (over 1 cm) per 10 plants' } },
    { name: { hi: 'सेमीलूपर इल्ली', en: 'Semilooper' }, act: { hi: '10 पौधों पर 2 इल्लियाँ', en: '2 larvae per 10 plants' } },
    { name: { hi: 'उकठा / जड़ सड़न', en: 'Wilt / root rot' }, act: { hi: '5–10% पौधे सूखते दिखें', en: '5–10% plants affected' } },
  ],
  chana_pod: [{ name: { hi: 'चने की इल्ली (फली छेदक)', en: 'Gram pod borer' }, act: { hi: '10 पौधों पर 2 छोटी इल्लियाँ, या 1 बड़ी इल्ली (1 सेमी से लंबी)', en: '2 small larvae or 1 large larva (over 1 cm) per 10 plants' } }],
};
