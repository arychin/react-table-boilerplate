// Phase 3 failure check: with Sarvam broken, the diagnosis must still succeed (TRD §6.1, Vision Brief §3.1).
// Run only while SARVAM_API_KEY is temporarily invalid; restore it right after.
import { createClient } from '@supabase/supabase-js';
import { readFileSync } from 'node:fs';

const client = createClient(process.env.EXPO_PUBLIC_SUPABASE_URL, process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY, { auth: { persistSession: false } });
await client.auth.signInWithOtp({ phone: '+919000000001' });
await client.auth.verifyOtp({ phone: '+919000000001', token: '246810', type: 'sms' });

const bytes = readFileSync('test-assets/potato_late_blight.jpg');
const started = Date.now();
const { data: d, error } = await client.functions.invoke('diagnose-crop', {
  body: bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength),
  headers: { 'Content-Type': 'image/jpeg', 'x-ks-language': 'hi' },
});
console.log(`${d?.id && !error ? 'PASS' : 'FAIL'}  diagnosis succeeds with TTS broken  (${Date.now() - started} ms, ${d?.diagnosis?.disease_name})`);

const b = await client.functions.invoke('bolo', { body: { diagnosis_id: d?.id } });
const status = b.error?.context?.status;
console.log(`${status === 503 ? 'PASS' : 'FAIL'}  bolo reports voice unavailable  (status ${status})`);

const row = await client.from('diagnoses').select('diagnosis_json').eq('id', d?.id).single();
console.log(`${row.data?.diagnosis_json?.disease_name ? 'PASS' : 'FAIL'}  diagnosis row complete`);
console.log(`DIAGNOSIS_ID=${d?.id}`);
