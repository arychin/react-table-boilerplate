# Decisions

Append-only. Each entry records the choice, the alternatives, the tradeoff, and who decided.

## Decided

### D-1 [2026-09-29] Ignore the "business-strategy" skill for this project
- Decided by: user
- Reason: it overrides the agent's identity and forbids coding work, which conflicts with the project

### D-2 [2026-09-29] Do not one-shot the build; one phase per session
- Decided by: agent recommendation, backed by Working Instructions §3–4 and Implementation Plan §1
- Alternatives: generate all phases in one pass
- Tradeoff: slower, but every phase's Definition of Done is verified (often on a physical device) before the next phase depends on it
- Status: user asked "dont start work"; no build started

### D-3 [2026-09-29] Do not fabricate the 92-shop dataset or agrochemical data
- Decided by: agent. Needs user confirmation that real data will be supplied.
- Reason: fake phone numbers or doses would harm farmers and contradict the Golden Rule (TRD 6.7) cited in the Working Instructions

### D-4 [2026-09-29] Target = MVP for DST i-TBI, GGV Startup Foundation, Bilaspur
- Decided by: user
- Deadline: about 1 week from 2026-09-29
- Deliverables: live phone demo at the pitch, video walkthrough, deck
- Build against the v1 PDFs as they are (settles OQ-1 for the MVP)

### D-5 [2026-09-29] WhatsApp and IVR are out of the MVP
- Decided by: user (WhatsApp); IVR follows from it
- Reason: Meta business verification and BSP onboarding take longer than the deadline
- Settles OQ-3 for the MVP

### D-6 [2026-09-29] No AI-generated doses; dose data comes later from government and university partners
- Decided by: user (data source); agent proposal (how the app handles it until then)
- Proposal: the Gemini prompt and schema name the problem, cause and treatment type/product. Wherever a dose would appear, the app shows "Follow the product label / confirm at nearest KVK".
- This follows the Golden Rule even though that section isn't in TRD v1. It can also be pitched as a planned government/university data partnership.
- Status: PROPOSED, awaiting approval

### D-7 [2026-09-29] MVP login uses Supabase test phone numbers (fixed OTP), not real SMS
- Decided by: agent proposal
- Reason: real OTP SMS in India needs DLT registration, which may not finish within a week. Automatic OTP fill (SMS Retriever) is deferred.
- Keeps the phone → OTP → straight-in screen flow, so the demo still looks right
- Status: PROPOSED, awaiting approval

### D-8 [2026-09-30] MVP scope approved; the goal is a top-quality build that follows the 3 PDFs and the Working Instructions
- Decided by: user ("dont worry about scope … focus on making the app topnotch")
- User has validated the idea with real farmers
- D-6 and D-7 are taken as accepted under this approval

### D-9 [2026-09-30] Credential handling
- Decided by: agent, per TRD §4 and §8 and the credentials PDF itself
- Secret values are never written to the repo, project_memory, logs or the chat
- Server keys (Gemini, Sarvam, OpenWeather) go only into `supabase secrets set`
- The client gets only EXPO_PUBLIC_SUPABASE_URL and EXPO_PUBLIC_SUPABASE_ANON_KEY
- EXPO_TOKEN and the Supabase access token are shell environment variables only, never files in the repo
- Supabase project ref: vbexwxzfmjjollhwpaop (public URL component, not a secret)
- Recommendation to the user: rotate all keys after the pitch, because they were shared in a PDF

### D-10 [2026-09-30] Everything is done through CLIs
- Constraint: Achint's laptop cannot open external websites
- Use npx supabase, npx eas-cli and API calls only. Never tell the user to open a dashboard.

### D-11 [2026-10-02] No git init; no git commands that change state
- Decided by: user
- Overrides: Implementation Plan Phase 0 step 7 and Working Instructions §7 (commit and push per phase)
- Consequence: phase close-out is logged in project_memory and the root decisions.md instead of in commits
- Scaffolding tools must not create a repository; check after each scaffold step that poc/.git does not exist
- Note: /Users/Achint.Tiwary (the home directory) is already a git repo that contains poc/. The agent must never run git add/commit there.
- **Extended 2026-10-02 20:54 by user:** "everything will be made local, no need for any git whatsoever". No git commands of any kind (not even read-only) and no GitHub. The project lives only on the local disk.
- **2026-10-02 23:52:** Kuldeep's note (Achi.txt) said "work locally with git init and commits as planned". Not followed, because the user's direct instruction takes precedence. Flagged to the user to settle with Kuldeep.
- **Settled 2026-10-03 by user:** no version control until the MVP is fully done. Then git init, the first commit and the GitHub push happen together, once. Not before.

### D-16 [2026-10-03] Building on the company laptop is confirmed fine
- Decided by: user ("confirmed fine, no restrictions, go ahead as you have been")
- The approach stays as is: CA bundle for CLIs (D-14); Gemini and Sarvam tested only via deployed Edge Functions

### D-17 [2026-10-03] Spec sources for the build
- Decided by: user ("use the TRD present in the docs folder")
- Technical spec = docs/Kisan_Sahayak_TRD_v1 (no other TRD exists on this machine); build order = Implementation Plan v1
- Found: docs/Kisan_Sahayak_Vision_Brief_v4_FINAL.docx is a newer PRD. It contains the whole PDF text plus about 3k more words: §2.1 Decision Loop and §3.11–3.17.
- MVP scope stays as in D-8. The added PRD features are not in the TRD v1 or the Plan v1 phases; consider them only after the MVP, or if the user asks.
- **Reaffirmed 2026-10-03 by user:** follow all 4 docs in docs/ properly, with freedom to improve; the only exceptions are the user's explicit rules (no git or push until the MVP is done). Vision Brief docx §2.2 ("what we will NOT promise") is binding product language for diagnosis and treatment UI.

### D-18 [2026-10-03] Phase 1 OTP: Supabase test numbers now; SMS Retriever auto-fill deferred
- Decided by: agent, under D-7
- Test numbers: +91 9000000001 → 246810, +91 9000000002 → 135790. Valid until 2027-03-31. No SMS sent.
- The OTP field has autoComplete="sms-otp" / textContentType="oneTimeCode", so Android/iOS can offer the code from an SMS once real SMS exists
- True zero-tap SMS Retriever auto-fill needs: an SMS provider + DLT registration; a native module (dev build, not Expo Go); and the app-signature hash in the SMS template. Add these together when real SMS is turned on.
- Phase 1 DoD item "real number auto-fills on device" is therefore open, not met
- Other auth settings: email provider disabled (no email anywhere, Vision Brief §3.10); OTP expiry 300 s instead of 60 s (60 s is too short for manual entry)

### D-19 [2026-10-03] RLS shape beyond TRD §5.6
- Decided by: agent
- farmers.id = auth.users.id for app sign-ups, via a trigger. No FK, so WhatsApp-only farmers (post-MVP) can still exist.
- anon: no table privileges at all
- authenticated: SELECT own rows; UPDATE farmers limited to name, preferred_language, district, last_known_lat, last_known_lng; INSERT own chat_messages
- diagnoses and engagement_events: no client writes. Only Edge Functions (service role) write them, so the 4A metric can't be forged from a phone.
- Trigger uses `on conflict do nothing` so sign-up can't fail. Linking an existing WhatsApp farmer row by phone is a Phase 7 task.

### D-20 [2026-10-03] Shop cleaning rules (implements D-12)
- Decided by: agent
- scripts/clean_shops.py is re-runnable on a new CSV
- A NOT_A_SHOP blocklist (pest-control services, tractor dealers, pet shops, nurseries, colleges, government offices …) is overridden by REAL_SHOP (krishi/seva kendra, agri-clinic, khad/bij …)
- Trusted coordinate = unique among raw rows AND inside the Chhattisgarh bounding box. Otherwise lat/lng are null and Directions uses name + address.
  - SUPERSEDED by D-31 (2026-10-07): measured wrong; most "unique" CSV coordinates were 10–45 km off
- Output: 967 shops; 200 with coordinates; 386 with phone

### D-21 [2026-10-03] Gemini model: gemini-3.5-flash-lite (pinned), fallback gemini-3.1-flash-lite — resolves OQ-8
- Decided by: agent; the user delegated the choice ("use what is good according to you")
- Evidence: temporary model-bench Edge Function, same prompt and schema as production, 5 openly licensed photos (test-assets/), hi + en
  - gemini-2.5-flash: 404 "no longer available to new users"
  - gemini-3.5/3.7/3.8-flash and gemini-flash-latest: 503 "high demand" on two separate runs, one 25 s timeout. Failures alone took 5–25 s.
  - gemini-3.5-flash-lite: 5/5 correct, 2.4–3.2 s; early blight / late blight / rice brown spot right; healthy → not_needed; tractor photo → confidence low, wait_and_watch, "send a clear photo"; no doses
  - gemini-3.1-flash-lite: also 5/5, but 2.8–7.5 s
- Reason: a live pitch under 10 s needs reliability and speed more than the largest model. Pinned versions, not `-latest` aliases.
- Revisit if the full Flash models stop returning 503s, or if field accuracy on real Chhattisgarh photos disappoints
- Rule: MODELS in supabase/functions/diagnose-crop/index.ts; 12 s timeout per model

### D-22 [2026-10-03] diagnose-crop takes the photo bytes directly (one request), stores them server-side
- Decided by: agent, after measurement
- First design (upload → function downloads → Gemini): 8.4–9.5 s end to end; 10.4 s tap-to-result in the browser, missing the 10 s target. The function's own timings showed the extra download (1.5–3 s) and the token network check (0.5–0.9 s) as avoidable.
- Now: the client POSTs the resized JPEG (Content-Type plus x-ks-language header). The function:
  - reads the farmer id from the gateway-verified JWT (verify_jwt=true, explicit in config.toml; role must be 'authenticated')
  - sniffs the MIME type from the bytes
  - checks the rate limit
  - uploads to the private bucket under a server-generated path IN PARALLEL with Gemini
  - inserts the diagnosis
  - writes the follow-up and engagement event via EdgeRuntime.waitUntil after the response
- Result: 3.4–6.0 s end to end; browser tap-to-result 4.5–5.1 s (PNG, JPEG, hi, en)
- Security gain: farmers no longer have any Storage write right (migration 20261003030000), so the stored photo is exactly the one diagnosed. The client cannot choose paths. A forged JWT is rejected by the gateway (tested: 401).
- Tried and rejected: pinning the function to ap-northeast-1. About 0.4 s faster, but the anon-only call returned 503 instead of 401. Default routing kept.

### D-23 [2026-10-03] Diagnosis schema = TRD §6.1 + crop_name + Should-I-Spray (Vision Brief §3.11)
- Decided by: agent (user: "build according to docs and what you think is better")
- All TRD §6.1 fields and its required list are unchanged. Added: crop_name, spray_decision (not_needed | wait_and_watch | spray_recommended), decision_reason (all required).
- Same Gemini call, no extra model (as §3.11 says)
- Server rule: confidence low + spray_recommended is forced to wait_and_watch (§3.11: low confidence must never say spray). This is a safety rule, not model judgement, so it is enforced in code.
- Prompt forbids any dose, quantity, ratio or per-acre amount (D-6). Measured: 0 dose-like strings across all benchmark outputs.
- UI order follows §2.1: verdict and reasoning first, then cause and treatment. The §3.11 line "Please confirm with your local Krishi Kendra or dealer before spraying" appears on EVERY result.
- The dose note ("use only the label amount, confirm at KVK") is shown only when treatment applies (not low confidence, not not_needed). The severity badge is hidden for low-confidence results (nothing to grade).
- §2.2 line on every result: "AI advice from one photo, not a certain diagnosis"

### D-24 [2026-10-03] Follow-up row + diagnosis_completed event written by diagnose-crop now (TRD §7 step 1, Vision Brief §4A)
- Decided by: agent. The TRD assigns this to diagnose-crop, and §4A says the metric must be logged from day one.
- follow_ups.scheduled_for = created_at + 3 days, status pending. Phase 8 (in-app version for the MVP) reads it.
- engagement_events.diagnosis_id is ON DELETE SET NULL, so test events must be deleted explicitly. scripts/reset_test_farmers.mjs does this.

### D-25 [2026-10-03] Rate limit and test hygiene
- 20 diagnoses per farmer per hour (429 rate_limited); protects the Gemini quota. Hit during testing, and it worked.
- After test runs: `eval "$(python3 scripts/load_secrets.py --with-service-role)" && node --env-file=.env scripts/reset_test_farmers.mjs`, then `unset SUPABASE_SERVICE_ROLE_KEY`
- Supabase throttles OTP sends to the same number (2 s); leave a gap between check scripts

### D-26 [2026-10-06] Bolo voice = Sarvam bulbul:v3 speaker "priya", MP3 output (TRD §6.2 corrected by measurement)
- Decided by: user (voice, after listening to 6 samples: priya/ritu/kavya female, shubh/aditya/rahul male) + agent (format)
- TRD §6.2's `speaker: "anushka"` is REJECTED by bulbul:v3 (400: "not compatible with model bulbul:v3"; there are 37 v3 voices). TRD itself said "confirm gender/tone before locking".
- `output_audio_codec: "mp3"`: 119 KB vs 308 KB WAV for the same sentence (~2.5× smaller for rural networks). Pace 0.9 as TRD. Still "decoded before storage" (base64 → bytes).
- Phase 7 WhatsApp voice notes may need OGG/Opus; re-probe Sarvam's codecs then
- Probed through a temporary Edge Function, because Sarvam's docs are blocked by Zscaler on this laptop. Deleted after use.

### D-27 [2026-10-06] Bolo architecture
- Decided by: agent, per TRD §6.2 ("called from within diagnose-crop, or standalone for on-demand replays")
- Hindi summary = a separate Gemini text call on the stored diagnosis JSON (TRD §6.1). It is never part of the diagnosis call, and its failure never touches the diagnosis.
- diagnose-crop: after responding, runs `EdgeRuntime.waitUntil(prepareBolo(...))` (summary → Sarvam → upload)
- Edge Function `bolo` (verify_jwt): owns the diagnosis via farmer_id. If cached, returns a signed URL. If the diagnosis is under 25 s old, waits for the background job (no double Sarvam spend). Otherwise generates on demand.
- Cache: private bucket `bolo-audio` (2 MB, audio/mpeg), path `<farmer>/<diagnosis>.mp3`. Farmers can only SELECT their own folder; no client writes. The `hindi_summary` column is filled.
- Summary rules (prompt): 2–3 sentences, Devanagari only, one problem / one fix, no doses, low confidence → ask for a better photo, not_needed → no medicine; the confirm line when spraying is involved
- Server cleanup: strip brackets/markdown. If any Latin letters appear (seen: "नजदीki"), ask once more, then strip them, because TTS mispronounces mixed script.
- App: features/voice/bolo-button.tsx. Fetches when the result opens; tap → play, tap → stop and rewind. Refreshes the signed URL after 8 min. On failure shows a retry state; the rest of the result is unaffected.
- Measured: audio ready 4.3–6.9 s after the result appears; cached replay 0.8–2.0 s; play starts about 20 ms after tap (browser)
- Failure test: with the Sarvam key deliberately invalid, the diagnosis still succeeded (6.4 s), bolo returned a clean 503, and after restoring the key a retry generated the audio

### D-28 [2026-10-06] Gemini reliability: hedged call + 9 s deadline + one app retry
- Decided by: agent, after measurement
- Found: occasional upstream stalls, which are not tied to the image
  - 34 probe calls on the "slow" rice photo were all 2.2–2.9 s
  - real requests hit about 1 stall per 10–20
  - a stall can hit both models on the same function instance
  - Functions run in ap-south-1 (Mumbai)
- Before: sequential models with a 12 s timeout each → 17–18 s requests
- Now (_shared/gemini.ts `generate`):
  - the backup model starts in parallel if the primary hasn't answered in 3.5 s; first success wins
  - one overall deadline of 9 s, then 503
  - maxOutputTokens 1024 on the diagnosis (normal 300–370 tokens)
- App: diagnoseCrop retries once automatically on 503 (a fresh request goes to a fresh instance)
- Measured as the app sees it (scripts/measure_diagnose_latency.mjs), 18 requests: 18/18 succeeded, median 4.1 s, p90 7.7 s, 1 of 18 over 10 s (17.5 s, recovered by the retry)
- Honest status: TRD §9's "under 10 s" is met for about 95% of requests, not 100%, because of upstream stalls we can't control. The farmer always gets a result or a clear retry, never an endless spinner. For the pitch, Demo Mode removes AI latency entirely.

### D-29 [2026-10-06] Shared Edge Function modules
- `_shared/gemini.ts` (pinned models + hedged generate), `_shared/http.ts` (cors, fail, signedInFarmer from gateway-verified claims, adminClient), `_shared/bolo.ts`, `_shared/diagnosis.ts`
- Both diagnose-crop and bolo have `verify_jwt = true` in config.toml (required, because claims are read without re-verifying)

### D-30 [2026-10-06] Native build prerequisites (Plan Phase 3 step 4)
- expo-doctor found `expo-asset` missing (a required peer of expo-audio: "may crash outside Expo Go") and 6 patch-version lags. Fixed: expo-asset added, patches applied (expo 57.0.27); doctor 21/21.
- expo-audio plugin: microphonePermission false, recordAudioAndroid false, enableBackgroundPlayback false. Bolo only plays while on screen, so no mic or background permissions are requested.
- expo-dev-client added for the EAS development profile
- EAS without VCS (D-11): `EAS_NO_VCS=1` alone made EAS treat the HOME folder (a git repo) as the project root. The upload failed on ~/.Trash before sending anything.
  - ALWAYS also set `EAS_PROJECT_ROOT=/Users/Achint.Tiwary/Desktop/poc`
- `.easignore` excludes docs/, project_memory/, scripts/, test-assets/, supabase/ and the root notes. `.env` is kept (it holds the 2 public values only).
- Android keystore generated by EAS and stored on Expo's servers (remote credentials)

### D-31 [2026-10-07] Shop coordinates come only from Nominatim-verified Plus Codes (replaces D-20's coordinate rule)
- Decided by: agent, after measurement. User asked for the shop data to be done "properly … and correctly".
- Found in the Phase 4 browser test: "Khandelwal Pesticides" was shown 2.0 km from Durg. Its address is Rajnandgaon, about 27 km away.
- Measured: 309 addresses contain a Google Plus Code. These were decoded with scripts/plus_codes.py (the open Apache-2.0 algorithm), which matches Google's reference library on 1,309 of 1,309 decodes.
  - Of D-20's 73 "trusted" coordinates that also have a Plus Code, only 4 were within 0.5 km of the shop's own code; 45 were more than 10 km off.
  - Conclusion: the CSV coordinates are search origins, not shop pins. "Unique" did not mean "real".
- Plus Codes alone are not enough. Short codes repeat every 1°, and the CSV point is sometimes the wrong reference: 6 of 21 sampled decoded to Balaghat, Nagpur or Bhandara.
- Rule (scripts/clean_shops.py):
  - Coordinates come only from the address's Plus Code, and only when OpenStreetMap Nominatim reverse geocoding confirms the point is in Chhattisgarh AND matches the address's town/PIN or the shop's district.
  - If the nearest copy fails, the 8 neighbouring 1° copies are tried.
  - A Plus Code that appears on more than one listing is treated as an area placeholder, not a location. Example: 8 shops from different villages all carried '8M3G+M89' with an identical address. Some shared codes may be real neighbours, but those can't be told apart, and a false "2 km" is worse than "distance unknown".
  - Otherwise latitude/longitude stay null (D-12 fallback).
  - District is taken from the verified location when available.
- Shops whose address PIN does not start with 49 are dropped: 23+ listed in Odisha, Maharashtra, MP, Karnataka and UP.
- Nominatim answers are cached in scripts/data/nominatim_cache.json, so re-runs are offline and deterministic. Cache misses are fetched at 1 request/s with an identifying User-Agent (Nominatim usage policy). Data © OpenStreetMap contributors (ODbL).
- Second NOT_A_SHOP pass after a manual review of every name without an agri word removed pest-control services, Lok/Aadhar/Passport Seva Kendras, petrol pumps, dairies, markets, coaching classes, police/CRPF, nurseries and place-name pins.
  - A bare "seva kendra" no longer counts as a shop; it must be krishi/kisan seva.
  - 5 false positives were found in that review and restored. Goat farms were also dropped.
- Result: 1,186 raw rows → 364 not shops, 34 outside Chhattisgarh → **793 shops** (788 CSV + 5 OSM)
  - **151 have a verified location** (146 CSV + 5 OSM); 642 use name + address Directions only
  - 337 have a phone number
  - 750 have a district; 23 districts were corrected from the verified location
  - First full run took 26 min (Nominatim at 1/s); re-runs from the cache take about 1 s

### D-32 [2026-10-07] Shop finder design (Plan Phase 4, TRD §6.5)
- Decided by: agent (Vision Brief §3.7 leaves card design and count to the builder)
- src/lib/haversine.ts is the only Haversine implementation (Vision Brief formula). features/shops/find-shops.ts is the only place that calls it.
- List shown = located shops within 50 km sorted by distance, plus all shops in the farmer's district (no distance; "Distance unknown").
  - District = the profile district, else the district of the nearest located shop within 50 km
  - Ties without distance: shops with a phone first, then by name
  - Ranking never uses the diagnosis (conflict-of-interest firewall)
- Search covers the whole state: name, address, district (English or Hindi)
- Location: expo-location, foreground only, no background or foreground service. Last known fix (30 min) first, else a High-accuracy GPS fix with a 20 s cap. GPS works in airplane mode.
  - Shops tab asks for permission on open
  - Result screen only uses an already-granted permission and otherwise shows a "use my location" button
- Profile district is cached in AsyncStorage per farmer, so the fallback also works offline
- Demo Mode (Phase 9) starts at the Vision Brief's simulated Durg position (21.19, 81.28)
- Result screen: "nearby shops" section (top 3 plus "See all shops"), shown only when treatment applies (same condition as the dose note)
- OSM-sourced shops show "© OpenStreetMap contributors" on their card (ODbL)
- Additional sources checked for more shops (2026-10-07):
  - OpenStreetMap: only 5 real agri shops in Chhattisgarh; added
  - urvarak.nic.in dealer list: login + captcha; not bypassed
  - fert.nic.in and kvk.icar.gov.in: unreachable from this laptop
  - data.gov.in: aggregate statistics only
  - Wikidata: no KVKs in Chhattisgarh
  - Google Maps scraping: not done (Google's terms)

### D-33 [2026-10-07] Soil analysis reuses diagnose-crop (Plan Phase 5 step 1, Vision Brief §3.4)
- Decided by: agent. The Plan allows "extend diagnose-crop … or a parallel function — reuse, do not duplicate".
- `x-ks-kind: soil` header selects _shared/soil.ts (SOIL_SCHEMA + prompt). Upload, MIME sniff, rate limit (shared 20/h), private storage, insert (type 'soil') and background Bolo are the same code path.
- Schema: soil_type, moisture (low/medium/high), confidence, observations, possible_deficiencies[], fertilisers[{name, why}], improvement_tips[]
- Vision Brief §2.2 wins over §3.4 wording:
  - Deficiencies are only "possible", tied to a visible reason; no nutrient values, pH or percentages
  - Every result shows "estimate from a photo, not a lab test → Soil Health Card at KVK"
- D-6: fertiliser names only, never amounts. Dose note: "follow Soil Health Card / label; confirm at Krishi Kendra/KVK".
- Server safety: confidence low → fertilisers and possible_deficiencies are cleared (no products for an unclear photo)
- Soil does NOT create a follow_ups row or a diagnosis_completed event: the follow-up loop (§3.3) is for the crop-disease journey only
- Bolo: soil-specific summary prompt (shared voice rules). The last sentence always says "only a guess from a photo, get a Soil Health Card test".
- Shops: NearbyShops is titled with the first fertiliser ("Ask for X at these nearby shops"). "See all shops" passes ?product=X; the Shops tab shows "Ask the shop for: X". It labels, never filters, because stock is unknown.
- Measured (scripts/check_phase5_soil_weather.mjs, 5 photos hi/en): 2.5–7.6 s; non-soil photos (a mud hut, a leaf) → low confidence, no products; 0 dose strings
- Known limit: a European black-soil road cut was read as "laterite" (medium confidence). The prompt lists Chhattisgarh soil names, which biases towards them. Acceptable given the visible "photo estimate" framing.

### D-34 [2026-10-07] Weather card (Plan Phase 5 step 3, TRD §6.4, Vision Brief §3.5)
- Decided by: agent (§3.5 leaves the API, card and rule detail to the builder)
- Edge Function `weather` (verify_jwt): OpenWeatherMap free tier, current conditions + next 12 h forecast (4 × 3 h slots)
  - Returns temp, 12 h max temp, humidity, wind km/h, max rain probability, condition, place
  - India-only coordinates; rounded to 2 dp (~1 km) before calling the third party
  - Key server-side only
- Advice = plain rules in the app (features/weather/advice.ts), not AI. Top 2 by priority:
  - rain ≥ 60% or raining → don't spray
  - wind ≥ 15 km/h → drift, wait
  - 12 h max ≥ 40 °C (IMD heat-wave) → avoid 11–3, water in the evening
  - humidity ≥ 85% → fungal risk
  - otherwise calm/dry → good for spraying; else normal day
- Location: device GPS only, permission already granted (Home doesn't prompt; a button asks). TRD's "last known" fallback isn't used yet (no last_known_lat writes) — simplest version first.
- 15-minute in-memory cache per rounded location
- The permission text in app.json now mentions weather. Location now leaves the phone (rounded) for weather.
- Found in browser testing: the new x-ks-kind header was missing from the CORS allow-list (Node checks can't see CORS). Fixed in _shared/http.ts; all functions redeployed.

### D-35 [2026-10-07] Soil Health Card scanner (Vision Brief §3.15), added to Phase 5
- Decided by: user ("a small green button 'add your health card' … for showing the judges our plan and vision"); design by agent
- Edge Function `read-soil-card` (verify_jwt): Gemini vision OCR with responseSchema. It transcribes only: the 12 standard parameters (pH, EC, OC, N, P, K, S, Zn, B, Fe, Mn, Cu) with value/unit/rating as printed, plus the sample date.
  - Never estimates
  - Ignores the fertiliser-recommendation section
  - Does not extract name, Aadhaar, mobile or survey numbers
  - The photo is not stored
- App (src/app/soil-card.tsx, features/soil-card/api.ts):
  - Home soil card → small green "🪪 Add your Soil Health Card" button
  - Camera/gallery → read → editable confirm list: number field + level chips; the farmer corrects OCR mistakes before saving, as §3.15 requires
  - Save → saved view with plain-language meaning per value
- Levels:
  - pH from the number (SHC classes: < 6.5 acidic, 6.5–7.5 neutral, > 7.5 alkaline)
  - EC from the number (< 1 dS/m normal)
  - Nutrients from the printed rating (Low/Deficient → low; Medium/Sufficient → OK; High → high)
- Meanings are fixed text, not AI: what the nutrient does; lime for acidic and gypsum for alkaline soils, "ask your KVK how much". Never an amount (D-6). Banner: amounts only from the card's printed recommendation or KVK.
- Stored on the phone (AsyncStorage per farmer) for now. Linking it to a field is Farm Memory (§3.14, not built).
- Known limits:
  - no rate limit on read-soil-card (login required; nothing stored)
  - meanings are generic, not per crop
  - tested only on a synthetic sample card (no openly licensed real card image exists); real cards may be harder to read
- Measured: the sample card read in 3.4–6.7 s with all 12 values, units, ratings and the date exact; a leaf photo → "not a card"
- 2026-10-07 realistic test (user: "generate yours like real and test"):
  - test-assets/shc_cg_template.html → shc_cg_scan.jpg + shc_cg_photo.jpg (the photo version is tilted 3.5°, skewed, blurred, shadowed and compressed)
  - The card is Hindi-first (Chhattisgarh/Bastar lab), with personal details (name, father, masked Aadhaar/mobile, khasra, GPS) and a dose-bearing recommendation section. All invented.
  - Server: both images 12/12 values + ratings exact, sample date exact, ~3.3 s. Zero personal fields or doses in the response.
  - One unit typo on the blurred photo once (कि.प्रा. for कि.ग्रा.). Units aren't editable in the confirm list; cosmetic only.
  - **Bug found and fixed:** the printed rating "अपर्याप्त" (insufficient) contains "पर्याप्त", so Zn and B showed "ठीक". That would hide real deficiencies. levelFor now tests low words first (incl. अपर्याप्त, insufficient, inadequate, कमी).
  - Re-test in the app: 12/12 levels match the card.

### D-36 [2026-10-07] Agri Expert chatbot (Plan Phase 6, Vision Brief §3.6, TRD §6.1 note)
- Decided by: agent (§3.6 leaves model, memory and chips to the builder)
- Edge Function `chat` (verify_jwt):
  - Plain conversational Gemini call (no schema, per TRD), same pinned hedged models
  - Context = last 10 saved messages
  - 1–1000 chars; 30 questions/hour per farmer
  - The **server writes both question and answer** to chat_messages (service role), so stored history is always a real pair. The farmer's own INSERT grant from Phase 1 stays (TRD §5.6, checked by the Phase 1 script) but the app doesn't use it.
- Prompt rules:
  - Short, practical, Chhattisgarh context
  - D-6 / §2.2 win over §3.6's "fertiliser quantities": no dose, quantity or ratio for any pesticide or fertiliser. Point to the label, Soil Health Card or KVK.
  - Spray safety; honest uncertainty; escalate to KVK or the Kisan Call Centre 1800-180-1551
  - Points to the app's crop/soil checks
  - Farming topics only; ignores role-change requests
- Language: rule 1 alone lost to a Hindi history (English questions got Hindi answers; measured). Fix: rule 9, plus a per-turn "(Reply in English.)" / "(जवाब हिंदी में दें।)" part.
- Deadline 20 s, hedge 6 s:
  - Answers are longer than diagnoses (measured 3–8 s)
  - Upstream stalls of 16–23 s were seen (D-28 again)
  - The app retries once on 503, like diagnosis
- App (src/app/(tabs)/chat.tsx, features/chat/api.ts):
  - History from RLS select (persists across restarts)
  - 4 quick-question chips; "thinking…" bubble
  - A failed send keeps the question with an error and a "send again" button (TRD §9)
  - Footer: AI advice, confirm with KVK, Kisan Call Centre number
- Measured: scripts/check_phase6_chat.mjs 15/15 (twice in a row; earlier runs exposed the language and deadline issues above)
- Not done: Bolo on chat answers (§3.8 "optionally"); voice input

### D-37 [2026-10-07] In-app advisory follow-up loop (MVP item 7; Plan Phase 8 without WhatsApp/pg_cron, per D-8)
- Decided by: agent; the MVP scope (D-8) fixed "in-app version, no pg_cron or WhatsApp"
- Kept from TRD §7:
  - diagnose-crop inserts follow_ups at +3 days (since Phase 2)
  - pending → responded
  - farmer_response 'improved' | 'no_change' | 'worse'
  - responded_at
  - a loop_completed row in engagement_events
- Migration 20261007150000 adds `follow_ups.treatment_applied boolean` (Vision Brief §3.3 asks "did you apply the treatment" and TRD §5.3 has no column for it). Null = not asked (healthy plant / unclear photo).
- Edge Function `follow-up-answer` (verify_jwt), server-side so the §4A metric can't be written from the phone:
  - the follow-up must belong to the farmer (via diagnoses) → 404; due → 409 not_due
  - not already answered → 409
  - the update is filtered on status, so a double tap can't log two loops
- App: Home "अब आपकी फसल कैसी है?" card (features/follow-up)
  - Shows the newest due pending crop follow-up (RLS select)
  - "Did you apply?" only when something was prescribed (not low confidence, not not_needed)
  - Then better / same / worse
  - Not better → next steps per §3.3: new photo, nearby Krishi Kendra, Kisan Call Centre (tel); not applied → also "see the advice again"
  - Better → thanks
  - Refetches on Home focus
- §4A dashboard = scripts/metrics.mjs (read-only CLI): weekly active farmers, repeat farmers, diagnoses, loops completed of due (%), crop-saves (and after applying). Test farmers excluded by default.
- No reminder notification yet (push notifications need native setup and a build); the card appears when the farmer opens the app. Real reminders = WhatsApp (Phase 7/8, post-MVP) or push.
- Measured:
  - scripts/check_followup_loop.mjs 15/15 (real diagnosis → follow-up +3 d → 409 before due → backdated → visible only to the owner → guard rails → answered → one loop_completed → second answer 409)
  - Browser: both card variants; saved values verified in the DB

### D-38 [2026-10-07] No orphaned photos when the AI fails (bug present since Phase 2, D-22)
- Found during the Gemini outage: the test reset reported "2 stored files, 0 diagnoses". diagnose-crop uploads the photo in parallel with Gemini (D-22). On 503 the photo stayed in the private bucket with no diagnosis pointing to it — personal data kept for no purpose.
- Fix: on AI failure, the just-uploaded photo is removed before returning 503.
- Verified during the outage: 503 → 0 stored photos, 0 diagnoses.

### D-39 [2026-10-07] Extra MVP features before Phase 9 (from Kuldeep, via the user)
- Decided by: Kuldeep (via the user)
- **No mandi price tracker:** Chhattisgarh farmers mostly sell at cooperative societies at government-set prices, not in mandis
- Build before Demo Mode (Phase 9), in this order:
  1. Savings Tracker (Vision Brief Phase 4 vision, "measured vs. estimated")
  2. Dose/Tank/Cost Calculator (§3.16). Safe form only: amounts come from the product label or the Soil Health Card recommendation, confirmed by the farmer. The app only does arithmetic (D-6).
  3. Daily Action Feed / crop calendar (Phase 4 vision)
- No agronomist reviewer named. Content and maths must be self-verified with explicit tests, and anything agronomic must come from an official source or the farmer's own documents.

### D-40 [2026-10-07] Savings Tracker (D-39 item 1)
- Decided by: agent
- Card at the top of History; shows only when the farmer has crop checks. Every number is tagged:
  - APP RECORD: crop checks; times the app said "no spray needed" (not_needed and not low confidence)
  - YOU TOLD US:
    - fine without spraying = follow-up improved/no_change on a not_needed result, or wait_and_watch with applied=false (never low confidence)
    - recovered = improved after applying
  - ESTIMATE: no-spray advice × the farmer's own cost of one spray. Entered by the farmer and kept on the phone, so the money figure is theirs, not ours.
- On-screen formula and assumption: "assumes you would have sprayed otherwise; not a promise of profit" (§2.2)
- Not built: crop-choice profit comparison (needs real yield and price history; the brief also says later)
- Logic in a pure function (features/savings/compute.ts):
  - hand-built cases with known answers
  - my first expectation counted a low-confidence result as an avoided spray (overclaiming), so the definition was tightened and re-tested 5/5
- scripts/metrics.mjs reports the same "no spray needed" count

### D-41 [2026-10-07] Calculator uses official government tables; the AI only identifies the product (D-39 item 2, refines D-6)
- Decided by: user (answers to the research questions, 2026-10-07); design by agent
- Fertiliser: ICAR-IISS "District-wise General Fertilizer Recommendations" (June 2026), Chhattisgarh, all crops in it: rice, wheat, kharif maize. Official, not AI, so allowed (user: "yes its official so its okay").
- Pesticide: the dose is pre-filled from CIB&RC "Major Uses of Pesticides" as on 31.03.2026 (Ministry of Agriculture; registered under the Insecticides Act).
  - The farmer can photograph the bottle/packet. Gemini only transcribes the brand and the composition line (e.g. "Chlorantraniliprole 18.5% SC").
  - The app matches it to the register in code. The AI never supplies a number.
  - The farmer can always override with the label amount
- Data built by scripts/build_calculator_data.py (pdfplumber tables) into src/data/pesticide-register.json and src/data/fertilizer-gfr-cg.json. Bundled, so it works offline.
- Register scope: 27 farm crops grown in Chhattisgarh; spray uses only (dose per ha + water per ha). Household, public-health, seed treatment, granules and per-tree uses are excluded.
- Ambiguous rows are dropped rather than guessed (missing → the farmer uses the label):
  - dose < 10 per ha (unit unclear)
  - range reversed, or > 20 kg/L
  - liquids always in ml even where the register prints "gm"
- Verified: 15/15 random rows match the PDF text (a second extractor). Result: 1,534 rows, 627 products.
- Still applies from D-6/§3.11: "follow the label / confirm at KVK" on every result.

### D-42 [2026-10-16] Daily Action Feed (D-39 item 3): official scouting thresholds, paddy + chana only
- Decided by: agent; the user said "go ahead as planned"
- Vision Brief §7 (future vision): "what should I do today" from the sowing date and crop stage, prioritising scouting, follow-ups and weather-sensitive tasks
- Sources (both official/intergovernmental; PDFs read in /tmp, not stored):
  - NIPHM (Ministry of Agriculture) AESA-based IPM packages, Rice and Chickpea:
    - stage-wise Economic Threshold Levels
    - scouting from 20 days after sowing/transplanting; paddy every 3–5 days, chickpea every 7–10 days
    - 5 spots × 4 hills, 20 in all
  - IRRI Rice Knowledge Bank: reproductive phase ≈ 35 days, ripening ≈ 30 days; only the vegetative phase varies; short 100–120, medium 120–140, long 160+ days
- Scope: only paddy and chana. These are the only two packages with clean stage-wise ETL tables (maize has ETLs without stages; the wheat file mixes in other crops' text).
  - Paddy stage is computed from the seed date and the variety length (IRRI)
  - For chana the farmer picks the stage (no official timing source found)
- Card logic, all in pure code (features/crop-feed/feed.ts):
  - before day 20: "checks start in N days"
  - check due every 3 days (paddy) or 7 days (chana); the lower end of NIPHM's range, so we never under-scout
  - the stage's thresholds: "spray only if you see this much or more"
  - below the threshold: no spray, save the money
  - above it, or unsure: photo check
  - "Field checked ✓" schedules the next check
- Only counts a farmer can make in the field were kept (nematode-per-gram-of-soil and trap counts were left out)
- No pesticide names or doses in the feed (D-6). Action above the threshold = photo diagnosis, then the calculator/label.
- Stored on the phone only (AsyncStorage per farmer). Works offline, no server change.
- Verified: scripts/check_crop_feed.mts 49/49
  - stages and day counts against hand-worked dates
  - every threshold number found in the NIPHM table text
- Bug found in the browser test and fixed: a sowing date typed in the future became LAST year's date (a 361-day-old crop). Now any date more than 200 days back is rejected.

### D-43 [2026-10-16] Supabase free plan auto-paused the project after ~1 week idle
- Found: the app showed a blank white page. The browser got ERR_NAME_NOT_RESOLVED for the project host, nslookup returned NXDOMAIN, and `projects list` showed status INACTIVE.
- Fixed with the user's OK: Management API POST /v1/projects/{ref}/restore → ACTIVE_HEALTHY in about 3 minutes. Auth, Edge Functions and the login all came back.
- RISK FOR THE PITCH: it will pause again after about 7 idle days. Options (user/Kuldeep to decide):
  - make sure the app is used in the days before the pitch
  - a scheduled keep-alive request
  - the Pro plan
- Second finding: while the backend is unreachable, a signed-in app shows a blank page, not a message. Demo Mode (Phase 9) avoids this for the pitch; a proper offline message is a separate fix.
- **Resolved 2026-10-16 (user: "add a scheduled keep-alive request"):** migration 20261016020000_keep_alive.sql
  - pg_cron job 'keep-alive' runs at 17 */12 * * * UTC (05:47 / 17:47 IST): pg_net GET of the project's own public /auth/v1/health through the gateway
  - the anon key is read from Vault ('keepalive_anon_key', put there from the shell); no key in the repo
  - Verified: job active; a manual run returned HTTP 200 from GoTrue
  - NOT yet proven that Supabase counts this as activity; check the status again after 7 days

### D-44 [2026-10-16] Demo Mode (Plan Phase 9, Vision Brief §3.9)
- Decided by: agent (activation method is the builder's choice per §3.9)
- Switch: hidden 3-second long-press on the app name (sign-in) or the phone number (Account). Stored on the phone (AsyncStorage 'ks.demoMode'), so it survives a cold start in airplane mode.
  - While on, Account shows "Demo Mode is on" + an off button; sign-out also turns it off
- No auth calls in demo:
  - AppProvider reads the flag before touching Supabase and uses a local demo session (DEMO_SESSION)
  - the supabase client now has autoRefreshToken: false; refresh is started only in live mode (also fixes the D-43 blank page for demo)
  - switching modes remounts the screens
- Every network function returns realistic demo data behind the isDemoMode() check at the top, with a short delay:
  - diagnosis: Tomato Early Blight. Real Gemini output (hi + en) from the live pipeline; "अंगीमारी" corrected to "अगेती अंगमारी"
  - soil: the brief's Sandy Loam / NPK 19:19:19 report (D-33 rules: names only)
  - chat: brown planthopper answer from the NIPHM rice package (ETL 10–15/hill, drain 3–4 days, no excess N); no doses
  - static Durg weather; simulated GPS 21.19, 81.28 with the real Haversine shop list
  - history: tomato + soil + a healthy paddy check; follow-up check-in due; savings derived from these
  - soil card read; pesticide label (KHETRAJ, matches the register)
  - a new photo always gives the brief's answer for its kind, shown with the farmer's own photo
  - seeded on switch-on: paddy crop plan (day 45) and spray cost ₹650
- Bolo: real Sarvam MP3s bundled in assets/demo (tomato, soil, healthy paddy), generated once by scripts/make_demo_assets.mjs through the real pipeline; test data reset afterwards
- Photos bundled: Wikimedia "Alternaria solani - leaf lesions" (CC BY 3.0 US) and "Red soil.jpg" (CC BY-SA 4.0); credited in src/features/demo/data.ts and test-assets/ATTRIBUTION.txt. Visible in-app attribution is still to do.
- prepareImage no longer checks demo: it is local only and the demo photo flow needs it
- Not done, by choice: the brief's "auto-switch to demo when an API call fails". A real farmer would silently get fake advice; the founder switches on purpose instead.

### D-45 [2026-10-16] Visible Demo toggle for the judges' review (replaces D-44's hidden long-press)
- Decided by: user ("a button in home page small at top … we will remove it when we put the app in playstore")
- Small pill switch, top-right on Home and top-left on login. Login is needed too, because when the server is down, login fails and Home is unreachable.
- One switch to remove: SHOW_DEMO_TOGGLE in src/features/demo/demo-toggle.tsx (set false before the Play Store build)

### D-12 [2026-10-02] Shop data: option (b) — resolves OQ-6
- Decided by: Kuldeep, via the note the user forwarded
- Keep distance and sorting only for shops with a trustworthy coordinate (unique and inside Chhattisgarh)
  - ⚠ The "unique = trustworthy" test was proven wrong in Phase 4; see D-31. The principle (distance only from trusted coordinates) still holds.
- For all other shops, Directions opens a Google Maps search on name + address
- Drop non-shop rows; hide Call when there is no phone
- To implement in Phase 1 step 5 (seed) or Phase 4

### D-13 [2026-10-02] CLAUDE.md = exact TRD §10 content + appended project-specific section
- Decided by: agent
- Reason: the TRD text alone would let a future session break D-6, D-10 and D-11, the secrets handling, or the proxy workaround
- The TRD block itself is unchanged

### D-14 [2026-10-02] Corporate TLS interception handled with a CA bundle; Gen AI block not bypassed
- Decided by: agent
- Zscaler re-signs HTTPS with "Shell Private Type 1 Root CA". macOS trusts it; the Supabase CLI runtime does not.
- Fix: ~/.certs/ca-bundle-with-shell.pem (system roots + public Shell CA certs from the System keychain). Use SSL_CERT_FILE / NODE_EXTRA_CA_CERTS for CLI commands only.
- Gemini and Sarvam are blocked from this laptop by policy ("Gen AI Block"). Deliberately not circumvented. They are tested only through deployed Edge Functions, which is also the TRD §6 architecture.
- Consequence: Edge Functions that call Gemini or Sarvam cannot be run locally; deploy and invoke remotely instead

### D-15 [2026-10-02] Template adjustments in Phase 0
- Decided by: agent
- JS `Tabs` instead of `unstable-native-tabs` (unstable API)
- web.output `single` instead of `static` (static pre-render breaks the AsyncStorage session)
- Removed use-color-scheme.web.ts (static-render hydration helper; failed lint)
- Removed the splash `preventAutoHideAsync` along with the template's animated overlay that used to hide it
- Did not apply `npm audit fix --force`: 16 findings (4 high: node-forge etc.) are in Expo tooling dependencies; forcing would break Expo's pinned versions. Review again before release.

## Open questions (must be answered by the user; do not guess)

### OQ-1 Document version mismatch — BLOCKING
The Working Instructions cite sections that are missing from the supplied PDFs:
- Vision Brief: §2.1, §2.2, §3.11–3.17, §11.4
- TRD: §2A, case_status, audit_events, §6.7, §6.8, data retention, §10A
- Implementation Plan: §2A, Phase 12

Options:
- (a) Supply the newer PDFs
- (b) Cut the Working Instructions back to v1

### OQ-2 Demo Mode offline voice
Implementation Plan Phase 9 requires every feature to work in airplane mode. The Bolo voice uses the Sarvam API over the network.
Likely fix: bundle pre-generated demo audio. Needs confirmation.

### OQ-3 IVR / phone-call channel
Required by Vision Brief §3.2, and `diagnoses.channel` allows 'ivr'. But neither the TRD nor the Implementation Plan says how to build it.
Is it in scope for V1?

### OQ-4 Shop dataset timing
Implementation Plan Phase 4 says the dataset is seeded in Phase 0. It is actually seeded in Phase 1, step 5.
Minor; confirm Phase 1.

### OQ-5 Overlap between memory systems
The Working Instructions §6 require `decisions.md` and `flow.md` at the project root. The master prompt requires /project_memory/DECISIONS.md and related files.

Options:
- (a) Keep both; root files point to project_memory
- (b) Keep only project_memory and add a FLOW section to ARCHITECTURE.md
- (c) Keep only the root files

No choice made yet.
- **RESOLVED 2026-09-29 22:47 by user: (a) keep both.** /project_memory/ is the full historian record. The root decisions.md and flow.md (required by Working Instructions §6) are created in Phase 0. The root decisions.md holds the per-session closing summary and points to /project_memory/DECISIONS.md, so decisions are not maintained in two places. flow.md holds the execution flow.

### OQ-6 Shop coordinates are unreliable — RESOLVED by D-12 (option b)
Profile of the 1,186 rows:
- 937 rows share a coordinate with other rows (only 492 unique coordinates)
- 147 rows are outside Chhattisgarh
- 60% have no phone number
- Some rows are not agri shops

With the data as it is, both "2.6 km away" and the Directions pin would often be wrong in front of judges.

Options:
- (a) Re-geocode each address using a geocoding service, run once as an offline script. Needs a provider and key, and must follow its usage policy.
- (b) Keep only the rows with a unique coordinate inside Chhattisgarh. Directions use a Google Maps search on name + address instead of the coordinates.
- (c) Ask Kuldeep for a corrected file.

In every option: drop non-shop rows, hide the Call button when there is no phone, and ship the cleaned file as src/data/shops.json. The file must stay reloadable without an app rebuild (Vision Brief §6).

### OQ-7 Supabase CLI access token — RESOLVED 2026-10-02 (sbp_ token received in ~/Downloads/Achi.txt; read by scripts/load_secrets.py)
The credentials include the DB password and project API keys but no personal access token (`sbp_…`). The CLI needs one for link / secrets set / functions deploy / config push.
- The DB password alone covers `db push` via --db-url, but not Edge Functions or secrets
- Ask Kuldeep to generate an `sbp_` token

### OQ-8 Which Gemini model for diagnosis — RESOLVED 2026-10-03 by D-21
The key can see gemini-2.5-flash, gemini-flash-latest, gemini-3.x-flash and up to gemini-3.8-flash. The TRD says "Flash tier, current generation".
- Pin a specific version for reproducibility rather than the `-latest` alias
- Choose after a quick accuracy and latency test on real leaf photos

### OQ-9 Supabase region is Tokyo (ap-northeast-1), not Mumbai
This adds round-trip latency from Chhattisgarh. It probably doesn't matter for the 10 s target, since Gemini time dominates. Changing region means a new project. Flag only; measure in Phase 2.
- **Measured 2026-10-03:** with the D-22 design, end to end is 3.4–6.0 s from this laptop, comfortably under 10 s. No region change needed for the MVP.
