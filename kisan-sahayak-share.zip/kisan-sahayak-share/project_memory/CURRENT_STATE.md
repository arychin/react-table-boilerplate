# Current State

Snapshot as of: 2026-10-07 20:11 — **MVP items 1–4, 7–10 done (Phases 0–6 + in-app follow-up loop); phone checks pending (user deferred); Gemini had a Google-side outage at the end of the session**

## Goal
MVP for DST i-TBI GGV Bilaspur: a live phone demo, video and deck (D-4). Follow all 4 docs in docs/ with freedom to improve (D-17). Local only; no git until the MVP is done (D-11).

## What exists
- **App** (`poc/`): Expo SDK 57, RN 0.86.3, React 19.2.3, TS 6.0.3 strict, Expo Router with root `src/app`
  - Auth: sign-in (phone) → verify (OTP) → (tabs), with Stack.Protected guards
  - Home: "crop problem?" card with camera and gallery buttons, plus photo tips (3 taps to result)
  - diagnosis/camera: resize to 1280 px JPEG → diagnose-crop (one request) → progress stages → retry on error
  - diagnosis/[id]: photo (local, or signed URL), crop, disease, badges, **Bolo button (🔊 Hindi voice + summary text)**, low-confidence banner, Should-I-Spray verdict + reason + confirm line, cause, treatment, dose-by-label note, steps, prevention, organic option, AI disclaimer
  - History: past crop diagnoses from the server with verdict icons → result
  - Home (Phase 5): weather card (OpenWeather via the `weather` function; plain-rule advice) + crop card + soil card
  - Soil (Phase 5): same photo flow with kind=soil → SoilResult (photo-estimate note, fertilisers without amounts, Bolo, shops titled with the fertiliser); History lists soil
  - Home: follow-up check-in card when a crop follow-up is due (D-37) → follow-up-answer function → loop_completed
  - Advice tab (Phase 6): Agri Expert chat (`chat` function), saved history, quick chips, retry state; no doses (D-36)
  - Shops tab (Phase 4): search + list; located shops ≤ 50 km by distance + the farmer's district; Call / Directions; works without network
  - Result screen: "nearby shops" (top 3) when treatment applies
  - Advice tab is still a placeholder (Phase 6); settings/account as in Phase 1
  - lib: supabase.ts, demo-mode.ts, haversine.ts (the only one). features: auth/*, diagnosis/{api, pick-image, photo-tips}, voice/{api, bolo-button}, shops/{find-shops, use-nearby-shops, shop-card, nearby-shops}
  - diagnoseCrop retries once automatically on 503 (D-28)
  - data/shops.json: 793 shops, 151 with Nominatim-verified coordinates (D-31); 5 from OpenStreetMap
- **Native**: expo-dev-client, expo-audio (no mic, no background), expo-asset, expo-location (when-in-use only); .easignore. EAS dev build 805756e5 predates expo-location → a new build is needed
- **Supabase** (vbexwxzfmjjollhwpaop; DB in Tokyo, functions served from ap-south-1 Mumbai)
  - Migrations:
    - 20261003004500: schema + RLS
    - 20261003020000: private bucket diagnosis-images
    - 20261003030000: no client image writes
    - 20261006213000: private bucket bolo-audio (2 MB, mp3; own-folder SELECT only)
  - Edge Functions (verify_jwt=true): diagnose-crop v15+, bolo v8+. Shared modules: _shared/{gemini, http, diagnosis, bolo}.ts
  - Gemini: gemini-3.5-flash-lite, hedged with 3.1-flash-lite after 3.5 s, 9 s overall deadline (D-28)
  - Sarvam: bulbul:v3, speaker priya, mp3, pace 0.9 (D-26)
  - Writes per diagnosis: diagnoses row; then in the background follow_ups (+3 d), engagement_events, Hindi summary + cached MP3
  - Auth: phone on, email off, 2 test numbers. Secrets: GEMINI, SARVAM, OPENWEATHER.
- **Scripts**: load_secrets.py, clean_shops.py (+ plus_codes.py, data/osm_shops.json, data/nominatim_cache.json), check_phase1_rls.mjs, check_phase2_diagnose.mjs, check_phase3_bolo.mjs, check_phase3_tts_failure.mjs, measure_diagnose_latency.mjs, reset_test_farmers.mjs
- **test-assets/**: 5 CC-licensed photos + a PNG copy + ATTRIBUTION.txt (testing only, not bundled)

## How modules connect
```
Home → pick-image → diagnosis/camera → api.prepareImage (1280 px JPEG) → api.diagnoseCrop (retry once on 503)
  → POST diagnose-crop (bytes; JWT verified by gateway)
      → sniff MIME → rate check → [Storage upload ∥ gemini.generate (hedged, 9 s)] → enforceSafety → insert → respond
      → waitUntil: follow_ups + engagement_events ; waitUntil: bolo.prepareBolo (summary → Sarvam → bolo-audio)
  → /diagnosis/[id] → BoloButton → voice/api.fetchBolo → POST bolo
      → own diagnosis? → cached MP3? (waits up to 25 s for the background job on new diagnoses) → signed URL (600 s)
      → else prepareBolo on demand
  → expo-audio player: tap play / tap stop
History → api.listDiagnoses (RLS) → /diagnosis/[id]
Shops tab / NearbyShops → shops/use-nearby-shops (expo-location; profile district cached) → shops/find-shops (bundled shops.json + lib/haversine) — no network
```

## Stable (verified with real output 2026-10-06)
- tsc 0; lint 0; deno check (diagnose-crop, bolo) 0; expo-doctor 21/21
- Android bundle HTTP 200; secret scan 0/6; no speechSynthesis; no direct Sarvam/Gemini calls from the app
- check_phase1_rls: pass. check_phase2_diagnose: pass. check_phase3_bolo: pass (all three back to back from a clean state).
  - Bolo for treat / healthy / unsure photos: correct Hindi summaries, valid MP3s
  - replay cached; B gets 404; no client writes; anon 401
- check_phase3_tts_failure: with Sarvam broken the diagnosis still succeeds and bolo returns 503; it recovers once the key is restored
- measure_diagnose_latency (18 runs as the app makes them): 18/18 OK, median 4.1 s, p90 7.7 s, 1 over 10 s (D-28)
- Browser end to end: result → Bolo ready about 6–7 s later → tap plays (21 ms) → tap stops; History reopen → voice ready in 2.0 s
- 2026-10-07 Phase 4: tsc 0, lint 0; scenario check on real code; browser with simulated Durg GPS
  - Shops tab, search, denied permission, Directions/Call URLs, and nearby shops on a real diagnosis all work
  - Bundle: no real secrets, OSM credit present

## Experimental / unverified
- **Physical Android phone:** camera capture, Bolo through the phone speaker, real network speed, Shops with real GPS + airplane mode (needs a new EAS dev build)
- Real SMS OTP and auto-fill (D-18)
- Diagnosis accuracy on real Chhattisgarh field photos (only 5 Wikimedia photos tested)

## Known limitations
- About 1 in 20 diagnoses exceeds TRD §9's 10 s because of upstream Gemini stalls (bounded, retried; D-28). Demo Mode avoids this for the pitch.
- Zscaler blocks Gemini, Sarvam and their docs from the laptop (D-14); test only via deployed functions or probes
- The full Flash models returned 503 "high demand"; we rely on flash-lite (D-21)
- Tab icons are placeholders; tab labels slightly clipped on web (design pass)
- Only 151 of 793 shops have a verified location; the rest show "Distance unknown" and get Directions by name + address (D-12, D-31). Open sources for more shops are exhausted; the official dealer list needs the agriculture office or a KVK.
- If a farmer's profile district is unset and no located shop is within 50 km, the Shops tab lists nothing until they search
- 16 npm audit findings in Expo tooling (D-15); `npm test` not configured

## Current phase
Phase 6, the in-app follow-up loop, the Savings Tracker (D-40), the Calculator (D-41), the Daily Action Feed (D-42) and Demo Mode (D-44) are done. Keep-alive cron added (D-43); confirm after 7 days that the project stays active. Phone testing deferred by the user. Open: offline message for a signed-in app when the backend is unreachable (live mode); in-app photo attribution for the demo images; Phase 10 polish.
