// One place for Gemini calls (TRD §6.1): pinned models with fallback, used by diagnose-crop and bolo.

// Pinned after a measured benchmark (D-21); the fallback absorbs "high demand" 503s.
export const MODELS = ['gemini-3.5-flash-lite', 'gemini-3.1-flash-lite'];

type GenerateBody = {
  systemInstruction: { parts: { text: string }[] };
  contents: unknown[];
  generationConfig: Record<string, unknown>;
};

async function generateOnce(apiKey: string, model: string, body: GenerateBody, timeoutMs: number): Promise<string> {
  const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-goog-api-key': apiKey },
    signal: AbortSignal.timeout(timeoutMs),
    body: JSON.stringify(body),
  });
  const json = await res.json();
  if (!res.ok) throw new Error(`gemini ${res.status}: ${json?.error?.message ?? 'unknown error'}`);
  const text: string | undefined = json?.candidates?.[0]?.content?.parts?.find((p: { text?: string }) => p.text)?.text;
  if (!text) throw new Error(`gemini returned no content (finishReason=${json?.candidates?.[0]?.finishReason})`);
  return text;
}

/**
 * Hedged call across the pinned models, under one overall deadline (D-28). If a model hasn't answered within
 * hedgeMs (or fails), the next one starts in parallel and the first success wins. Measured: primary answers in
 * ~2.5 s, but rare upstream stalls made a sequential 12 s timeout cost 17–18 s end to end.
 */
export function generate(body: GenerateBody, deadlineMs = 9_000, hedgeMs = 3_500): Promise<{ text: string; model: string }> {
  const apiKey = Deno.env.get('GEMINI_API_KEY') ?? '';
  const started = Date.now();
  return new Promise((resolve, reject) => {
    let settled = false;
    let launched = 0;
    let failed = 0;
    const finish = (fn: () => void) => {
      if (settled) return;
      settled = true;
      clearTimeout(deadline);
      fn();
    };
    const deadline = setTimeout(() => finish(() => reject(new Error(`gemini: no answer within ${deadlineMs} ms`))), deadlineMs);
    const launch = () => {
      if (settled || launched >= MODELS.length) return;
      const model = MODELS[launched++];
      const hedge = setTimeout(launch, hedgeMs);
      generateOnce(apiKey, model, body, Math.max(1_000, deadlineMs - (Date.now() - started)))
        .then((text) => {
          clearTimeout(hedge);
          finish(() => resolve({ text, model }));
        })
        .catch((e) => {
          clearTimeout(hedge);
          console.warn(`gemini: ${model} failed: ${String(e).slice(0, 200)}`);
          if (++failed === MODELS.length) finish(() => reject(e));
          else launch();
        });
    };
    launch();
  });
}
