-- MVP follow-up loop (Vision Brief §3.3 "did you apply the treatment, and is it getting better?").
-- TRD §5.3 has no column for the first half of that question; null = not asked (healthy plant / unclear photo).
alter table public.follow_ups add column treatment_applied boolean;
