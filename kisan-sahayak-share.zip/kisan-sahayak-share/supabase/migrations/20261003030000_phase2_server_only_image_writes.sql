-- Phase 2b: only diagnose-crop (service role) writes images now, so the stored photo is exactly the one diagnosed.
-- Farmers keep read access to their own folder for short-lived signed URLs.
drop policy if exists "diagnosis-images: upload own folder" on storage.objects;
