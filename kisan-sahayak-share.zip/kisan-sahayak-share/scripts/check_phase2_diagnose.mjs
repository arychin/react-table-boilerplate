// Phase 2 server check, using only the anon key + a test-number login (exactly what the app has).
// Run: node --env-file=.env scripts/check_phase2_diagnose.mjs [region]   (region e.g. ap-northeast-1; default: any)
import { Buffer } from 'node:buffer';
import { readFileSync } from 'node:fs';
import { createClient } from '@supabase/supabase-js';

const url = process.env.EXPO_PUBLIC_SUPABASE_URL;
const anonKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY;
const region = process.argv[2];
let failures = 0;
const check = (label, ok, detail = '') => {
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${label}${detail ? `  (${detail})` : ''}`);
  if (!ok) failures += 1;
};

async function login(phone, otp) {
  const client = createClient(url, anonKey, { auth: { persistSession: false } });
  await client.auth.signInWithOtp({ phone });
  const { data } = await client.auth.verifyOtp({ phone, token: otp, type: 'sms' });
  return { client, id: data.user.id, token: data.session.access_token };
}

// Exactly how the app calls it: raw image bytes + language header.
async function diagnose(client, bytes, contentType, language = 'hi') {
  const started = Date.now();
  const { data, error } = await client.functions.invoke('diagnose-crop', {
    body: bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength),
    headers: { 'Content-Type': contentType, 'x-ks-language': language },
    ...(region ? { region } : {}),
  });
  return { data, error, status: error?.context?.status, totalMs: Date.now() - started };
}

const a = await login('+919000000001', '246810');
const b = await login('+919000000002', '135790');
console.log(`region=${region ?? 'any'}`);

const cases = [['test-assets/tomato_early_blight.jpg', 'image/jpeg'], ['test-assets/tomato_early_blight.png', 'image/png']];
if (process.env.KS_RESIZED) cases.push([process.env.KS_RESIZED, 'image/jpeg']);
for (const [file, type] of cases) {
  const r = await diagnose(a.client, new Uint8Array(readFileSync(file)), type);
  const d = r.data?.diagnosis;
  check(`${file.split('/').pop()} diagnosed`, !!r.data?.id, r.error?.message);
  if (!d) continue;
  check('  under 10 s end to end', r.totalMs < 10_000, `total ${r.totalMs} ms, server ${JSON.stringify(r.data.timings_ms)}`);
  check('  has every TRD §6.1 required field',
    ['disease_name', 'cause', 'severity', 'treatment', 'treatment_steps', 'confidence'].every((k) => d[k] !== undefined));
  console.log(`      → ${d.crop_name} | ${d.disease_name} | conf=${d.confidence} spray=${d.spray_decision} | model=${r.data.model}`);

  const row = await a.client.from('diagnoses').select('image_url, channel').eq('id', r.data.id).single();
  check('  row readable by owner, path in own folder', row.data?.image_url === r.data.image_path && r.data.image_path.startsWith(`${a.id}/`));
  const ext = { 'image/jpeg': '.jpg', 'image/png': '.png' }[type];
  check('  stored with the sniffed type', r.data.image_path.endsWith(ext), r.data.image_path.split('/')[1]);
  const signed = await a.client.storage.from('diagnosis-images').createSignedUrl(r.data.image_path, 600);
  check('  owner gets a signed URL', !!signed.data?.signedUrl);
  await new Promise((res) => setTimeout(res, 1500)); // side records are written after the response
  const fu = await a.client.from('follow_ups').select('scheduled_for, status').eq('diagnosis_id', r.data.id).single();
  const days = fu.data ? (new Date(fu.data.scheduled_for) - Date.now()) / 86400_000 : 0;
  check('  follow-up scheduled ~3 days', fu.data?.status === 'pending' && days > 2.9 && days < 3.1, `${days.toFixed(2)} d`);
  const ev = await a.client.from('engagement_events').select('event_type').eq('diagnosis_id', r.data.id);
  check('  diagnosis_completed logged', ev.data?.[0]?.event_type === 'diagnosis_completed');

  if (type === 'image/jpeg' && file.startsWith('test-assets')) {
    const bRow = await b.client.from('diagnoses').select('id').eq('id', r.data.id);
    check('B cannot read A diagnosis', (bRow.data ?? []).length === 0);
    const bImg = await b.client.storage.from('diagnosis-images').createSignedUrl(r.data.image_path, 600);
    check('B cannot get a signed URL for A image', !bImg.data?.signedUrl, bImg.error?.message);
  }
}

// Storage writes are server-only now.
const direct = await a.client.storage.from('diagnosis-images').upload(`${a.id}/direct.jpg`, readFileSync('test-assets/tomato_early_blight.jpg'), { contentType: 'image/jpeg' });
check('farmer cannot upload to Storage directly', !!direct.error, direct.error?.message);

// Auth: anon key alone, and a forged token.
const anon = createClient(url, anonKey, { auth: { persistSession: false } });
const noAuth = await diagnose(anon, new Uint8Array(readFileSync('test-assets/tomato_early_blight.jpg')), 'image/jpeg');
check('anon key alone is rejected', noAuth.status === 401, `status ${noAuth.status}`);
const [h, , s] = a.token.split('.');
const forgedPayload = Buffer.from(JSON.stringify({ sub: b.id, role: 'authenticated', exp: 4102444800 })).toString('base64url');
const forged = await fetch(`${url}/functions/v1/diagnose-crop`, {
  method: 'POST',
  headers: { Authorization: `Bearer ${h}.${forgedPayload}.${s}`, apikey: anonKey, 'Content-Type': 'image/jpeg' },
  body: readFileSync('test-assets/tomato_early_blight.jpg'),
});
check('forged token rejected by the gateway', forged.status === 401, `status ${forged.status}`);

// Not an image: bytes are sniffed, the claimed content type is not trusted.
const fake = await diagnose(a.client, new TextEncoder().encode('not really an image'), 'image/jpeg');
check('non-image bytes rejected (415)', fake.status === 415, `status ${fake.status}`);

console.log(failures === 0 ? '\nALL CHECKS PASSED' : `\n${failures} CHECK(S) FAILED`);
process.exit(failures === 0 ? 0 : 1);
