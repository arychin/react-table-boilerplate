import { useLocalSearchParams } from 'expo-router';
import { useState } from 'react';
import { FlatList, StyleSheet, Text, TextInput, View } from 'react-native';

import { Button } from '@/components/ui/button';
import { MinTouchTarget, Spacing } from '@/constants/theme';
import { useApp } from '@/features/auth/app-context';
import { districtLabel } from '@/features/shops/find-shops';
import { ShopCard } from '@/features/shops/shop-card';
import { useNearbyShops } from '@/features/shops/use-nearby-shops';
import { useTheme } from '@/hooks/use-theme';

// Plan Phase 4 / TRD §6.5: offline shop finder — bundled data + on-device distance, no network.
export default function ShopsScreen() {
  const { t, language } = useApp();
  const theme = useTheme();
  const [query, setQuery] = useState('');
  const { product } = useLocalSearchParams<{ product?: string }>();
  const { shops, area, location } = useNearbyShops(true, query);

  const locationNote = {
    locating: t.shopsLocating,
    ready: null,
    'needs-permission': null,
    denied: t.shopsDenied,
    unavailable: t.shopsUnavailable,
  }[location.status];
  const heading = query.trim() ? t.shopsFound(shops.length) : area ? t.shopsArea(districtLabel(area, language)) : null;

  return (
    <FlatList
      style={{ backgroundColor: theme.background }}
      contentContainerStyle={styles.content}
      data={shops}
      keyExtractor={(s) => s.id}
      renderItem={({ item }) => <ShopCard shop={item} />}
      keyboardShouldPersistTaps="handled"
      ListHeaderComponent={
        <View style={styles.header}>
          {!!product && (
            <View style={[styles.product, { backgroundColor: theme.successBg }]}>
              <Text style={[styles.productText, { color: theme.primary }]}>🛍️ {t.askFor(product)}</Text>
            </View>
          )}
          <TextInput
            value={query}
            onChangeText={setQuery}
            placeholder={t.shopsSearch}
            placeholderTextColor={theme.textSecondary}
            accessibilityLabel={t.shopsSearch}
            autoCorrect={false}
            clearButtonMode="while-editing"
            style={[styles.search, { color: theme.text, borderColor: theme.border, backgroundColor: theme.backgroundElement }]}
          />
          {locationNote && <Text style={[styles.note, { color: theme.textSecondary }]}>{locationNote}</Text>}
          {(location.status === 'needs-permission' || location.status === 'unavailable') && (
            <Button label={t.shopsUseLocation} variant="secondary" onPress={location.locate} />
          )}
          {heading && <Text style={[styles.heading, { color: theme.text }]}>{heading}</Text>}
        </View>
      }
      ListEmptyComponent={
        location.status === 'locating' ? null : (
          <Text style={[styles.note, { color: theme.textSecondary }]}>{query.trim() ? t.shopsNone : t.shopsNoArea}</Text>
        )
      }
    />
  );
}

const styles = StyleSheet.create({
  content: { padding: Spacing.three, gap: Spacing.three, paddingBottom: Spacing.six },
  header: { gap: Spacing.two },
  search: { minHeight: MinTouchTarget, borderWidth: 1.5, borderRadius: Spacing.three, paddingHorizontal: Spacing.three, fontSize: 18 },
  note: { fontSize: 16, lineHeight: 23 },
  heading: { fontSize: 18, fontWeight: '800', marginTop: Spacing.one },
  product: { borderRadius: Spacing.three, padding: Spacing.three },
  productText: { fontSize: 17, fontWeight: '700' },
});
