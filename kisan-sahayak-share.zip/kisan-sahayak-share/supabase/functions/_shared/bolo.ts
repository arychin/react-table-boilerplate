// Bolo (Vision Brief §3.8): a separate 2–3 sentence Hindi summary (TRD §6.1) spoken by Sarvam Bulbul v3 (TRD §6.2).
import type { SupabaseClient } from 'npm:@supabase/supabase-js@2';

import type { Diagnosis } from './diagnosis.ts';
import { generate } from './gemini.ts';
import type { SoilReport } from './soil.ts';

export type Kind = 'crop' | 'soil';

// TRD §6.2 asked to confirm the voice before locking: 'anushka' is not a bulbul:v3 speaker; user chose 'priya' (D-26).
const SPEAKER = 'priya';

const VOICE_RULES = `1. Exactly 2 or 3 short sentences in simple, everyday spoken Hindi, written in Devanagari. Speak to the farmer directly.
2. No English words, no scientific names, no brackets, no numbers, no lists, no markdown. Write product names in Devanagari.
3. NEVER mention any dose, quantity, concentration or amount.`;

const SUMMARY_INSTRUCTION: Record<Kind, string> = {
  crop: `You write the short Hindi voice message that the Kisan Sahayak app reads aloud to a farmer in Chhattisgarh, India.
You are given the app's diagnosis of the farmer's crop photo as JSON. Rules — follow all of them:
${VOICE_RULES}
4. One problem, one fix: say what the problem is and the single most important thing to do.
5. If confidence is "low": do not name any disease as certain. Say the photo was not clear enough and ask for a sharp close-up of the sick leaf in daylight, or to show the plant at the nearest कृषि केंद्र.
6. If spray_decision is "not_needed": say no medicine is needed right now and what to keep an eye on.
7. If spray_decision is "wait_and_watch" or "spray_recommended": the last sentence must ask the farmer to confirm with their कृषि केंद्र or dealer before spraying.
Return only the sentences.`,
  soil: `You write the short Hindi voice message that the Kisan Sahayak app reads aloud to a farmer in Chhattisgarh, India.
You are given the app's reading of the farmer's soil photo as JSON. Rules — follow all of them:
${VOICE_RULES}
4. Say the soil type and how wet or dry it looks, then the single most useful thing to do (usually the first fertiliser or tip).
5. The last sentence must say this is only a guess from a photo, and that a मिट्टी जाँच (सॉयल हेल्थ कार्ड) at the nearest कृषि केंद्र gives the exact amounts.
6. If confidence is "low": do not describe the soil. Say the photo was not clear and ask for a close photo of bare soil in daylight.
Return only the sentences.`,
};

/** Separate Gemini call; failure here never affects the stored diagnosis. */
export async function generateHindiSummary(kind: Kind, result: Diagnosis | SoilReport): Promise<string> {
  const ask = async (extra = '') => {
    const { text } = await generate({
      systemInstruction: { parts: [{ text: SUMMARY_INSTRUCTION[kind] + extra }] },
      contents: [{ role: 'user', parts: [{ text: JSON.stringify(result) }] }],
      generationConfig: { temperature: 0.3, responseMimeType: 'text/plain', maxOutputTokens: 400 },
    });
    // TTS reads stray brackets/markdown aloud; strip any that slipped through rule 3.
    return text.replace(/\([^)]*\)|\[[^\]]*\]|[*_#`]/g, ' ').replace(/\s+/g, ' ').trim();
  };
  let summary = await ask();
  // Seen in testing: "नजदीki" — Latin glued into a Hindi word, which TTS mispronounces. Ask once more, then strip.
  if (/[A-Za-z]/.test(summary)) summary = await ask('\nIMPORTANT: your previous answer mixed in Latin letters. Write every word entirely in Devanagari.');
  summary = summary.replace(/[A-Za-z]+/g, '').replace(/\s+([।,?!])/g, '$1').replace(/\s+/g, ' ').trim();
  if (!summary) throw new Error('empty summary');
  return summary.slice(0, 600);
}

/** Sarvam returns base64 audio (TRD §6.2) — decoded here before it is stored. MP3 is ~2.5× smaller than WAV (D-26). */
export async function synthesizeHindi(text: string): Promise<Uint8Array> {
  const res = await fetch('https://api.sarvam.ai/text-to-speech', {
    method: 'POST',
    headers: { 'api-subscription-key': Deno.env.get('SARVAM_API_KEY') ?? '', 'Content-Type': 'application/json' },
    signal: AbortSignal.timeout(15_000),
    body: JSON.stringify({
      text,
      target_language_code: 'hi-IN',
      speaker: SPEAKER,
      model: 'bulbul:v3',
      pace: 0.9,
      output_audio_codec: 'mp3',
    }),
  });
  const body = await res.json().catch(() => null);
  const audio: string | undefined = body?.audios?.[0];
  if (!res.ok || !audio) throw new Error(`sarvam ${res.status}: ${body?.error?.message ?? 'no audio'}`);
  return Uint8Array.from(atob(audio), (c) => c.charCodeAt(0));
}

export const BOLO_BUCKET = 'bolo-audio';
export const boloPath = (farmerId: string, diagnosisId: string) => `${farmerId}/${diagnosisId}.mp3`;

/**
 * Generates the summary (if not saved yet) and the speech, and caches the MP3 against the diagnosis id.
 * Used by diagnose-crop (background, right after the result) and by bolo (on demand).
 */
export async function prepareBolo(
  admin: SupabaseClient,
  farmerId: string,
  diagnosisId: string,
  kind: Kind,
  result: Diagnosis | SoilReport,
  savedSummary: string | null,
): Promise<string> {
  let summary = savedSummary;
  if (!summary) {
    summary = await generateHindiSummary(kind, result);
    await admin.from('diagnoses').update({ hindi_summary: summary }).eq('id', diagnosisId);
  }
  const audio = await synthesizeHindi(summary);
  const { error } = await admin.storage.from(BOLO_BUCKET).upload(boloPath(farmerId, diagnosisId), audio, { contentType: 'audio/mpeg' });
  // A parallel request may have stored it first — that copy is just as good.
  if (error && !/exists|duplicate/i.test(error.message)) throw new Error(`store: ${error.message}`);
  return summary;
}
