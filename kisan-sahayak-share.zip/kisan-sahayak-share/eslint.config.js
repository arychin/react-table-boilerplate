// https://docs.expo.dev/guides/using-eslint/
const { defineConfig } = require('eslint/config');
const expoConfig = require("eslint-config-expo/flat");

module.exports = defineConfig([
  expoConfig,
  {
    // supabase/functions is Deno code (jsr:/npm: imports), checked with `deno check` instead.
    ignores: ["dist/*", ".expo/*", "supabase/functions/**"],
  }
]);
