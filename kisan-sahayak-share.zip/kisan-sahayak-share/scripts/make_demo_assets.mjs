// One-time generator for Demo Mode content (Phase 9, D-44). Uses the REAL pipeline so the demo is authentic:
// - tomato: real diagnose-crop (hi + en) on test-assets/tomato_early_blight.jpg, real Bolo (Sarvam) audio
// - soil: the Vision Brief's Sandy Loam report (hand-written, D-33 rules), voiced by the real Bolo function
// Writes assets/demo/bolo_*.mp3 and /tmp/ks_demo_raw.json. Run, then reset the test farmers.
// Run: eval "$(python3 scripts/load_secrets.py --with-service-role)" && node --env-file=.env scripts/make_demo_assets.mjs
import { createClient } from '@supabase/supabase-js';
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';

const url = process.env.EXPO_PUBLIC_SUPABASE_URL;
const anon = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY;
const service = process.env.SUPABASE_SERVICE_ROLE_KEY;
if (!service) throw new Error('needs --with-service-role (soil row insert)');

const SOIL_HI = {
  soil_type: 'बलुई दोमट (Sandy Loam)',
  moisture: 'low',
  confidence: 'medium',
  observations: 'मिट्टी हल्के भूरे-लाल रंग की, भुरभुरी और दानेदार दिख रही है — रेत ज़्यादा, चिकनी मिट्टी कम। सतह सूखी है और सड़ी पत्तियाँ या गोबर जैसी जैविक चीज़ें कम दिख रही हैं।',
  possible_deficiencies: ['नाइट्रोजन — हल्का रंग और कम जैविक पदार्थ', 'पोटाश — रेतीली मिट्टी पोषक तत्व कम रोक पाती है'],
  fertilisers: [
    { name: 'NPK 19:19:19 (पानी में घुलने वाली खाद)', why: 'तीनों मुख्य पोषक तत्व बराबर; रेतीली मिट्टी में एक साथ ज़्यादा देने के बजाय कई बार थोड़ा देने के लिए ठीक' },
    { name: 'गोबर की सड़ी खाद / वर्मी कम्पोस्ट', why: 'मिट्टी की पानी और पोषक रोकने की ताक़त बढ़ाती है' },
  ],
  improvement_tips: ['खेत में सड़ी गोबर खाद या हरी खाद मिलाएँ', 'कम पानी से, पर ज़्यादा बार सिंचाई करें', 'पुआल या सूखी पत्तियों से मल्चिंग करें — नमी बचेगी'],
};

const client = createClient(url, anon, { auth: { persistSession: false } });
await client.auth.signInWithOtp({ phone: '+919000000001' });
const { data: auth } = await client.auth.verifyOtp({ phone: '+919000000001', token: '246810', type: 'sms' });
const token = auth.session.access_token;
const farmerId = auth.user.id;

async function diagnose(language) {
  const res = await fetch(`${url}/functions/v1/diagnose-crop`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}`, apikey: anon, 'Content-Type': 'image/jpeg', 'x-ks-language': language, 'x-ks-kind': 'crop' },
    body: readFileSync('test-assets/tomato_early_blight.jpg'),
  });
  if (!res.ok) throw new Error(`diagnose ${language}: ${res.status} ${await res.text()}`);
  return res.json();
}

async function bolo(diagnosisId, file) {
  for (let i = 0; i < 4; i++) {
    const { data, error } = await client.functions.invoke('bolo', { body: { diagnosis_id: diagnosisId } });
    if (data?.url) {
      const mp3 = Buffer.from(await (await fetch(data.url)).arrayBuffer());
      writeFileSync(`assets/demo/${file}`, mp3);
      console.log(`${file}: ${mp3.length} bytes`);
      return data.summary;
    }
    console.log(`bolo attempt ${i + 1}: ${error?.context?.status ?? error}`);
    await new Promise((r) => setTimeout(r, 5000));
  }
  throw new Error('bolo failed');
}

mkdirSync('assets/demo', { recursive: true });
const admin = createClient(url, service, { auth: { persistSession: false } });

if (process.argv.includes('--rice')) {
  // Healthy paddy check (src/features/demo/data.ts DEMO_RICE.hi), voiced by the real Bolo function.
  const RICE_HI = {
    crop_name: 'धान (Rice)',
    disease_name: 'स्वस्थ फसल — कोई रोग नहीं दिखा',
    cause: 'पत्तियाँ हरी और साफ़ हैं; किसी कीट या रोग का निशान नहीं दिखा।',
    severity: 'low',
    confidence: 'high',
    spray_decision: 'not_needed',
    decision_reason: 'कोई धब्बा, छेद या पीलापन नहीं — अभी दवा की ज़रूरत नहीं। पैसा बचाएँ और हर 3–5 दिन में खेत देखते रहें।',
    treatment: 'अभी कोई इलाज ज़रूरी नहीं',
    treatment_steps: ['हर 3–5 दिन में खेत की 5 जगह पौधे देखें।', 'कोई नया धब्बा या कीट दिखे तो फिर से फोटो लें।'],
    prevention_tips: ['यूरिया सिफ़ारिश से ज़्यादा न डालें — ज़्यादा नाइट्रोजन से माहू बढ़ता है।', 'मेड़ और खेत के आसपास खरपतवार साफ़ रखें।'],
  };
  const { data: row, error } = await admin.from('diagnoses').insert({ farmer_id: farmerId, type: 'crop', image_url: 'demo/rice.jpg', diagnosis_json: RICE_HI }).select('id').single();
  if (error) throw error;
  const summary = await bolo(row.id, 'bolo_rice.mp3');
  writeFileSync('/tmp/ks_demo_rice.json', JSON.stringify({ rice_summary: summary }, null, 2));
  console.log('rice summary:', summary);
  process.exit(0);
}

const hi = await diagnose('hi');
console.log('hi diagnosis', hi.id);
const en = await diagnose('en');
console.log('en diagnosis', en.id);

const { data: soilRow, error: soilErr } = await admin
  .from('diagnoses')
  .insert({ farmer_id: farmerId, type: 'soil', image_url: 'demo/soil.jpg', diagnosis_json: SOIL_HI })
  .select('id')
  .single();
if (soilErr) throw soilErr;

const tomatoSummary = await bolo(hi.id, 'bolo_tomato.mp3');
const soilSummary = await bolo(soilRow.id, 'bolo_soil.mp3');

writeFileSync('/tmp/ks_demo_raw.json', JSON.stringify({ tomato_hi: hi.diagnosis, tomato_en: en.diagnosis, tomato_summary: tomatoSummary, soil_hi: SOIL_HI, soil_summary: soilSummary }, null, 2));
console.log('wrote /tmp/ks_demo_raw.json');
