// Phase 5 server check (soil + weather), using only the anon key + test-number logins (exactly what the app has).
// Run: node --env-file=.env scripts/check_phase5_soil_weather.mjs
import { createClient } from '@supabase/supabase-js';
import { readFileSync } from 'node:fs';

const url = process.env.EXPO_PUBLIC_SUPABASE_URL;
const anonKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY;
let failures = 0;
const check = (label, ok, detail = '') => {
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${label}${detail ? `  (${detail})` : ''}`);
  if (!ok) failures += 1;
};
// Same dose patterns the Phase 2 benchmark used: numbers next to units/rates.
const DOSE = /\d+\s*(kg|किलो|g\b|ग्राम|ml|मिली|l\b|लीटर|bag|बोरी|%|प्रतिशत)|per\s+(acre|hectare)|प्रति\s+(एकड़|हेक्टेयर)/i;

async function login(phone, otp) {
  const client = createClient(url, anonKey, { auth: { persistSession: false } });
  await client.auth.signInWithOtp({ phone });
  const { data } = await client.auth.verifyOtp({ phone, token: otp, type: 'sms' });
  return { client, id: data.user.id };
}

const a = await login('+919000000001', '246810');
await new Promise((r) => setTimeout(r, 2500)); // Supabase OTP throttle between sends
const b = await login('+919000000002', '135790');

// ---- Soil: exactly how the app calls it (raw bytes + language + kind headers).
const photos = [
  ['soil_red_field.jpg', 'hi', 'clear'],
  ['soil_dry_cracked.jpg', 'en', 'clear'],
  ['soil_black.jpg', 'hi', 'clear'],
  ['soil_red.jpg', 'en', 'mostly a mud hut'],
  ['tomato_early_blight.jpg', 'hi', 'a leaf, not soil'],
];
let soilId = null;
for (const [file, language, note] of photos) {
  const bytes = readFileSync(`test-assets/${file}`);
  const started = Date.now();
  const { data, error } = await a.client.functions.invoke('diagnose-crop', {
    body: bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength),
    headers: { 'Content-Type': 'image/jpeg', 'x-ks-language': language, 'x-ks-kind': 'soil' },
  });
  const ms = Date.now() - started;
  const r = data?.diagnosis;
  check(`${file} (${language}, ${note}) analysed`, !!r, error?.message);
  if (!r) continue;
  console.log(`      → ${r.soil_type} | moisture=${r.moisture} conf=${r.confidence} | ferts=${JSON.stringify(r.fertilisers.map((f) => f.name))} | ${ms} ms`);
  check('  under 10 s end to end', ms < 10_000, `${ms} ms`);
  check('  all required fields', ['soil_type', 'moisture', 'confidence', 'observations', 'possible_deficiencies', 'fertilisers', 'improvement_tips'].every((k) => r[k] !== undefined));
  check('  no dose / amount anywhere', !DOSE.test(JSON.stringify(r)), JSON.stringify(r).match(DOSE)?.[0]);
  if (r.confidence === 'low') check('  low confidence → no products', r.fertilisers.length === 0);
  if (note.startsWith('a leaf')) check('  non-soil photo is marked low confidence', r.confidence === 'low', r.confidence);
  const row = await a.client.from('diagnoses').select('type').eq('id', data.id).single();
  check('  stored as type soil', row.data?.type === 'soil');
  if (file === 'soil_red_field.jpg') soilId = data.id;
}

if (soilId) {
  await new Promise((r) => setTimeout(r, 1500)); // background side records
  const fu = await a.client.from('follow_ups').select('id').eq('diagnosis_id', soilId);
  check('soil creates no crop follow-up', (fu.data ?? []).length === 0);
  const bRow = await b.client.from('diagnoses').select('id').eq('id', soilId);
  check('B cannot read A soil report', (bRow.data ?? []).length === 0);
  const started = Date.now();
  const { data: bolo, error } = await a.client.functions.invoke('bolo', { body: { diagnosis_id: soilId } });
  check('Bolo for soil returns audio', !!bolo?.url, error?.message);
  console.log(`      → "${bolo?.summary}" (${Date.now() - started} ms, cached=${bolo?.cached})`);
  check('  summary is Devanagari only', !!bolo?.summary && !/[A-Za-z]/.test(bolo.summary));
  if (bolo?.url) {
    const head = new Uint8Array(await (await fetch(bolo.url)).arrayBuffer()).slice(0, 3);
    check('  audio is MP3', (head[0] === 0x49 && head[1] === 0x44 && head[2] === 0x33) || (head[0] === 0xff && (head[1] & 0xe0) === 0xe0));
  }
}

// ---- Crop still works through the same function (no kind header = crop).
const leaf = readFileSync('test-assets/tomato_early_blight.jpg');
const crop = await a.client.functions.invoke('diagnose-crop', {
  body: leaf.buffer.slice(leaf.byteOffset, leaf.byteOffset + leaf.byteLength),
  headers: { 'Content-Type': 'image/jpeg', 'x-ks-language': 'en' },
});
check('crop diagnosis unchanged', !!crop.data?.diagnosis?.spray_decision, crop.error?.message);

// ---- Weather.
for (const [name, lat, lng] of [['Durg', 21.19, 81.28], ['Jagdalpur', 19.08, 82.02]]) {
  const started = Date.now();
  const { data: w, error } = await a.client.functions.invoke('weather', { body: { lat, lng } });
  check(`weather ${name}`, !!w && typeof w.temp_c === 'number', error?.message);
  if (w) console.log(`      → ${JSON.stringify(w)} (${Date.now() - started} ms)`);
  if (w) check('  sane values', w.temp_c > -5 && w.temp_c < 55 && w.humidity >= 0 && w.humidity <= 100 && w.rain_chance >= 0 && w.rain_chance <= 100 && w.wind_kmh >= 0);
}
const outside = await a.client.functions.invoke('weather', { body: { lat: 51.5, lng: -0.12 } });
check('location outside India rejected', outside.error?.context?.status === 400, `status ${outside.error?.context?.status}`);
const anon = createClient(url, anonKey, { auth: { persistSession: false } });
const noAuth = await anon.functions.invoke('weather', { body: { lat: 21.19, lng: 81.28 } });
check('weather: anon key alone is rejected', noAuth.error?.context?.status === 401, `status ${noAuth.error?.context?.status}`);

console.log(failures ? `\n${failures} FAILED` : '\nALL PASS');
process.exit(failures ? 1 : 0);
