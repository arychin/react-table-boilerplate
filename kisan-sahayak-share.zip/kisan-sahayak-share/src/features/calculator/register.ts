import gfrData from '@/data/fertilizer-gfr-cg.json';
import registerData from '@/data/pesticide-register.json';

import type { Range } from './compute';

// D-41: official tables, built by scripts/build_calculator_data.py.
export const CROP_IDS = [
  'rice', 'wheat', 'maize', 'arhar', 'chana', 'moong', 'urad', 'pea', 'soybean', 'groundnut', 'mustard', 'sesame', 'sugarcane', 'cotton',
  'tomato', 'brinjal', 'chilli', 'okra', 'cabbage', 'cauliflower', 'potato', 'onion', 'cucumber', 'bitter_gourd', 'bottle_gourd', 'mango', 'banana',
] as const;
export type CropId = (typeof CROP_IDS)[number];

export type RegisterRow = { crops: CropId[]; crop: string; pest: string; wait: number | null; dose: Range; unit: 'g' | 'ml'; water: Range };
export type Product = { name: string; kind: string; form: string | null; rows: RegisterRow[] };

export const REGISTER_SOURCE = registerData.source;
const PRODUCTS = registerData.products as Product[];

export const rowsFor = (product: Product, crop: CropId) => product.rows.filter((r) => r.crops.includes(crop));

const letters = (s: string) => s.toLowerCase().replace(/[^a-z]/g, '');
const FORM_ALIAS: Record<string, string> = { WDG: 'WG' };

/** "Acetamiprid 25% + Bifenthrin 25 % WG" → ingredient names + strengths, and the formulation code. */
export function parseComposition(text: string): { names: string; key: string; form: string | null } | null {
  const plain = text.replace(/\([^)]*\)/g, ' ');
  const parts = [...plain.matchAll(/([A-Za-z][A-Za-z\- ']*?)\s*(\d+(?:\.\d+)?)\s*%/g)]
    .map((m) => ({ name: letters(m[1]), pct: Number(m[2]) }))
    .filter((p) => p.name)
    .sort((a, b) => a.name.localeCompare(b.name));
  if (!parts.length) return null;
  const codes = plain.toUpperCase().match(/\b[A-Z]{1,3}\b/g) ?? [];
  const code = [...codes].reverse().find((c) => /^(EC|SC|SL|EW|OD|CS|ME|SE|ZC|AS|LF|FS|DC|ZW|WP|WG|WDG|DF|SP|SG|GR|DP|DS|WS|TB|CG)$/.test(c)) ?? null;
  return {
    names: parts.map((p) => p.name).join('+'),
    key: parts.map((p) => `${p.name}@${p.pct}`).join('+'),
    form: code ? (FORM_ALIAS[code] ?? code) : null,
  };
}

const PARSED = PRODUCTS.map((product) => ({ product, parsed: parseComposition(product.name) }));

export type LabelMatch = {
  exact: Product[];
  /** Same chemicals but a different strength or formulation — doses differ, so the farmer must compare with the bottle. */
  similar: Product[];
  /** The chemical is in the register, but not for this crop. */
  notForCrop: boolean;
};

export function matchComposition(text: string, crop: CropId): LabelMatch {
  const label = parseComposition(text);
  if (!label) return { exact: [], similar: [], notForCrop: false };
  const sameNames = PARSED.filter((p) => p.parsed?.names === label.names);
  const forCrop = sameNames.filter((p) => rowsFor(p.product, crop).length);
  const isExact = (p: (typeof PARSED)[number]) => p.parsed?.key === label.key && (!label.form || !p.parsed.form || p.parsed.form === label.form);
  return {
    exact: forCrop.filter(isExact).map((p) => p.product),
    similar: forCrop.filter((p) => !isExact(p)).map((p) => p.product),
    notForCrop: sameNames.length > 0 && forCrop.length === 0,
  };
}

export function searchProducts(query: string, crop: CropId, limit = 25): Product[] {
  const q = letters(query);
  if (q.length < 3) return [];
  return PRODUCTS.filter((p) => letters(p.name).includes(q) && rowsFor(p, crop).length)
    .sort((a, b) => a.name.localeCompare(b.name))
    .slice(0, limit);
}

export type FertCrop = 'rice' | 'wheat' | 'maize';
export const FERT_CROPS: FertCrop[] = ['rice', 'wheat', 'maize'];
export type Npk = [number, number, number];
export const GFR_SOURCE = gfrData.source;

/** ICAR district recommendation (kg/ha N:P2O5:K2O) and the earlier state-wide one it replaced. */
export function gfrFor(district: string, crop: FertCrop): { npk: Npk; earlier: Npk } | null {
  const d = (gfrData.districts as Record<string, Record<FertCrop, number[]>>)[district];
  return d ? { npk: d[crop] as Npk, earlier: gfrData.earlier[crop] as Npk } : null;
}
