import AsyncStorage from '@react-native-async-storage/async-storage';

// TRD §11: every function that makes a network or AI call checks this FIRST, before any request.
// Phase 9 (D-44): founder-only switch, kept on the phone so it works from a cold start in airplane mode.
const KEY = 'ks.demoMode';
let demoMode = false;

export function isDemoMode(): boolean {
  return demoMode;
}

export async function loadDemoMode(): Promise<boolean> {
  demoMode = (await AsyncStorage.getItem(KEY)) === '1';
  return demoMode;
}

export async function setDemoMode(on: boolean): Promise<void> {
  demoMode = on;
  await AsyncStorage.setItem(KEY, on ? '1' : '0');
}

/** Demo answers arrive after a realistic pause, so loading states look the same as live. */
export const demoDelay = (ms: number) => new Promise<void>((resolve) => setTimeout(resolve, ms));
