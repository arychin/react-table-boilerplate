// D-42 Daily Action Feed checks: stage maths against hand-worked dates, and every threshold number against the
// NIPHM ETL tables (if the source text is in /tmp/ks_sources/ipm — see scripts/build_calculator_data.py for the pattern).
// Run: npx --yes tsx --tsconfig tsconfig.json scripts/check_crop_feed.mts
import { existsSync, readFileSync } from 'node:fs';

import { pastDate } from '../src/features/crop-feed/api';
import { CHECKS, daysBetween, riceStage, todayFor, type CropPlan } from '../src/features/crop-feed/feed';

let pass = 0, fail = 0;
function check(name: string, ok: boolean, got?: unknown) {
  if (ok) pass++; else { fail++; console.log('FAIL', name, JSON.stringify(got)); }
}

check('daysBetween', daysBetween('2026-07-01', '2026-07-21') === 20 && daysBetween('2026-02-27', '2026-03-01') === 2);
check('daysBetween across year', daysBetween('2025-12-31', '2026-01-01') === 1);

// 130-day paddy: harvest−65 = day 65 panicle initiation, harvest−30 = day 100 flowering → ripening, day 130 harvest
const stages = [0, 64, 65, 99, 100, 129, 130, 150].map((d) => riceStage(d, 130));
check('rice stages 130 d', stages.join() === 'rice_veg,rice_veg,rice_repro,rice_repro,rice_ripen,rice_ripen,rice_harvest,rice_harvest', stages);
check('rice stages 110 d', riceStage(44, 110) === 'rice_veg' && riceStage(45, 110) === 'rice_repro' && riceStage(80, 110) === 'rice_ripen');

const rice: CropPlan = { crop: 'rice', sownOn: '2026-07-01', duration: 130, chanaStage: 'chana_veg', lastScouted: null };
const t1 = todayFor(rice, '2026-07-10');
check('day 9 → too early, scout in 11', t1?.dayNo === 9 && t1.scouting === 'too_early' && t1.nextScoutIn === 11 && t1.harvestIn === 121, t1);
check('day 20, never scouted → due', todayFor(rice, '2026-07-21')?.scouting === 'due');
const t3 = todayFor({ ...rice, lastScouted: '2026-07-21' }, '2026-07-23');
check('scouted 2 days ago → done, next in 1', t3?.scouting === 'done' && t3.nextScoutIn === 1, t3);
check('3 days later → due again', todayFor({ ...rice, lastScouted: '2026-07-21' }, '2026-07-24')?.scouting === 'due');
check('sown in future → null', todayFor(rice, '2026-06-30') === null);
const t5 = todayFor(rice, '2026-11-08');
check('day 130 → harvest, no scouting', t5?.stage === 'rice_harvest' && t5.scouting === 'not_needed' && t5.harvestIn === 0, t5);

const chana: CropPlan = { crop: 'chana', sownOn: '2026-10-20', duration: 130, chanaStage: 'chana_pod', lastScouted: '2026-11-15' };
const c1 = todayFor(chana, '2026-11-20');
check('chana uses chosen stage, weekly scouting', c1?.stage === 'chana_pod' && c1.scouting === 'done' && c1.nextScoutIn === 2 && c1.harvestIn === null, c1);
check('chana 7 days → due', todayFor(chana, '2026-11-22')?.scouting === 'due');

check('pastDate same year', pastDate(15, 7, '2026-10-16') === '2026-07-15');
check('pastDate Nov last year on 16 Jan', pastDate(20, 11, '2027-01-16') === '2026-11-20');
check('pastDate typed future date → rejected, not last year', pastDate(20, 11, '2026-10-16') === null && pastDate(20, 10, '2026-10-16') === null);
check('pastDate today', pastDate(16, 10, '2026-10-16') === '2026-10-16');
check('pastDate invalid', pastDate(31, 6, '2026-10-16') === null && pastDate(0, 5) === null && pastDate(5, 13) === null);

for (const [stage, list] of Object.entries(CHECKS)) check(`${stage} has checks`, stage === 'rice_harvest' ? list.length === 0 : list.length > 0);

// Every number in a threshold must appear in the source ETL table.
for (const [file, stagesOf] of [['Rice', ['rice_veg', 'rice_repro', 'rice_ripen']], ['Chickpea', ['chana_seedling', 'chana_veg', 'chana_pod']]] as const) {
  const path = `/tmp/ks_sources/ipm/${file}.txt`;
  if (!existsSync(path)) { console.log(`skip source check (${path} missing)`); continue; }
  const text = readFileSync(path, 'latin1').replace(/\s+/g, ' ');
  const startAt = text.indexOf(file === 'Rice' ? 'ECONOMIC THRESHOLD LEVEL (ETL) OF MAJOR PESTS' : 'Economic Threshold Levels (ETLs)');
  const etl = text.slice(startAt, text.indexOf(file === 'Rice' ? '3.2. Cultural' : 'Nematodes', startAt));
  check(`${file} ETL table found`, startAt >= 0 && etl.length > 300, etl.length);
  for (const s of stagesOf) for (const c of CHECKS[s]) {
    const nums = c.act.en.match(/\d+(?:–\d+)?/g) ?? [];
    const missing = nums.map((n) => n.replace('–', '-')).filter((n) => !etl.includes(n) && !etl.includes(n.replace('-', ' to ')));
    check(`${s} ${c.name.en} numbers in NIPHM table`, missing.length === 0, missing);
  }
}

console.log(`${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
