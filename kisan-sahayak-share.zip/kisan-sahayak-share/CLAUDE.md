# Kisan Sahayak
AI agricultural advisory app. React Native + Expo (TypeScript, strict) +
Supabase (Postgres, Edge Functions) + Gemini Flash (vision/chat) +
Sarvam AI Bulbul v3 (Hindi TTS) + WhatsApp Cloud API.

## Commands
- Dev server: npx expo start
- Type check: npx tsc --noEmit
- Lint: npm run lint
- Test: npm test
- Deploy Edge Function: supabase functions deploy <name>

## Rules
- No `any` type without an inline comment explaining why.
- No third-party API key in src/ — ever. Server calls only, via Edge Functions.
- One Haversine implementation: src/lib/haversine.ts. Import it, never re-write it.
- Gemini image analysis calls MUST use responseSchema structured output,
  never freeform markdown parsing.
- Auto-detect image MIME type from the file. Never hardcode 'image/jpeg'.
- Hindi summary generation is a separate call from the main diagnosis call
  and must never block the main result if it fails.
- Check isDemoMode at the top of every function that makes a network or AI
  call, before any request is sent.
- Use the simplest possible implementation. Do not add abstraction layers
  for single-use functions.
- Run type check and lint before declaring any task complete.

## Project-specific additions (see project_memory/DECISIONS.md)
- Session start: read project_memory/*.md, decisions.md, flow.md, then the relevant docs/*.txt.
- Log every meaningful action in project_memory/ using the SESSION_LOG format.
- NO git of any kind — local only (D-11).
- CLI only; this laptop cannot use web dashboards (D-10).
- Load secrets into the shell only: `eval "$(python3 scripts/load_secrets.py)"`.
  Never write secret values to any file in this project.
- The corporate proxy intercepts TLS. Before running supabase or eas CLIs:
  `export SSL_CERT_FILE=~/.certs/ca-bundle-with-shell.pem NODE_EXTRA_CA_CERTS=~/.certs/ca-bundle-with-shell.pem`
- Gemini and Sarvam are blocked from this laptop (Zscaler "Gen AI" category). Test them only through deployed Edge Functions.
- Supabase CLI: `npx supabase@2.119.0 …`; deploy functions with `--use-api` (no Docker).
- EAS CLI: always `export EAS_NO_VCS=1 EAS_PROJECT_ROOT=/Users/Achint.Tiwary/Desktop/poc` — otherwise EAS treats the home folder (a git repo) as the project root.
- Edge Function code (Deno) is excluded from tsc/eslint; check it with `cd supabase/functions && npx --yes deno@latest check <fn>/index.ts`.
- `npm test` is not configured yet.
- MVP: no AI-generated pesticide doses — show "follow label / confirm at KVK" (D-6).
- Shop data: only trusted coordinates are used for distance; otherwise Directions opens by name + address (D-12).
