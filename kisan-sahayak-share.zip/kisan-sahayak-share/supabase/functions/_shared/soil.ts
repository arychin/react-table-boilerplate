// Soil analysis prompt + schema (Vision Brief §3.4), reusing the crop pipeline in diagnose-crop (Plan Phase 5 step 1).
// Vision Brief §2.2 is binding: a soil photo never replaces a lab test, so nutrient findings are only "possible".
import { LANGUAGE_RULE, type Language } from './diagnosis.ts';
import { generate } from './gemini.ts';

export const SOIL_SCHEMA = {
  type: 'object',
  properties: {
    soil_type: { type: 'string' },
    moisture: { type: 'string', enum: ['low', 'medium', 'high'] },
    confidence: { type: 'string', enum: ['low', 'medium', 'high'] },
    observations: { type: 'string' },
    possible_deficiencies: { type: 'array', items: { type: 'string' } },
    fertilisers: {
      type: 'array',
      items: {
        type: 'object',
        properties: { name: { type: 'string' }, why: { type: 'string' } },
        required: ['name', 'why'],
        propertyOrdering: ['name', 'why'],
      },
    },
    improvement_tips: { type: 'array', items: { type: 'string' } },
  },
  required: ['soil_type', 'moisture', 'confidence', 'observations', 'possible_deficiencies', 'fertilisers', 'improvement_tips'],
  propertyOrdering: ['soil_type', 'moisture', 'confidence', 'observations', 'possible_deficiencies', 'fertilisers', 'improvement_tips'],
} as const;

export type SoilReport = {
  soil_type: string;
  moisture: 'low' | 'medium' | 'high';
  confidence: 'low' | 'medium' | 'high';
  observations: string;
  possible_deficiencies: string[];
  fertilisers: { name: string; why: string }[];
  improvement_tips: string[];
};

function soilInstruction(language: Language): string {
  return `You are Kisan Sahayak, a careful soil adviser for small farmers in Chhattisgarh, India (paddy, wheat, soybean, chickpea, vegetables; common soils: red-yellow, black/kanhar, matasi, dorsa, bhata/laterite, alluvial).
Look at the photo of the farmer's soil and give a practical, honest reading of what is VISIBLE.

Rules — follow all of them:
1. ${LANGUAGE_RULE[language]}
2. A photo cannot measure nutrients. Never state a nutrient value, pH number or percentage. possible_deficiencies: 0 to 3 items, each phrased as a possibility with the visible reason (for example "may be low in organic matter — the soil looks pale and loose"). If nothing is visibly suggested, return an empty list.
3. NEVER state a dose, quantity, amount per acre or bag count. You may name the product.
4. fertilisers: 1 to 3 products a Krishi Kendra in Chhattisgarh commonly stocks (for example vermicompost, farmyard manure, urea, DAP, SSP, MOP, NPK 12:32:16, NPK 19:19:19, zinc sulphate, gypsum, lime), most useful first, each with one line on why. Prefer organic matter when the soil looks poor in it. name must be only the product name a farmer can ask for at a shop, written in the answer language (rule 1); keep grade numbers like 19:19:19 as they are.
5. moisture: "low" (dry, dusty, cracked), "medium" (slightly damp, crumbly), "high" (wet, sticky, waterlogged).
6. Be honest about uncertainty. confidence "high" only when bare soil is clearly visible close up in good light; "medium" when visible but far away, mixed with crop residue or in poor light; "low" when the photo does not mainly show soil.
7. If the photo does not mainly show soil (for example a wall, a house, a leaf, a person): say the photo is unclear in soil_type, confidence "low", moisture "medium", empty possible_deficiencies and fertilisers, and use improvement_tips to ask for a close photo of bare soil (remove grass and stones, daylight, about one foot away).
8. observations: one or two sentences on colour, texture, cracks, stones and organic matter you can see.
9. improvement_tips: 2 to 4 short practical tips (organic matter, mulching, drainage, crop rotation, getting a Soil Health Card test at the nearest KVK or soil lab for exact values).
10. Do not promise yield or results.`;
}

// Safety net for rule 7: an unclear photo must never come with product recommendations.
function enforceSoilSafety(r: SoilReport): SoilReport {
  return r.confidence === 'low' ? { ...r, fertilisers: [], possible_deficiencies: [] } : r;
}

export async function analyseSoil(opts: { language: Language; mimeType: string; base64: string }): Promise<{ diagnosis: SoilReport; model: string }> {
  const { text, model } = await generate({
    systemInstruction: { parts: [{ text: soilInstruction(opts.language) }] },
    contents: [{
      role: 'user',
      parts: [{ inlineData: { mimeType: opts.mimeType, data: opts.base64 } }, { text: 'Analyse this soil photo.' }],
    }],
    generationConfig: {
      temperature: 0.2,
      responseMimeType: 'application/json',
      responseSchema: SOIL_SCHEMA,
      maxOutputTokens: 1024,
    },
  });
  return { diagnosis: enforceSoilSafety(JSON.parse(text) as SoilReport), model };
}
